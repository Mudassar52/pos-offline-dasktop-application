import { useState, useMemo, useCallback, useEffect } from "react";
import { PRODUCT_CATEGORIES } from "../data/mockData";
import { buildStockAlerts, getStockStatus } from "../utils/productHelpers";
import { api } from "../api/client";

// ── IndexedDB helpers for logo (unchanged) ──
function openLogoIDB() {
  return new Promise((res, rej) => {
    const r = indexedDB.open("inv_settings", 1);
    r.onupgradeneeded = (e) => e.target.result.createObjectStore("logo");
    r.onsuccess = (e) => res(e.target.result);
    r.onerror = () => rej(r.error);
  });
}
async function loadLogoFromIDB() {
  try {
    const db = await openLogoIDB();
    return new Promise((res) => {
      const req = db.transaction("logo", "readonly").objectStore("logo").get("current");
      req.onsuccess = () => res(req.result || null);
      req.onerror = () => res(null);
    });
  } catch {
    return null;
  }
}
async function saveLogoToIDB(logoData) {
  const db = await openLogoIDB();
  await new Promise((res, rej) => {
    const tx = db.transaction("logo", "readwrite");
    tx.objectStore("logo").put(logoData, "current");
    tx.oncomplete = res;
    tx.onerror = () => rej(tx.error);
  });
}

// ── Hook ─────────────────────────────────────────────────────────────────────
export function useProducts(uid) {
  const [products, setProducts] = useState([]);
  const [sales, setSales] = useState([]);
  const [manualInvoices, setManualInvoices] = useState([]);
  const [categories, setCategories] = useState(PRODUCT_CATEGORIES);
  const [appSettings, setAppSettings] = useState({ appName: "Shakir POS", tagline: "Pro Dashboard" });
  const [invoiceSettings, setInvoiceSettings] = useState({ ownerName: "", businessName: "", phone: "", address: "", logo: "" });
  const [customers, setCustomers] = useState([]);
  const [suppliers, setSuppliers] = useState([]);
  const [supplierTransactions, setSupplierTransactions] = useState([]);
  const [supplierPurchases, setSupplierPurchases] = useState([]);
  const [expenses, setExpenses] = useState([]);
  const [expenseCategories, setExpenseCategories] = useState(["Rent", "Utilities", "Salaries", "Transport", "Maintenance", "Other"]);
  const [expenseCategoryColors, setExpenseCategoryColors] = useState({});
  const [returns, setReturns] = useState([]);
  const [losses, setLosses] = useState([]);
  const [loading, setLoading] = useState(true);

  // ── Modular Refresh Actions ────────────────────────────────────────────────
  const refreshProducts = useCallback(async () => {
    if (!uid) return;
    try {
      const data = await api.get("/api/products");
      setProducts(data || []);
    } catch (e) {
      console.error("Failed to refresh products:", e);
    }
  }, [uid]);

  const refreshCustomers = useCallback(async () => {
    if (!uid) return;
    try {
      const data = await api.get("/api/customers");
      setCustomers(data || []);
    } catch (e) {
      console.error("Failed to refresh customers:", e);
    }
  }, [uid]);

  const refreshInvoices = useCallback(async () => {
    if (!uid) return;
    try {
      const [manualData, salesData] = await Promise.all([
        api.get("/api/invoices"),
        api.get("/api/pos"),
      ]);
      setManualInvoices(manualData || []);
      setSales(salesData || []);
    } catch (e) {
      console.error("Failed to refresh invoices:", e);
    }
  }, [uid]);

  const refreshSettings = useCallback(async () => {
    if (!uid) return;
    try {
      const data = await api.get("/api/settings");
      if (data) {
        setAppSettings(data.appSettings || { appName: "Shakir POS", tagline: "Pro Dashboard" });
        setCategories(data.categories?.length ? data.categories : PRODUCT_CATEGORIES);
        setExpenseCategories(data.expenseCategories?.length ? data.expenseCategories : ["Rent", "Utilities", "Salaries", "Transport", "Maintenance", "Other"]);
        setExpenseCategoryColors(data.expenseCategoryColors || {});
        const inv = data.invoiceSettings || {};
        if (inv.logo === "__local__") {
          const logoData = await loadLogoFromIDB();
          setInvoiceSettings({ ...inv, logo: logoData || "" });
        } else {
          setInvoiceSettings(inv);
        }
      }
    } catch (e) {
      console.error("Failed to refresh settings:", e);
    }
  }, [uid]);

  const refreshSuppliers = useCallback(async () => {
    if (!uid) return;
    try {
      const [supplierData, txnData] = await Promise.all([
        api.get("/api/suppliers"),
        api.get("/api/supplier-transactions"),
      ]);
      setSuppliers(supplierData || []);
      setSupplierTransactions(txnData || []);
    } catch (e) {
      console.error("Failed to refresh suppliers:", e);
    }
  }, [uid]);

  const refreshExpenses = useCallback(async () => {
    if (!uid) return;
    try {
      const data = await api.get("/api/expenses");
      setExpenses(data || []);
    } catch (e) {
      console.error("Failed to refresh expenses:", e);
    }
  }, [uid]);

  const refreshReturns = useCallback(async () => {
    if (!uid) return;
    try {
      const data = await api.get("/api/returns");
      setReturns(data || []);
    } catch (e) {
      console.error("Failed to refresh returns:", e);
    }
  }, [uid]);

  const refreshLosses = useCallback(async () => {
    if (!uid) return;
    try {
      const data = await api.get("/api/losses");
      setLosses(data || []);
    } catch (e) {
      console.error("Failed to refresh losses:", e);
    }
  }, [uid]);

  const refreshAll = useCallback(async () => {
    if (!uid) return;
    await Promise.all([
      refreshProducts(),
      refreshCustomers(),
      refreshInvoices(),
      refreshSettings(),
      refreshSuppliers(),
      refreshExpenses(),
      refreshReturns(),
      refreshLosses(),
    ]);
  }, [uid, refreshProducts, refreshCustomers, refreshInvoices, refreshSettings, refreshSuppliers, refreshExpenses, refreshReturns, refreshLosses]);

  useEffect(() => {
    if (!uid) {
      setLoading(false);
      return;
    }
    setLoading(true);
    refreshAll().finally(() => setLoading(false));
  }, [uid, refreshAll]);

  // ── Computed ────────────────────────────────────────────────────────────
  const alerts = useMemo(() => buildStockAlerts(products), [products]);

  const stats = useMemo(() => {
    const totalProducts = products.length;
    const totalStock = products.reduce((sum, p) => sum + (p.currentStock || 0), 0);
    const lowStockCount = products.filter((p) => getStockStatus(p) === "low").length;
    const outOfStockCount = products.filter((p) => getStockStatus(p) === "out").length;
    return { totalProducts, totalStock, lowStockCount, outOfStockCount };
  }, [products]);

  const allInvoices = useMemo(() => {
    const normalize = (inv) => {
      const advancePayments = (inv.payments || []).filter(p => p.note && p.note.includes("Advance at sale")).reduce((s, p) => s + (p.amount || 0), 0);
      const extraPayments = (inv.payments || []).filter(p => !p.note || !p.note.includes("Advance at sale")).reduce((s, p) => s + (p.amount || 0), 0);
      const totalPaid = advancePayments + extraPayments + (inv.advance && advancePayments === 0 ? inv.advance : 0);
      const due = Math.max(0, (inv.total || 0) - totalPaid);
      let paymentStatus;
      if (due <= 0) paymentStatus = "paid";
      else if (totalPaid > 0) paymentStatus = "partial";
      else paymentStatus = "udaar";
      return { ...inv, paymentStatus };
    };
    const combined = [
      ...sales.map((s) => normalize({ ...s, source: s.source || "pos" })),
      ...manualInvoices.map((m) => normalize({ ...m, source: m.source || "manual" })),
    ];
    return combined.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
  }, [sales, manualInvoices]);

  const posStats = useMemo(() => {
    const inStock = products.filter((p) => p.currentStock > 0).length;
    const today = new Date().toDateString();
    const todaySales = sales.filter((s) => new Date(s.createdAt).toDateString() === today);
    const todayRevenue = todaySales.reduce((sum, s) => sum + (s.total || 0), 0);
    return { inStock, todaySalesCount: todaySales.length, todayRevenue };
  }, [products, sales]);

  // ── Product actions ─────────────────────────────────────────────────────
  const addProduct = useCallback(async (form) => {
    const created = await api.post("/api/products", form);
    setProducts((prev) => [...prev, created]);
    return created;
  }, []);

  const updateProduct = useCallback(async (id, form) => {
    const updated = await api.put(`/api/products/${id}`, form);
    setProducts((prev) => prev.map((p) => (String(p.id) === String(id) ? updated : p)));
    return updated;
  }, []);

  const deleteProduct = useCallback(async (id) => {
    await api.delete(`/api/products/${id}`);
    setProducts((prev) => prev.filter((p) => String(p.id) !== String(id)));
  }, []);

  const stockIn = useCallback(async (id, qty) => {
    const amount = Number(qty);
    if (!amount || amount <= 0) return false;
    try {
      const updated = await api.post(`/api/products/${id}/stock-in`, { qty: amount });
      setProducts((prev) => prev.map((p) => (String(p.id) === String(id) ? updated : p)));
      return true;
    } catch {
      return false;
    }
  }, []);

  const stockOut = useCallback(async (id, qty) => {
    const amount = Number(qty);
    if (!amount || amount <= 0) return false;
    try {
      const updated = await api.post(`/api/products/${id}/stock-out`, { qty: amount });
      setProducts((prev) => prev.map((p) => (String(p.id) === String(id) ? updated : p)));
      return true;
    } catch {
      return false;
    }
  }, []);

  // ── Sale / Invoice actions ───────────────────────────────────────────────
  // IMPORTANT: all the actions below used to `await` a full re-fetch of every
  // product and/or every customer from the server before letting the caller
  // continue (e.g. before the "Save Invoice" button stopped spinning, or
  // before the POS checkout modal closed). With a large product/customer/
  // invoice list, that re-fetch (network round-trip + JSON parsing) can take
  // real time — and since the UI was waiting on it, EVERY action (not just
  // page navigation) felt like it hung. Now we update the visible data
  // immediately (optimistically where possible) and let the full refresh
  // happen quietly in the background, without blocking the UI.
  const completeSale = useCallback(async (items) => {
    if (!items?.length) return { success: false };
    try {
      const result = await api.post("/api/pos/complete-sale", { items });
      if (result.success) {
        // Optimistic instant stock update — no need to wait for a full
        // products re-fetch just to reflect what we already know changed.
        setProducts((prev) => prev.map((p) => {
          const sold = items.find((it) => String(it.productId) === String(p.id));
          if (!sold) return p;
          return { ...p, currentStock: Math.max(0, (p.currentStock || 0) - (sold.qty || 0)) };
        }));
        // Background reconciliation (e.g. if stock was also changed elsewhere) —
        // fire-and-forget, doesn't block the checkout flow.
        refreshProducts();
      }
      return result;
    } catch {
      return { success: false };
    }
  }, [refreshProducts]);

  const recordSale = useCallback(async (sale) => {
    const created = await api.post("/api/pos/sales", sale);
    setSales((prev) => [created, ...prev]);
    // Background refresh — don't block on it.
    if (sale.customerId) refreshCustomers();
    refreshProducts();
    return created;
  }, [refreshCustomers, refreshProducts]);

  const createManualInvoice = useCallback(async (data) => {
    const created = await api.post("/api/invoices/manual", data);
    setManualInvoices((prev) => [created, ...prev]);
    // Background refresh — the invoice itself is already reflected above via
    // `created`, so the modal/UI doesn't need to wait for the full
    // products/customers re-fetch to complete.
    if (data.customerId) refreshCustomers();
    refreshProducts();
    return created;
  }, [refreshCustomers, refreshProducts]);

  const updateInvoice = useCallback(async (id, data, source) => {
    const updated = await api.put(`/api/invoices/${id}?source=${source === "manual" ? "manual" : "pos"}`, data);
    if (source === "manual") {
      setManualInvoices((prev) => prev.map((i) => (String(i.id) === String(id) ? updated : i)));
    } else {
      setSales((prev) => prev.map((i) => (String(i.id) === String(id) ? updated : i)));
    }
    // Background refresh — don't block on it.
    refreshProducts();
    refreshCustomers();
    return updated;
  }, [refreshProducts, refreshCustomers]);

  const deleteInvoice = useCallback(async (id, source) => {
    if (source === "manual") {
      await api.delete(`/api/invoices/${id}?source=manual`);
      setManualInvoices((prev) => prev.filter((i) => String(i.id) !== String(id)));
    } else {
      await api.delete(`/api/pos/${id}`);
      setSales((prev) => prev.filter((i) => String(i.id) !== String(id)));
    }
    // Invoice is already removed from the visible list above (optimistic),
    // so the delete-confirm modal can close instantly — the affected
    // product stock / customer balance reconcile in the background.
    refreshProducts();
    refreshCustomers();
  }, [refreshProducts, refreshCustomers]);


  // ── Customer actions ─────────────────────────────────────────────────────
  const addCustomer = useCallback(async (form) => {
    const created = await api.post("/api/customers", form);
    setCustomers((prev) => [...prev, created]);
    return created;
  }, []);

  const updateCustomer = useCallback(async (id, form) => {
    const updated = await api.put(`/api/customers/${id}`, form);
    setCustomers((prev) => prev.map((c) => (String(c.id) === String(id) ? updated : c)));
    return updated;
  }, []);

  const deleteCustomer = useCallback(async (id) => {
    await api.delete(`/api/customers/${id}`);
    setCustomers((prev) => prev.filter((c) => String(c.id) !== String(id)));
  }, []);

  // ── Payment & Ledger actions ────────────────────────────────────────────
  const receivePayment = useCallback(async ({ customerId, amount, date, note, allocations }) => {
    const mapped = allocations.map((a) => ({
      ...a,
      source: sales.some((s) => String(s.id) === String(a.invoiceId)) ? "pos" : "manual",
    }));
    await api.post("/api/invoices/receive-payment", { customerId, amount, date, note, allocations: mapped });
    // Background refresh — don't make the person wait for the whole
    // customer + invoice list to re-download before the payment dialog closes.
    refreshCustomers();
    refreshInvoices();
  }, [sales, refreshCustomers, refreshInvoices]);

  const addBalanceAdjustment = useCallback(async ({ customerId, type, amount, reason, date }) => {
    const updated = await api.post(`/api/customers/${customerId}/adjustments`, { type, amount, reason, date });
    setCustomers((prev) => prev.map((c) => (String(c.id) === String(customerId) ? updated : c)));
  }, []);

  // Advance — customer se pehle se paisa lena, jo agli udaar khareedari
  // par khud-ba-khud istemal ho jata hai.
  const addCustomerAdvance = useCallback(async (customerId, { amount, note, date }) => {
    const updated = await api.post(`/api/customers/${customerId}/advance`, { amount, note, date });
    setCustomers((prev) => prev.map((c) => (String(c.id) === String(customerId) ? updated : c)));
    return updated;
  }, []);

  // ── Supplier actions ─────────────────────────────────────────────────────
  const addSupplier = useCallback(async (form) => {
    const created = await api.post("/api/suppliers", form);
    setSuppliers((prev) => [created, ...prev]);
    return created;
  }, []);

  const updateSupplier = useCallback(async (id, form) => {
    const updated = await api.put(`/api/suppliers/${id}`, form);
    setSuppliers((prev) => prev.map((s) => (String(s.id) === String(id) ? updated : s)));
    return updated;
  }, []);

  const deleteSupplier = useCallback(async (id) => {
    await api.delete(`/api/suppliers/${id}`);
    setSuppliers((prev) => prev.filter((s) => String(s.id) !== String(id)));
    setSupplierTransactions((prev) => prev.filter((t) => String(t.supplierId) !== String(id)));
  }, []);

  // type: 'purchase' (maal liya) or 'payment' (supplier ko paise diye)
  const addSupplierTransaction = useCallback(async (supplierId, { type, amount, description, date }) => {
    const created = await api.post(`/api/suppliers/${supplierId}/transactions`, { type, amount, description, date });
    setSupplierTransactions((prev) => [created, ...prev]);
    return created;
  }, []);

  const deleteSupplierTransaction = useCallback(async (supplierId, transactionId) => {
    await api.delete(`/api/suppliers/${supplierId}/transactions/${transactionId}`);
    setSupplierTransactions((prev) => prev.filter((t) => String(t.id) !== String(transactionId)));
  }, []);

  // Maal khareedna (purchase) — ek batch mein multiple products select karo
  // (ya naya likho), har ek ki qty + purchase price + poore batch ka advance
  // do; supplier ledger aur har product ka stock/catalog ek hi call mein
  // khud update ho jate hain.
  const addSupplierPurchase = useCallback(async (supplierId, form) => {
    const result = await api.post(`/api/suppliers/${supplierId}/purchase`, form);
    if (result.purchase) setSupplierTransactions((prev) => [result.purchase, ...prev]);
    if (result.payment) setSupplierTransactions((prev) => [result.payment, ...prev]);
    if (result.purchaseRecord) setSupplierPurchases((prev) => [result.purchaseRecord, ...prev]);
    const updatedProducts = result.products || (result.product ? [result.product] : []);
    if (updatedProducts.length) {
      setProducts((prev) => {
        let next = prev;
        updatedProducts.forEach((p) => {
          const exists = next.some((x) => String(x.id) === String(p.id));
          next = exists
            ? next.map((x) => (String(x.id) === String(p.id) ? p : x))
            : [...next, p];
        });
        return next;
      });
    }
    return result;
  }, []);

  // Ek supplier ki saari purchase receipts (multi-product batches) — Purchases
  // tab mein dikhane aur thermal Urdu receipt print karne ke liye.
  const fetchSupplierPurchases = useCallback(async (supplierId) => {
    const data = await api.get(`/api/suppliers/${supplierId}/purchases`);
    setSupplierPurchases((prev) => {
      const others = prev.filter((p) => String(p.supplierId) !== String(supplierId));
      return [...others, ...(data || [])];
    });
    return data || [];
  }, []);

  // Ek purchase invoice edit karna — items/qty/price badalne par product
  // stock aur cost price khud reconcile ho jate hain (purana undo, naya apply).
  const updateSupplierPurchase = useCallback(async (supplierId, purchaseId, form) => {
    const result = await api.put(`/api/suppliers/${supplierId}/purchases/${purchaseId}`, form);
    if (result.purchaseRecord) {
      setSupplierPurchases((prev) => prev.map((p) => (String(p.id) === String(purchaseId) ? result.purchaseRecord : p)));
    }
    if (result.products) {
      setProducts((prev) => {
        let next = prev;
        result.products.forEach((p) => {
          const exists = next.some((x) => String(x.id) === String(p.id));
          next = exists ? next.map((x) => (String(x.id) === String(p.id) ? p : x)) : [...next, p];
        });
        return next;
      });
    }
    return result;
  }, []);

  // Payment — ek specific purchase invoice ke against, ya (purchaseId na
  // dene par) supplier ki overall balance ke against jo purani se nayi
  // invoices mein khud distribute ho jata hai.
  const paySupplierInvoice = useCallback(async (supplierId, form) => {
    const result = await api.post(`/api/suppliers/${supplierId}/pay`, form);
    if (result.payment) setSupplierTransactions((prev) => [result.payment, ...prev]);
    if (result.updatedPurchases?.length) {
      setSupplierPurchases((prev) => {
        let next = prev;
        result.updatedPurchases.forEach((p) => {
          next = next.map((x) => (String(x.id) === String(p.id) ? p : x));
        });
        return next;
      });
    }
    return result;
  }, []);

  // Advance — supplier ko future purchases ke liye pehle se paisa dena.
  // Agar koi purani outstanding invoice hai to wo pehle usi mein lag jata
  // hai, jo bache wo agli purchase par khud istemal ho jata hai.
  const addSupplierAdvance = useCallback(async (supplierId, form) => {
    const result = await api.post(`/api/suppliers/${supplierId}/advance`, form);
    if (result.payment) setSupplierTransactions((prev) => [result.payment, ...prev]);
    if (result.updatedPurchases?.length) {
      setSupplierPurchases((prev) => {
        let next = prev;
        result.updatedPurchases.forEach((p) => {
          next = next.map((x) => (String(x.id) === String(p.id) ? p : x));
        });
        return next;
      });
    }
    return result;
  }, []);

  // ── Expense actions ──────────────────────────────────────────────────────
  const addExpense = useCallback(async (form) => {
    const created = await api.post("/api/expenses", form);
    setExpenses((prev) => [created, ...prev]);
    return created;
  }, []);

  const updateExpense = useCallback(async (id, form) => {
    const updated = await api.put(`/api/expenses/${id}`, form);
    setExpenses((prev) => prev.map((e) => (String(e.id) === String(id) ? updated : e)));
    return updated;
  }, []);

  const deleteExpense = useCallback(async (id) => {
    await api.delete(`/api/expenses/${id}`);
    setExpenses((prev) => prev.filter((e) => String(e.id) !== String(id)));
  }, []);

  const addExpenseCategory = useCallback(async (name) => {
    const trimmed = name.trim();
    if (!trimmed || expenseCategories.includes(trimmed)) return;
    const settings = await api.post("/api/settings/expense-categories", { name: trimmed });
    setExpenseCategories(settings.expenseCategories);
  }, [expenseCategories]);

  const removeExpenseCategory = useCallback(async (name) => {
    const settings = await api.delete(`/api/settings/expense-categories/${encodeURIComponent(name)}`);
    if (settings) setExpenseCategories(settings.expenseCategories);
    else setExpenseCategories((prev) => prev.filter((c) => c !== name));
  }, []);

  const setExpenseCategoryColor = useCallback(async (name, color) => {
    const settings = await api.put("/api/settings/expense-category-colors", { name, color });
    setExpenseCategoryColors(settings.expenseCategoryColors || {});
  }, []);

  // ── Order Returns actions ────────────────────────────────────────────────
  const addReturn = useCallback(async (form) => {
    const created = await api.post("/api/returns", form);
    setReturns((prev) => [created, ...prev]);
    if (form.productId) {
      setProducts((prev) => prev.map((p) => (
        String(p.id) === String(form.productId)
          ? { ...p, currentStock: (p.currentStock || 0) + Number(form.qty || 0) }
          : p
      )));
      refreshProducts();
    }
    return created;
  }, [refreshProducts]);

  const deleteReturn = useCallback(async (id) => {
    const row = returns.find((r) => String(r.id) === String(id));
    await api.delete(`/api/returns/${id}`);
    setReturns((prev) => prev.filter((r) => String(r.id) !== String(id)));
    // Return delete karte hi uska stock turant wapis ho jaye — background
    // refresh ka wait na karna pade (jo pehle der se update hota tha).
    if (row?.productId) {
      setProducts((prev) => prev.map((p) => (
        String(p.id) === String(row.productId)
          ? { ...p, currentStock: Math.max(0, (p.currentStock || 0) - row.qty) }
          : p
      )));
      refreshProducts();
    }
  }, [returns, refreshProducts]);

  // ── Loss Management actions ──────────────────────────────────────────────
  const addLoss = useCallback(async (form) => {
    const created = await api.post("/api/losses", form);
    setLosses((prev) => [created, ...prev]);
    if (form.productId) {
      setProducts((prev) => prev.map((p) => (
        String(p.id) === String(form.productId)
          ? { ...p, currentStock: Math.max(0, (p.currentStock || 0) - Number(form.qty || 0)) }
          : p
      )));
      refreshProducts();
    }
    return created;
  }, [refreshProducts]);

  const deleteLoss = useCallback(async (id) => {
    const row = losses.find((l) => String(l.id) === String(id));
    await api.delete(`/api/losses/${id}`);
    setLosses((prev) => prev.filter((l) => String(l.id) !== String(id)));
    // Loss delete karte hi uska stock turant wapis add ho jaye — background
    // refresh ka wait na karna pade.
    if (row?.productId) {
      setProducts((prev) => prev.map((p) => (
        String(p.id) === String(row.productId)
          ? { ...p, currentStock: (p.currentStock || 0) + row.qty }
          : p
      )));
      refreshProducts();
    }
  }, [losses, refreshProducts]);

  // ── Settings actions ────────────────────────────────────────────────────
  const addCategory = useCallback(async (name) => {
    const trimmed = name.trim();
    if (!trimmed || categories.includes(trimmed)) return;
    const settings = await api.post("/api/settings/categories", { name: trimmed });
    setCategories(settings.categories);
  }, [categories]);

  const removeCategory = useCallback(async (name) => {
    const settings = await api.delete(`/api/settings/categories/${encodeURIComponent(name)}`);
    if (settings) setCategories(settings.categories);
    else setCategories((prev) => prev.filter((c) => c !== name));
  }, []);

  const updateAppSettings = useCallback(async (settings) => {
    const next = await api.put("/api/settings/app-settings", settings);
    setAppSettings(next.appSettings);
  }, []);

  const updateInvoiceSettings = useCallback(async (settings) => {
    const { logo, ...rest } = settings;
    const payload = { ...rest };
    if (logo !== undefined) {
      if (logo) {
        await saveLogoToIDB(logo);
        payload.logo = "__local__";
      } else {
        payload.logo = "";
      }
    }
    const next = await api.put("/api/settings/invoice-settings", payload);
    setInvoiceSettings((prev) => ({ ...next.invoiceSettings, logo: logo !== undefined ? logo : prev.logo }));
  }, []);

  // ── Backup Restore ──────────────────────────────────────────────────────
  const restoreBackup = useCallback(async (data) => {
    if (!uid) throw new Error("Not logged in");
    if (data.settings?.invoiceSettings?.logo && data.settings.invoiceSettings.logo !== "__local__") {
      try {
        await saveLogoToIDB(data.settings.invoiceSettings.logo);
      } catch {
        /* ignore */
      }
    }
    await api.post("/api/backup/restore", data);
    await refreshAll();
  }, [uid, refreshAll]);

  return {
    loading,
    products, alerts, stats, sales, allInvoices, posStats,
    addProduct, updateProduct, deleteProduct, stockIn, stockOut,
    completeSale, recordSale, createManualInvoice, updateInvoice, deleteInvoice,
    customers, addCustomer, updateCustomer, deleteCustomer, receivePayment, addBalanceAdjustment, addCustomerAdvance,
    categories, addCategory, removeCategory,
    appSettings, updateAppSettings,
    invoiceSettings, updateInvoiceSettings,
    restoreBackup,
    suppliers, addSupplier, updateSupplier, deleteSupplier,
    supplierTransactions, addSupplierTransaction, deleteSupplierTransaction, addSupplierPurchase,
    supplierPurchases, fetchSupplierPurchases, updateSupplierPurchase, paySupplierInvoice, addSupplierAdvance,
    expenses, addExpense, updateExpense, deleteExpense,
    expenseCategories, addExpenseCategory, removeExpenseCategory,
    expenseCategoryColors, setExpenseCategoryColor,
    returns, addReturn, deleteReturn,
    losses, addLoss, deleteLoss,
  };
}
