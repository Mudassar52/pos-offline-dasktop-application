import db, { uuid, nowIso } from "../db.js";
import { mapInvoice, num } from "../utils/mappers.js";
import { getNextInvoiceNumber } from "./settings.js";
import { bumpCustomerStats, getAdvanceBalance } from "./customers.js";

function tableFor(source) {
  return source === "manual" ? "manual_invoices" : "sales";
}

export function list() {
  const rows = db.prepare("SELECT * FROM manual_invoices ORDER BY created_at DESC").all();
  return rows.map((r) => mapInvoice(r, "manual"));
}

// POST /api/invoices/manual - create a manual invoice
export const createManual = db.transaction((data) => {
  const counter = getNextInvoiceNumber();

  // Agar yeh udaar invoice hai aur customer ka pehle se diya hua advance
  // balance maujood hai, to wo yahan khud-ba-khud is bill par lag jata
  // hai — jitni zaroorat ho utna hi (jo bache wo udaar hi rehta hai).
  let advanceBalanceUsed = 0;
  if (data.paymentMode === "udaar" && data.customerId) {
    const available = getAdvanceBalance(data.customerId);
    const manualAdvance = Number(data.advance) || 0;
    const stillOwed = Math.max(0, (Number(data.total) || 0) - manualAdvance);
    advanceBalanceUsed = Math.min(available, stillOwed);
  }

  const totalPaidNow = (Number(data.advance) || 0) + advanceBalanceUsed;
  const paymentStatus = data.paymentMode === "udaar"
    ? (totalPaidNow >= Number(data.total) ? "paid" : totalPaidNow > 0 ? "partial" : "udaar")
    : "paid";
  const payments = [];
  if (data.paymentMode === "udaar" && Number(data.advance) > 0) {
    payments.push({ amount: Number(data.advance), date: nowIso(), note: "Advance at sale" });
  }
  if (advanceBalanceUsed > 0) {
    payments.push({ amount: advanceBalanceUsed, date: nowIso(), note: "Advance Balance Used" });
  }

  // Deduct stock for inventory items
  for (const item of data.items || []) {
    if (item.productId) {
      db.prepare(
        "UPDATE products SET current_stock = MAX(0, current_stock - ?), updated_at = ? WHERE id = ?"
      ).run(Number(item.qty) || 0, nowIso(), item.productId);
    }
  }

  const extra = {
    customerName: data.customerName || "",
    customerPhone: data.customerPhone || "",
    customerAddress: data.customerAddress || "",
    notes: data.notes || "",
    subtotal: Number(data.subtotal) || 0,
    discount: Number(data.discount) || 0,
    tax: Number(data.tax) || 0,
    discountPercent: Number(data.discountPercent) || 0,
    taxPercent: Number(data.taxPercent) || 0,
    totalCost: Number(data.totalCost) || 0,
    grossProfit: Number(data.grossProfit) || 0,
    profitMargin: Number(data.profitMargin) || 0,
  };

  const id = uuid();
  const createdAt = data.createdAt || nowIso();
  db.prepare(
    `INSERT INTO manual_invoices
      (id, invoice_number, customer_id, items, total, advance, payment_mode, payment_status, payments,
       previous_udaar, show_previous_udaar_on_invoice, extra, created_at, updated_at)
     VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)`
  ).run(
    id,
    counter,
    data.customerId || null,
    JSON.stringify(data.items || []),
    Number(data.total) || 0,
    Number(data.advance) || 0,
    data.paymentMode || null,
    paymentStatus,
    JSON.stringify(payments),
    Number(data.previousUdaar) || 0,
    data.showPreviousUdaarOnInvoice ? 1 : 0,
    JSON.stringify(extra),
    createdAt,
    createdAt
  );

  if (data.customerId) {
    bumpCustomerStats(data.customerId, 1, Number(data.total) || 0, nowIso());
  }

  return mapInvoice(db.prepare("SELECT * FROM manual_invoices WHERE id = ?").get(id), "manual");
});

// PUT /api/invoices/:id?source=pos|manual
export function update(id, source, data) {
  const table = tableFor(source);
  const row = db.prepare(`SELECT * FROM ${table} WHERE id = ?`).get(id);
  if (!row) {
    const err = new Error("Invoice not found");
    err.status = 404;
    throw err;
  }
  const prevExtra = JSON.parse(row.extra || "{}");
  const extra = {
    ...prevExtra,
    customerName: data.customerName ?? prevExtra.customerName ?? "",
    customerPhone: data.customerPhone ?? prevExtra.customerPhone ?? "",
    customerAddress: data.customerAddress ?? prevExtra.customerAddress ?? "",
    notes: data.notes ?? prevExtra.notes ?? "",
    subtotal: data.subtotal !== undefined ? Number(data.subtotal) : prevExtra.subtotal ?? 0,
    discount: data.discount !== undefined ? Number(data.discount) : prevExtra.discount ?? 0,
    tax: data.tax !== undefined ? Number(data.tax) : prevExtra.tax ?? 0,
    discountPercent: data.discountPercent !== undefined ? Number(data.discountPercent) : prevExtra.discountPercent ?? 0,
    taxPercent: data.taxPercent !== undefined ? Number(data.taxPercent) : prevExtra.taxPercent ?? 0,
    totalCost: data.totalCost !== undefined ? Number(data.totalCost) : prevExtra.totalCost ?? 0,
    grossProfit: data.grossProfit !== undefined ? Number(data.grossProfit) : prevExtra.grossProfit ?? 0,
    profitMargin: data.profitMargin !== undefined ? Number(data.profitMargin) : prevExtra.profitMargin ?? 0,
  };

  db.prepare(
    `UPDATE ${table} SET
       items = ?, total = ?, advance = ?, payment_mode = ?, payment_status = ?,
       customer_id = ?, invoice_number = ?, extra = ?, updated_at = ?
     WHERE id = ?`
  ).run(
    data.items ? JSON.stringify(data.items) : row.items,
    data.total !== undefined ? Number(data.total) : row.total,
    data.advance !== undefined ? Number(data.advance) : row.advance,
    data.paymentMode || row.payment_mode,
    data.paymentStatus || row.payment_status,
    data.customerId || row.customer_id,
    data.invoiceNumber !== undefined ? data.invoiceNumber : row.invoice_number,
    JSON.stringify(extra),
    nowIso(),
    id
  );

  return mapInvoice(db.prepare(`SELECT * FROM ${table} WHERE id = ?`).get(id), source);
}

// DELETE /api/invoices/:id?source=pos|manual - delete and restore stock/stats
export const remove = db.transaction((id, source) => {
  const table = tableFor(source);
  const inv = db.prepare(`SELECT * FROM ${table} WHERE id = ?`).get(id);
  if (!inv) {
    const err = new Error("Invoice not found");
    err.status = 404;
    throw err;
  }
  db.prepare(`DELETE FROM ${table} WHERE id = ?`).run(id);

  const items = JSON.parse(inv.items || "[]");
  for (const item of items) {
    if (item.productId) {
      db.prepare("UPDATE products SET current_stock = current_stock + ?, updated_at = ? WHERE id = ?").run(
        Number(item.qty) || 0,
        nowIso(),
        item.productId
      );
    }
  }

  if (inv.customer_id) {
    bumpCustomerStats(inv.customer_id, -1, -num(inv.total), null);
  }
});

// POST /api/invoices/receive-payment
export const receivePayment = db.transaction(({ allocations = [], date, note }) => {
  for (const alloc of allocations) {
    const payAmt = Number(alloc.amount);
    if (!payAmt || payAmt <= 0 || alloc.invoiceId === "bulk") continue;
    const table = tableFor(alloc.source);
    const inv = db.prepare(`SELECT * FROM ${table} WHERE id = ?`).get(alloc.invoiceId);
    if (!inv) continue;

    const existing = JSON.parse(inv.payments || "[]");
    const newPayments = [...existing, { amount: payAmt, date, note: note || "" }];
    const advInPayments = newPayments
      .filter((p) => p.note && p.note.includes("Advance at sale"))
      .reduce((s, p) => s + p.amount, 0);
    const otherPmts = newPayments
      .filter((p) => !p.note || !p.note.includes("Advance at sale"))
      .reduce((s, p) => s + p.amount, 0);
    const standAloneAdv = advInPayments > 0 ? 0 : num(inv.advance);
    const totalPaidAmt = advInPayments + otherPmts + standAloneAdv;
    const newStatus = totalPaidAmt >= num(inv.total) ? "paid" : totalPaidAmt > 0 ? "partial" : "udaar";

    const clearsPreviousUdaar = newStatus === "paid" && inv.show_previous_udaar_on_invoice && num(inv.previous_udaar) > 0;

    db.prepare(
      `UPDATE ${table} SET
          payments = ?,
          payment_status = ?,
          previous_udaar_cleared = ?,
          previous_udaar_cleared_at = ?,
          updated_at = ?
       WHERE id = ?`
    ).run(
      JSON.stringify(newPayments),
      newStatus,
      clearsPreviousUdaar ? 1 : inv.previous_udaar_cleared,
      clearsPreviousUdaar ? nowIso() : inv.previous_udaar_cleared_at,
      nowIso(),
      alloc.invoiceId
    );
  }
  return { success: true };
});

export default { list, createManual, update, remove, receivePayment };
