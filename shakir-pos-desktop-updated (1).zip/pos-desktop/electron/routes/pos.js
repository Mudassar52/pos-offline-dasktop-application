import db, { uuid, nowIso } from "../db.js";
import { mapInvoice } from "../utils/mappers.js";
import { getNextInvoiceNumber } from "./settings.js";
import { bumpCustomerStats, getAdvanceBalance } from "./customers.js";

export function list() {
  const rows = db.prepare("SELECT * FROM sales ORDER BY created_at DESC").all();
  return rows.map((r) => mapInvoice(r, "pos"));
}

// POST /api/pos/sales - record a new POS sale
export const recordSale = db.transaction((sale) => {
  const counter = getNextInvoiceNumber();

  // Agar yeh udaar sale hai aur customer ka pehle se diya hua advance
  // balance maujood hai, to wo yahan khud-ba-khud is bill par lag jata
  // hai — jitni zaroorat ho utna hi (jo bache wo udaar hi rehta hai).
  let advanceBalanceUsed = 0;
  if (sale.paymentMode === "udaar" && sale.customerId) {
    const available = getAdvanceBalance(sale.customerId);
    const manualAdvance = Number(sale.advance) || 0;
    const stillOwed = Math.max(0, (Number(sale.total) || 0) - manualAdvance);
    advanceBalanceUsed = Math.min(available, stillOwed);
  }

  const totalPaidNow = (Number(sale.advance) || 0) + advanceBalanceUsed;
  const paymentStatus = sale.paymentMode === "udaar"
    ? (totalPaidNow >= Number(sale.total) ? "paid" : totalPaidNow > 0 ? "partial" : "udaar")
    : "paid";
  const payments = [];
  if (sale.paymentMode === "udaar" && Number(sale.advance) > 0) {
    payments.push({ amount: Number(sale.advance), date: nowIso(), note: "Advance at sale" });
  }
  if (advanceBalanceUsed > 0) {
    payments.push({ amount: advanceBalanceUsed, date: nowIso(), note: "Advance Balance Used" });
  }

  const extra = {
    customerName: sale.customerName || "",
    customerPhone: sale.customerPhone || "",
    customerAddress: sale.customerAddress || "",
    notes: sale.notes || "",
    subtotal: Number(sale.subtotal) || 0,
    discount: Number(sale.discount) || 0,
    tax: Number(sale.tax) || 0,
    discountPercent: Number(sale.discountPercent) || 0,
    taxPercent: Number(sale.taxPercent) || 0,
    totalCost: Number(sale.totalCost) || 0,
    grossProfit: Number(sale.grossProfit) || 0,
    profitMargin: Number(sale.profitMargin) || 0,
  };

  const id = uuid();
  const createdAt = sale.createdAt || nowIso();
  db.prepare(
    `INSERT INTO sales
      (id, invoice_number, customer_id, items, total, advance, payment_mode, payment_status, payments,
       previous_udaar, show_previous_udaar_on_invoice, extra, created_at, updated_at)
     VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)`
  ).run(
    id,
    counter,
    sale.customerId || null,
    JSON.stringify(sale.items || []),
    Number(sale.total) || 0,
    Number(sale.advance) || 0,
    sale.paymentMode || null,
    paymentStatus,
    JSON.stringify(payments),
    Number(sale.previousUdaar) || 0,
    sale.showPreviousUdaarOnInvoice ? 1 : 0,
    JSON.stringify(extra),
    createdAt,
    createdAt
  );

  if (sale.customerId) {
    bumpCustomerStats(sale.customerId, 1, Number(sale.total) || 0, nowIso());
  }

  return mapInvoice(db.prepare("SELECT * FROM sales WHERE id = ?").get(id), "pos");
});

// POST /api/pos/complete-sale - deduct stock (used in checkout workflow)
export const completeSale = db.transaction((items = []) => {
  for (const { productId, qty } of items) {
    const row = db.prepare("SELECT current_stock FROM products WHERE id = ?").get(productId);
    if (!row || Number(row.current_stock) < qty) {
      return { success: false };
    }
  }
  for (const { productId, qty } of items) {
    db.prepare("UPDATE products SET current_stock = current_stock - ?, updated_at = ? WHERE id = ?").run(
      qty,
      nowIso(),
      productId
    );
  }
  return { success: true };
});

// DELETE /api/pos/:id - delete a POS sale and restore stock
export const deleteSale = db.transaction((id) => {
  const sale = db.prepare("SELECT * FROM sales WHERE id = ?").get(id);
  if (!sale) {
    const err = new Error("Sale not found");
    err.status = 404;
    throw err;
  }
  db.prepare("DELETE FROM sales WHERE id = ?").run(id);

  const items = JSON.parse(sale.items || "[]");
  for (const item of items) {
    if (item.productId) {
      db.prepare("UPDATE products SET current_stock = current_stock + ?, updated_at = ? WHERE id = ?").run(
        Number(item.qty) || 0,
        nowIso(),
        item.productId
      );
    }
  }

  if (sale.customer_id) {
    bumpCustomerStats(sale.customer_id, -1, -Number(sale.total), null);
  }
});

export default { list, recordSale, completeSale, deleteSale };
