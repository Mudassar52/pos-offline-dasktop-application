// ── Export helpers (CSV + Print) ─────────────────────────────────────────
// CSV mein UTF-8 BOM lagta hai taake Excel mein Urdu text sahi khule.
const esc = (v) => {
  const s = v === null || v === undefined ? "" : String(v);
  return /[",\n\r]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
};

export function toCSV(headers, rows) {
  return [headers.map(esc).join(","), ...rows.map((r) => r.map(esc).join(","))].join("\r\n");
}

export function downloadCSV(filename, headers, rows) {
  const blob = new Blob(["\uFEFF" + toCSV(headers, rows)], { type: "text/csv;charset=utf-8;" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename.endsWith(".csv") ? filename : `${filename}.csv`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

const escHtml = (v) => String(v ?? "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");

// Simple, clean printable table (browser print dialog → printer ya "Save as PDF").
export function printTable({ title, subtitle = "", headers, rows, aligns = [], footer = null }) {
  const win = window.open("", "_blank");
  if (!win) return;
  const th = headers.map((h, i) => `<th style="text-align:${aligns[i] || "left"}">${escHtml(h)}</th>`).join("");
  const body = rows
    .map((r) => `<tr>${r.map((c, i) => `<td style="text-align:${aligns[i] || "left"}">${escHtml(c)}</td>`).join("")}</tr>`)
    .join("");
  const foot = footer ? `<tfoot><tr>${footer.map((c, i) => `<td style="text-align:${aligns[i] || "left"}">${escHtml(c)}</td>`).join("")}</tr></tfoot>` : "";
  win.document.write(`<!DOCTYPE html><html><head><meta charset="utf-8"><title>${escHtml(title)}</title><style>
    *{box-sizing:border-box;margin:0;padding:0} body{font-family:Arial,sans-serif;font-size:11px;color:#1e293b;padding:20px}
    h1{font-size:18px;font-weight:800} p.sub{color:#64748b;margin:3px 0 14px;font-size:11px}
    table{width:100%;border-collapse:collapse} th{background:#f1f5f9;font-size:10px;text-transform:uppercase;color:#475569;padding:7px 8px;border-bottom:2px solid #cbd5e1}
    td{padding:6px 8px;border-bottom:1px solid #e2e8f0} tfoot td{font-weight:800;background:#f1f5f9;border-top:2px solid #94a3b8}
    @media print{body{padding:0}} </style></head><body>
    <h1>${escHtml(title)}</h1><p class="sub">${escHtml(subtitle)} · Printed ${new Date().toLocaleString("en-PK")}</p>
    <table><thead><tr>${th}</tr></thead><tbody>${body}</tbody>${foot}</table></body></html>`);
  win.document.close();
  win.focus();
  setTimeout(() => win.print(), 250);
}
