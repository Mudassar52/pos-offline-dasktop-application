export function getStockStatus(product) {
  if (product.currentStock <= 0) return "out";
  if (product.currentStock <= product.lowStockAlertQty) return "low";
  return "ok";
}

// ── Expiry Tracking ─────────────────────────────────────────────────────
// expiryDate "YYYY-MM-DD". Status: none (date nahi) | ok | soon (soonDays ke
// andar) | expired. Sirf unhi products par alert jin ka stock > 0 hai.
export const EXPIRY_SOON_DAYS = 30;
export function getExpiryInfo(product, soonDays = EXPIRY_SOON_DAYS, now = new Date()) {
  if (!product?.expiryDate) return { status: "none", daysLeft: null };
  const exp = new Date(String(product.expiryDate).slice(0, 10) + "T23:59:59");
  const daysLeft = Math.ceil((exp - now) / 86400000) - 1;
  if (exp < now) return { status: "expired", daysLeft: Math.floor((exp - now) / 86400000) };
  if (daysLeft <= soonDays) return { status: "soon", daysLeft };
  return { status: "ok", daysLeft };
}

export function buildStockAlerts(products) {
  const alerts = [];
  products.forEach((p) => {
    const exp = getExpiryInfo(p);
    if ((p.currentStock || 0) > 0 && exp.status === "expired") {
      alerts.push({ id: `exp-${p.id}`, type: "expired", productId: p.id, title: "Expired Stock", message: `${p.name} expire ho chuka hai (${p.currentStock} units abhi stock mein).`, time: "Just now" });
    } else if ((p.currentStock || 0) > 0 && exp.status === "soon") {
      alerts.push({ id: `expsoon-${p.id}`, type: "expiring", productId: p.id, title: "Expiring Soon", message: `${p.name} ${exp.daysLeft <= 0 ? "aaj" : exp.daysLeft + " din mein"} expire hoga (${p.currentStock} units).`, time: "Just now" });
    }
    const status = getStockStatus(p);
    if (status === "out") {
      alerts.push({
        id: `out-${p.id}`,
        type: "out",
        productId: p.id,
        title: "Out of Stock",
        message: `${p.name} is out of stock.`,
        time: "Just now",
      });
    } else if (status === "low") {
      alerts.push({
        id: `low-${p.id}`,
        type: "low",
        productId: p.id,
        title: "Low Stock Alert",
        message: `${p.name} has only ${p.currentStock} units left (alert at ${p.lowStockAlertQty}).`,
        time: "Just now",
      });
    }
  });
  return alerts;
}

export function formatCurrency(value) {
  return `Rs ${Number(value).toLocaleString(undefined, { minimumFractionDigits: 0, maximumFractionDigits: 2 })}`;
}

// Invoice par abhi kitna udhaar (due) baaqi hai — customer ke advance-at-sale
// aur baad ki payments dono ko hisaab mein rakhta hai. Customer profile
// ke totals isi formula se banti hain, is liye return karte waqt bhi
// yahi formula use hoti hai taake "paid" vs "udhaar" ka faisla sahi ho.
export function getInvoiceDue(inv) {
  const payments = inv.payments || [];
  const advanceInPayments = payments.filter((p) => p.note && p.note.includes("Advance at sale")).reduce((s, p) => s + (p.amount || 0), 0);
  const otherPayments = payments.filter((p) => !p.note || !p.note.includes("Advance at sale")).reduce((s, p) => s + (p.amount || 0), 0);
  const advance = advanceInPayments > 0 ? 0 : (inv.advance || 0);
  const totalPaidIncAdv = advanceInPayments + otherPayments + advance;
  return Math.max(0, (inv.total || 0) - totalPaidIncAdv);
}

export const emptyProductForm = {
  name: "",
  category: "Electronics",
  salePrice: "",
  costPrice: "",
  saleShopPrice: "",
  lowStockAlertQty: "",
  currentStock: "",
  ctn: "",
  expiryDate: "",
  batchNo: "",
};
