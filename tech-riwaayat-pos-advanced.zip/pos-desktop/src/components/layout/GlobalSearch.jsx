import { useState, useEffect, useMemo, useRef } from "react";

const PAGES = [
  { label: "Products", hint: "Inventory, stock, expiry" }, { label: "Point of Sale", hint: "Nayi sale" }, { label: "Invoices", hint: "Sab invoices" },
  { label: "Customers", hint: "Customers, udaar, ledger" }, { label: "Suppliers", hint: "Suppliers, ledger, purchase returns" },
  { label: "Reports", hint: "48 reports" }, { label: "Expenses", hint: "Kharche" }, { label: "Order Returns", hint: "Customer returns" },
  { label: "Loss Management", hint: "Nuqsan" }, { label: "Settings", hint: "Settings aur backup" },
];
const money = (v) => `Rs ${Number(v || 0).toLocaleString("en-PK")}`;
const GROUP_STYLE = { Pages: "bg-slate-100 text-slate-600", Products: "bg-blue-100 text-blue-600", Customers: "bg-emerald-100 text-emerald-600", Suppliers: "bg-amber-100 text-amber-600", Invoices: "bg-violet-100 text-violet-600", Expenses: "bg-rose-100 text-rose-600" };

/**
 * Global Search / Command Palette — Ctrl+K (ya Cmd+K) se kahin se bhi khulta
 * hai. Pages, products, customers, suppliers, invoices aur expenses ek
 * sath search; ↑↓ se chunein, Enter se kholein, Esc se band.
 */
export default function GlobalSearch({ setActiveNav, products = [], customers = [], allInvoices = [], suppliers = [], expenses = [] }) {
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState("");
  const [idx, setIdx] = useState(0);
  const inputRef = useRef(null);

  useEffect(() => {
    const onKey = (e) => {
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "k") { e.preventDefault(); setOpen((v) => !v); }
      else if (e.key === "/" && !/INPUT|TEXTAREA|SELECT/.test(document.activeElement?.tagName || "") && !document.activeElement?.isContentEditable) { e.preventDefault(); setOpen(true); }
    };
    document.addEventListener("keydown", onKey);
    return () => document.removeEventListener("keydown", onKey);
  }, []);
  useEffect(() => { if (open) { setQuery(""); setIdx(0); setTimeout(() => inputRef.current?.focus(), 30); } }, [open]);

  const custName = useMemo(() => new Map(customers.map((c) => [String(c.id), c.name])), [customers]);

  const results = useMemo(() => {
    const q = query.trim().toLowerCase();
    const go = (nav) => () => { setActiveNav?.(nav); setOpen(false); };
    if (!q) return PAGES.map((p) => ({ group: "Pages", key: `pg-${p.label}`, title: p.label, sub: p.hint, run: go(p.label) }));
    const out = [];
    PAGES.filter((p) => p.label.toLowerCase().includes(q) || p.hint.toLowerCase().includes(q)).forEach((p) => out.push({ group: "Pages", key: `pg-${p.label}`, title: p.label, sub: p.hint, run: go(p.label) }));
    products.filter((p) => `${p.name} ${p.category} ${p.batchNo || ""}`.toLowerCase().includes(q)).slice(0, 6).forEach((p) => out.push({ group: "Products", key: `p-${p.id}`, title: p.name, sub: `${p.category || "—"} · Stock ${p.currentStock ?? 0}`, right: money(p.salePrice), run: go("Products") }));
    customers.filter((c) => `${c.name} ${c.phone || ""} ${c.city || ""}`.toLowerCase().includes(q)).slice(0, 6).forEach((c) => out.push({ group: "Customers", key: `c-${c.id}`, title: c.name, sub: `${c.phone || "—"} · ${c.city || "—"}`, run: go("Customers") }));
    suppliers.filter((s) => `${s.name} ${s.phone || ""} ${s.city || ""}`.toLowerCase().includes(q)).slice(0, 5).forEach((s) => out.push({ group: "Suppliers", key: `s-${s.id}`, title: s.name, sub: `${s.phone || "—"} · ${s.city || "—"}`, run: go("Suppliers") }));
    allInvoices.filter((i) => `${i.invoiceNumber || ""} ${i.customerName || custName.get(String(i.customerId)) || ""}`.toLowerCase().includes(q)).slice(0, 5).forEach((i) => out.push({ group: "Invoices", key: `i-${i.id}`, title: `#${String(i.invoiceNumber || i.id).padStart(3, "0")}`, sub: i.customerName || custName.get(String(i.customerId)) || "Walk-in", right: money(i.total), run: go("Invoices") }));
    expenses.filter((e) => `${e.category} ${e.description || ""}`.toLowerCase().includes(q)).slice(0, 4).forEach((e) => out.push({ group: "Expenses", key: `e-${e.id}`, title: e.category, sub: e.description || "—", right: money(e.amount), run: go("Expenses") }));
    return out;
  }, [query, products, customers, suppliers, allInvoices, expenses, custName, setActiveNav]);

  useEffect(() => setIdx(0), [query]);
  useEffect(() => { document.querySelector(`[data-gs-idx="${idx}"]`)?.scrollIntoView({ block: "nearest" }); }, [idx]);

  const onKeyDown = (e) => {
    if (e.key === "Escape") setOpen(false);
    else if (e.key === "ArrowDown") { e.preventDefault(); setIdx((i) => Math.min(results.length - 1, i + 1)); }
    else if (e.key === "ArrowUp") { e.preventDefault(); setIdx((i) => Math.max(0, i - 1)); }
    else if (e.key === "Enter") { e.preventDefault(); results[idx]?.run(); }
  };

  let lastGroup = null;
  return (
    <>
      <button onClick={() => setOpen(true)} className="hidden sm:flex items-center gap-2 bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 hover:border-blue-300 hover:bg-white transition-all text-sm text-slate-400 w-56" title="Global search (Ctrl+K)">
        <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="#94A3B8" strokeWidth="2" strokeLinecap="round"><circle cx="11" cy="11" r="8" /><path d="m21 21-4.35-4.35" /></svg>
        <span className="flex-1 text-left">Search anything...</span>
        <kbd className="text-[10px] font-bold bg-white border border-slate-200 rounded px-1.5 py-0.5 text-slate-400">Ctrl K</kbd>
      </button>
      <button onClick={() => setOpen(true)} className="sm:hidden p-2 rounded-lg hover:bg-slate-100 text-slate-500" aria-label="Search">
        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><circle cx="11" cy="11" r="8" /><path d="m21 21-4.35-4.35" /></svg>
      </button>

      {open && (
        <div className="fixed inset-0 z-[60] flex items-start justify-center pt-[12vh] px-4 bg-black/50 backdrop-blur-sm" onMouseDown={(e) => { if (e.target === e.currentTarget) setOpen(false); }}>
          <div className="bg-white rounded-2xl w-full max-w-xl shadow-2xl overflow-hidden" role="dialog" aria-label="Global search">
            <div className="flex items-center gap-3 px-4 py-3.5 border-b border-slate-100">
              <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#94A3B8" strokeWidth="2" strokeLinecap="round"><circle cx="11" cy="11" r="8" /><path d="m21 21-4.35-4.35" /></svg>
              <input ref={inputRef} value={query} onChange={(e) => setQuery(e.target.value)} onKeyDown={onKeyDown} placeholder="Products, customers, suppliers, invoices, pages..." className="flex-1 outline-none text-sm text-slate-800 placeholder:text-slate-400" />
              <kbd className="text-[10px] font-bold bg-slate-100 rounded px-1.5 py-0.5 text-slate-400">Esc</kbd>
            </div>
            <div className="max-h-[55vh] overflow-y-auto py-1.5">
              {results.length === 0 ? <p className="px-4 py-8 text-center text-sm text-slate-400">Kuch nahi mila — "{query}"</p> : results.map((r, i) => {
                const header = r.group !== lastGroup; lastGroup = r.group;
                return (
                  <div key={r.key}>
                    {header && <p className="px-4 pt-2.5 pb-1 text-[10px] font-bold uppercase tracking-wider text-slate-400">{r.group}</p>}
                    <button data-gs-idx={i} onClick={r.run} onMouseEnter={() => setIdx(i)} className={`w-full flex items-center gap-3 px-4 py-2.5 text-left transition-colors ${i === idx ? "bg-blue-50" : ""}`}>
                      <span className={`w-7 h-7 rounded-lg flex items-center justify-center text-[11px] font-black flex-shrink-0 ${GROUP_STYLE[r.group]}`}>{r.group[0]}</span>
                      <span className="min-w-0 flex-1"><span className="block text-sm font-semibold text-slate-800 truncate">{r.title}</span><span className="block text-xs text-slate-400 truncate">{r.sub}</span></span>
                      {r.right && <span className="text-xs font-bold text-slate-500 flex-shrink-0">{r.right}</span>}
                      {i === idx && <kbd className="text-[10px] font-bold bg-white border border-slate-200 rounded px-1.5 py-0.5 text-slate-400">↵</kbd>}
                    </button>
                  </div>
                );
              })}
            </div>
            <div className="px-4 py-2 border-t border-slate-100 bg-slate-50/60 flex gap-4 text-[10px] text-slate-400 font-semibold"><span>↑↓ chunein</span><span>↵ kholein</span><span>/ ya Ctrl+K kahin se</span></div>
          </div>
        </div>
      )}
    </>
  );
}
