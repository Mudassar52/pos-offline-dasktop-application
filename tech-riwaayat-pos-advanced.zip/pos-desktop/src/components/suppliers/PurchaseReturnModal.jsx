import { useState, useMemo } from "react";
import Modal from "../ui/Modal";
import Button from "../ui/Button";
import ProductSelector from "../common/ProductSelector";

const money = (v) => "Rs " + Number(v || 0).toLocaleString("en-PK");
const today = () => new Date().toISOString().slice(0, 10);
const REASONS = ["Damaged", "Expired", "Wrong item", "Quality issue", "Excess stock", "Other"];
let rid = 0;
const newRow = () => ({ rowId: `r${++rid}`, product: null, name: "", price: "", qty: "" });

/**
 * Purchase Return — supplier ko maal wapis. Invoice select karein to sirf
 * usi invoice ka bacha hua maal wapis ho sakta hai; invoice ke bina "general"
 * return bhi ho sakta hai. Save par: stock kam, ledger mein DEBIT entry,
 * aur (invoice ho to) us invoice ka baaki kam.
 */
export default function PurchaseReturnModal({ purchases = [], returns = [], products = [], defaultPurchaseId = null, onClose, onSave }) {
  const [purchaseId, setPurchaseId] = useState(defaultPurchaseId || "");
  const purchase = purchases.find((p) => p.id === purchaseId) || null;

  // Invoice ke items aur har ek mein se kitna abhi wapis ho sakta hai
  const returnable = useMemo(() => {
    if (!purchase) return [];
    const prev = new Map();
    returns.filter((r) => r.purchaseId === purchase.id).forEach((r) =>
      r.items.forEach((it) => { const k = it.productId || it.productName; prev.set(k, (prev.get(k) || 0) + it.qty); })
    );
    return purchase.items.map((it) => ({ ...it, max: Math.max(0, it.qty - (prev.get(it.productId || it.productName) || 0)) }));
  }, [purchase, returns]);

  const [qtys, setQtys] = useState({});
  const [rows, setRows] = useState([newRow()]);
  const [date, setDate] = useState(today());
  const [reason, setReason] = useState("Damaged");
  const [note, setNote] = useState("");
  const [error, setError] = useState("");
  const [saving, setSaving] = useState(false);

  const items = purchase
    ? returnable.filter((it) => Number(qtys[it.id]) > 0).map((it) => ({ productId: it.productId, productName: it.productName, qty: Number(qtys[it.id]), purchasePrice: it.purchasePrice }))
    : rows.filter((r) => (r.product || r.name.trim()) && Number(r.qty) > 0 && Number(r.price) > 0)
        .map((r) => ({ productId: r.product?.id || null, productName: r.product?.name || r.name.trim(), qty: Number(r.qty), purchasePrice: Number(r.price) }));
  const total = items.reduce((s, i) => s + i.qty * i.purchasePrice, 0);
  const applied = purchase ? Math.min(total, purchase.remaining) : 0;

  const submit = async () => {
    if (items.length === 0) { setError("Kam az kam ek product ki quantity likhein"); return; }
    try {
      setSaving(true);
      await onSave({ purchaseId: purchase?.id || null, items, reason, note, date: new Date(date).toISOString() });
      onClose();
    } catch (e) {
      setError(e.message || "Return save nahi ho saka");
    } finally { setSaving(false); }
  };

  const inputCls = "w-full px-3 py-2 rounded-xl border border-slate-200 text-sm outline-none focus:border-blue-400";
  return (
    <Modal open onClose={onClose} title="Purchase Return (Maal Wapis)" subtitle="Supplier ko wapis kiya hua maal — stock kam hoga, ledger mein Debit lagega" size="lg"
      footer={<><Button variant="secondary" onClick={onClose}>Cancel</Button><Button variant="danger" loading={saving} onClick={submit}>Return Save Karein</Button></>}>
      <div className="space-y-4">
        <div>
          <label className="block text-xs font-semibold text-slate-500 mb-1">Kis Purchase Invoice se?</label>
          <select value={purchaseId} onChange={(e) => { setPurchaseId(e.target.value); setQtys({}); setError(""); }} className={inputCls}>
            <option value="">— Invoice ke bina (general return) —</option>
            {purchases.map((p) => <option key={p.id} value={p.id}>#{p.invoiceNumber} · {new Date(p.date).toLocaleDateString("en-PK")} · {money(p.total)} (baaki {money(p.remaining)})</option>)}
          </select>
        </div>

        {purchase ? (
          <div className="border border-slate-100 rounded-xl overflow-hidden">
            <div className="grid grid-cols-12 gap-2 px-3 py-2 bg-slate-50 text-[10px] font-bold uppercase text-slate-400">
              <span className="col-span-5">Product</span><span className="col-span-2 text-right">Rate</span><span className="col-span-2 text-right">Wapis ho sakta</span><span className="col-span-3 text-right">Return Qty</span>
            </div>
            {returnable.map((it) => (
              <div key={it.id} className="grid grid-cols-12 gap-2 px-3 py-2 items-center border-t border-slate-50 text-sm">
                <span className="col-span-5 font-semibold text-slate-700 truncate">{it.productName}</span>
                <span className="col-span-2 text-right text-slate-500">{money(it.purchasePrice)}</span>
                <span className="col-span-2 text-right text-slate-500">{it.max}</span>
                <input type="number" min="0" max={it.max} disabled={it.max === 0} value={qtys[it.id] || ""} placeholder="0"
                  onChange={(e) => { setQtys((q) => ({ ...q, [it.id]: Math.min(it.max, Number(e.target.value) || 0) || "" })); setError(""); }}
                  className="col-span-3 px-2 py-1.5 rounded-lg border border-slate-200 text-sm text-right outline-none focus:border-blue-400 disabled:bg-slate-50" />
              </div>
            ))}
          </div>
        ) : (
          <div className="space-y-2.5">
            {rows.map((r, idx) => (
              <div key={r.rowId} className="bg-slate-50 rounded-xl p-3 border border-slate-100 space-y-2">
                <div className="flex items-center justify-between"><p className="text-xs font-bold text-slate-500">Product #{idx + 1}</p>
                  {rows.length > 1 && <button onClick={() => setRows((p) => p.filter((x) => x.rowId !== r.rowId))} className="text-xs text-red-500 font-bold">Hataein</button>}</div>
                <ProductSelector products={products} selectedProduct={r.product}
                  onSelect={(p) => setRows((prev) => prev.map((x) => x.rowId === r.rowId ? { ...x, product: p, price: x.price || String(p?.costPrice || p?.stockPrice || "") } : x))}
                  allowFreeText freeTextValue={r.name} onFreeTextChange={(v) => setRows((prev) => prev.map((x) => x.rowId === r.rowId ? { ...x, name: v } : x))}
                  placeholder="Product search karein..." />
                <div className="grid grid-cols-2 gap-2">
                  <div><label className="block text-[11px] font-semibold text-slate-500 mb-1">Purchase Rate</label><input type="number" min="0" value={r.price} onChange={(e) => setRows((p) => p.map((x) => x.rowId === r.rowId ? { ...x, price: e.target.value } : x))} className={inputCls} /></div>
                  <div><label className="block text-[11px] font-semibold text-slate-500 mb-1">Quantity</label><input type="number" min="0" value={r.qty} onChange={(e) => setRows((p) => p.map((x) => x.rowId === r.rowId ? { ...x, qty: e.target.value } : x))} className={inputCls} /></div>
                </div>
              </div>
            ))}
            <button onClick={() => setRows((p) => [...p, newRow()])} className="text-xs font-bold text-blue-600 hover:underline">+ Aur product</button>
          </div>
        )}

        <div className="grid grid-cols-2 gap-3">
          <div><label className="block text-xs font-semibold text-slate-500 mb-1">Date</label><input type="date" value={date} onChange={(e) => setDate(e.target.value)} className={inputCls} /></div>
          <div><label className="block text-xs font-semibold text-slate-500 mb-1">Wajah</label>
            <select value={reason} onChange={(e) => setReason(e.target.value)} className={inputCls}>{REASONS.map((r) => <option key={r}>{r}</option>)}</select></div>
        </div>
        <div><label className="block text-xs font-semibold text-slate-500 mb-1">Note (optional)</label><input value={note} onChange={(e) => setNote(e.target.value)} className={inputCls} /></div>

        <div className="bg-violet-50 rounded-xl p-3.5 text-sm space-y-1">
          <div className="flex justify-between"><span className="text-slate-600">Return Total</span><b className="text-violet-700">{money(total)}</b></div>
          {purchase && <div className="flex justify-between text-xs"><span className="text-slate-500">Is invoice ke baaki se kata jayega</span><b>{money(applied)}</b></div>}
          {total - applied > 0 && <div className="flex justify-between text-xs"><span className="text-slate-500">Supplier ke paas hamara credit (agli purchase par lagega)</span><b className="text-amber-600">{money(total - applied)}</b></div>}
        </div>
        {error && <p className="text-xs font-semibold text-red-500">{error}</p>}
      </div>
    </Modal>
  );
}
