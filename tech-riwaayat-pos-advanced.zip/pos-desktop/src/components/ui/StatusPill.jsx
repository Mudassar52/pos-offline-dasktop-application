import { StatusBadge } from "./Badge";
export default function StatusPill({ s }) { return <StatusBadge status={s} />; }
