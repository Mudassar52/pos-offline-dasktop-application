/** Shimmer placeholder. <Skeleton className="h-4 w-24" /> */
export function Skeleton({ className = "" }) {
  return <div className={`animate-pulse bg-slate-200/70 rounded-md ${className}`} />;
}
export default Skeleton;

export function SkeletonRows({ rows = 6, cols = 5 }) {
  return Array.from({ length: rows }).map((_, r) => (
    <tr key={r} className="border-b border-slate-50">
      {Array.from({ length: cols }).map((__, c) => (
        <td key={c} className="px-4 py-3.5"><Skeleton className={`h-3.5 ${c === 0 ? "w-20" : c % 2 ? "w-full max-w-[140px]" : "w-16"}`} /></td>
      ))}
    </tr>
  ));
}

export function SkeletonCards({ count = 4 }) {
  return (
    <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
      {Array.from({ length: count }).map((_, i) => (
        <div key={i} className="bg-white rounded-2xl border border-slate-100 p-4 space-y-3">
          <Skeleton className="w-9 h-9 rounded-xl" /><Skeleton className="h-5 w-24" /><Skeleton className="h-3 w-16" />
        </div>
      ))}
    </div>
  );
}

export function PageSkeleton() {
  return (
    <div className="flex-1 overflow-hidden p-6 space-y-5">
      <div className="space-y-2"><Skeleton className="h-6 w-40" /><Skeleton className="h-3.5 w-64" /></div>
      <SkeletonCards />
      <div className="bg-white rounded-2xl border border-slate-100 overflow-hidden"><table className="w-full"><tbody><SkeletonRows rows={7} cols={5} /></tbody></table></div>
    </div>
  );
}
