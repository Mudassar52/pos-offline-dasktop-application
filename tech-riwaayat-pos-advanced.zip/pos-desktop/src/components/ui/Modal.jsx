import { useEffect } from "react";

const SIZES = { sm: "max-w-sm", md: "max-w-lg", lg: "max-w-2xl", xl: "max-w-4xl", "2xl": "max-w-6xl" };

/**
 * Reusable Modal — Esc se band, backdrop click se band, scroll-lock, sticky
 * header/footer. Har naye modal ko isi par banayein.
 *
 * <Modal open onClose title="..." subtitle="..." size="lg" footer={<Button/>}>…</Modal>
 */
export default function Modal({ open = true, onClose, title, subtitle, icon, size = "md", footer, children, closeOnBackdrop = true, bodyClassName = "" }) {
  useEffect(() => {
    if (!open) return;
    const onKey = (e) => { if (e.key === "Escape") onClose?.(); };
    document.addEventListener("keydown", onKey);
    return () => document.removeEventListener("keydown", onKey);
  }, [open, onClose]);

  if (!open) return null;
  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm"
      onMouseDown={(e) => { if (closeOnBackdrop && e.target === e.currentTarget) onClose?.(); }}
      role="dialog"
      aria-modal="true"
    >
      <div className={`bg-white rounded-2xl w-full ${SIZES[size] || SIZES.md} shadow-2xl max-h-[92vh] flex flex-col`}>
        {(title || onClose) && (
          <div className="flex items-center justify-between gap-3 px-5 py-4 border-b border-slate-100 flex-shrink-0">
            <div className="flex items-center gap-3 min-w-0">
              {icon && <div className="w-9 h-9 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center flex-shrink-0">{icon}</div>}
              <div className="min-w-0">
                <h2 className="font-bold text-slate-800 truncate">{title}</h2>
                {subtitle && <p className="text-xs text-slate-400 truncate">{subtitle}</p>}
              </div>
            </div>
            {onClose && (
              <button onClick={onClose} aria-label="Close" className="w-8 h-8 flex items-center justify-center rounded-lg hover:bg-slate-100 text-slate-400 flex-shrink-0">
                <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d="M18 6L6 18M6 6l12 12" /></svg>
              </button>
            )}
          </div>
        )}
        <div className={`flex-1 overflow-y-auto scrollbar-hide px-5 py-4 ${bodyClassName}`}>{children}</div>
        {footer && <div className="px-5 py-3.5 border-t border-slate-100 flex-shrink-0 flex items-center justify-end gap-2">{footer}</div>}
      </div>
    </div>
  );
}
