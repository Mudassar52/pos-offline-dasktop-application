const TONES = {
  green: "bg-emerald-100 text-emerald-700",
  red: "bg-red-100 text-red-700",
  amber: "bg-amber-100 text-amber-700",
  blue: "bg-blue-100 text-blue-700",
  violet: "bg-violet-100 text-violet-700",
  slate: "bg-slate-100 text-slate-600",
};
const DOTS = { green: "bg-emerald-500", red: "bg-red-500", amber: "bg-amber-500", blue: "bg-blue-500", violet: "bg-violet-500", slate: "bg-slate-400" };

/** <Badge tone="green" dot>Paid</Badge> */
export default function Badge({ tone = "slate", dot = false, children, className = "" }) {
  return (
    <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold whitespace-nowrap ${TONES[tone] || TONES.slate} ${className}`}>
      {dot && <span className={`w-1.5 h-1.5 rounded-full ${DOTS[tone] || DOTS.slate}`} />}
      {children}
    </span>
  );
}

// Common domain mappings — ek jagah, har page par same rang.
export const STATUS_TONE = { paid: "green", partial: "amber", udaar: "red", ok: "green", low: "amber", out: "red", expired: "red", soon: "amber" };
export function StatusBadge({ status, label }) {
  const text = label || { paid: "Paid", partial: "Partial", udaar: "Udaar", ok: "In Stock", low: "Low Stock", out: "Out of Stock", expired: "Expired", soon: "Expiring Soon" }[status] || status;
  return <Badge tone={STATUS_TONE[status] || "slate"} dot>{text}</Badge>;
}
