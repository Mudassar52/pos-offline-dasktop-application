import { useEffect, useMemo, useState } from "react";
import { api } from "../../api/client";
import DateRangePicker from "../common/DateRangePicker";
import DataTable from "../ui/DataTable";
import { Skeleton } from "../ui/Skeleton";
import { REPORTS, REPORT_GROUPS } from "../../utils/reportCatalog";

const PRESETS = [
  { key: "today", label: "Today" }, { key: "week", label: "7 Days" }, { key: "month", label: "This Month" },
  { key: "lastMonth", label: "Last Month" }, { key: "year", label: "This Year" }, { key: "all", label: "All Time" },
];
const iso = (d) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
function presetRange(key) {
  const n = new Date();
  switch (key) {
    case "today": return { from: iso(n), to: iso(n) };
    case "week": return { from: iso(new Date(n.getTime() - 6 * 86400000)), to: iso(n) };
    case "month": return { from: iso(new Date(n.getFullYear(), n.getMonth(), 1)), to: iso(n) };
    case "lastMonth": return { from: iso(new Date(n.getFullYear(), n.getMonth() - 1, 1)), to: iso(new Date(n.getFullYear(), n.getMonth(), 0)) };
    case "year": return { from: iso(new Date(n.getFullYear(), 0, 1)), to: iso(n) };
    default: return { from: null, to: null };
  }
}
const TONES = { blue: "text-blue-600", green: "text-emerald-600", red: "text-red-600", amber: "text-amber-600", violet: "text-violet-600", slate: "text-slate-800" };
const sel = "px-3 py-2 rounded-xl border border-slate-200 bg-white text-xs font-semibold text-slate-700 outline-none focus:border-blue-400 max-w-[190px]";

export default function ReportCenter({ invoices, products, customers, expenses, losses, returns, suppliers, supplierTransactions, supplierReturns, expenseCategories = [] }) {
  const [reportId, setReportId] = useState("daily-sales");
  const [q, setQ] = useState("");
  const [preset, setPreset] = useState("month");
  const [range, setRange] = useState(presetRange("month"));
  const [f, setF] = useState({ customerId: "", category: "", status: "", source: "", supplierId: "", expcat: "", days: "" });
  const [purchases, setPurchases] = useState(null);
  const [navOpen, setNavOpen] = useState(false);

  // Purchase invoices (items ke saath) — sirf jab zaroorat ho tab load hoti hain.
  useEffect(() => {
    let live = true;
    api.get("/api/supplier-purchases").then((d) => live && setPurchases(d || [])).catch(() => live && setPurchases([]));
    return () => { live = false; };
  }, [supplierTransactions.length, supplierReturns.length]);

  const report = REPORTS.find((r) => r.id === reportId) || REPORTS[0];
  const filters = report.filters || [];
  const categories = useMemo(() => [...new Set(products.map((p) => p.category).filter(Boolean))].sort(), [products]);
  const loadingData = report.needsPurchases && purchases === null;

  const ctx = useMemo(() => ({ invoices, products, customers, expenses, losses, returns, suppliers, supplierTransactions, supplierReturns, supplierPurchases: purchases || [] }),
    [invoices, products, customers, expenses, losses, returns, suppliers, supplierTransactions, supplierReturns, purchases]);

  const effective = useMemo(() => {
    const days = f.days !== "" ? f.days : report.daysDefault ?? "";
    return { ...f, days, from: filters.includes("date") ? range.from : null, to: filters.includes("date") ? range.to : null };
  }, [f, range, filters, report.daysDefault]);

  const built = useMemo(() => {
    if (loadingData) return null;
    try { return report.build(ctx, effective); } catch (e) { console.error("Report error", report.id, e); return { columns: [], rows: [], error: e.message }; }
  }, [report, ctx, effective, loadingData]);

  const grouped = useMemo(() => {
    const ql = q.trim().toLowerCase();
    return REPORT_GROUPS.map((g) => ({ ...g, items: REPORTS.filter((r) => r.group === g.id && (!ql || r.title.toLowerCase().includes(ql) || r.desc.toLowerCase().includes(ql))) })).filter((g) => g.items.length);
  }, [q]);

  const setFilter = (k, v) => setF((p) => ({ ...p, [k]: v }));
  const resetFilters = () => { setF({ customerId: "", category: "", status: "", source: "", supplierId: "", expcat: "", days: "" }); setPreset("month"); setRange(presetRange("month")); };
  const activeCount = ["customerId", "category", "status", "source", "supplierId", "expcat"].filter((k) => f[k] && filters.includes({ customerId: "customer", supplierId: "supplier" }[k] || k)).length;
  const subtitle = [filters.includes("date") ? (range.from ? `${range.from} → ${range.to}` : "All time") : null, report.desc].filter(Boolean).join(" · ");

  return (
    <div className="flex flex-col lg:flex-row gap-4 p-4 sm:p-6 min-h-0">
      {/* Report list */}
      <aside className="lg:w-72 flex-shrink-0">
        <button onClick={() => setNavOpen((v) => !v)} className="lg:hidden w-full flex items-center justify-between bg-white border border-slate-200 rounded-xl px-4 py-3 mb-2 text-sm font-bold text-slate-700">
          <span>{report.title}</span><span className="text-xs text-blue-600">{navOpen ? "Close" : `Change (${REPORTS.length})`}</span>
        </button>
        <div className={`${navOpen ? "block" : "hidden"} lg:block bg-white rounded-2xl border border-slate-100 shadow-sm overflow-hidden lg:sticky lg:top-0`}>
          <div className="p-3 border-b border-slate-100">
            <input value={q} onChange={(e) => setQ(e.target.value)} placeholder={`Search ${REPORTS.length} reports...`} className="w-full px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-sm outline-none focus:border-blue-300 focus:bg-white" />
          </div>
          <div className="max-h-[70vh] overflow-y-auto scrollbar-hide py-1">
            {grouped.length === 0 && <p className="p-4 text-xs text-slate-400 text-center">Koi report nahi mili</p>}
            {grouped.map((g) => (
              <div key={g.id} className="mb-1">
                <p className="px-4 pt-3 pb-1 text-[10px] font-bold uppercase tracking-wider text-slate-400">{g.icon} {g.label} <span className="text-slate-300">({g.items.length})</span></p>
                {g.items.map((r) => (
                  <button key={r.id} onClick={() => { setReportId(r.id); setNavOpen(false); }}
                    className={`w-full text-left px-4 py-2 text-[13px] transition-colors ${r.id === reportId ? "bg-blue-50 text-blue-700 font-bold border-l-[3px] border-blue-600" : "text-slate-600 hover:bg-slate-50 border-l-[3px] border-transparent"}`}>
                    {r.title}
                  </button>
                ))}
              </div>
            ))}
          </div>
        </div>
      </aside>

      {/* Report viewer */}
      <section className="flex-1 min-w-0 space-y-3">
        <div>
          <h2 className="text-lg font-black text-slate-800">{report.title}</h2>
          <p className="text-xs text-slate-400 mt-0.5">{report.desc}</p>
        </div>

        {/* Filters */}
        <div className="bg-white rounded-2xl border border-slate-100 shadow-sm p-3 flex flex-wrap items-center gap-2">
          {filters.includes("date") && (
            <>
              <div className="flex bg-slate-100 rounded-xl p-0.5">
                {PRESETS.map((p) => (
                  <button key={p.key} onClick={() => { setPreset(p.key); setRange(presetRange(p.key)); }}
                    className={`px-2.5 py-1.5 rounded-lg text-[11px] font-bold transition-all ${preset === p.key ? "bg-white text-blue-600 shadow-sm" : "text-slate-500 hover:text-slate-700"}`}>{p.label}</button>
                ))}
              </div>
              <DateRangePicker value={range} onChange={(r) => { setRange(r); setPreset("custom"); }} />
            </>
          )}
          {filters.includes("customer") && (
            <select className={sel} value={f.customerId} onChange={(e) => setFilter("customerId", e.target.value)}>
              <option value="">All Customers</option>{customers.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
            </select>
          )}
          {filters.includes("supplier") && (
            <select className={sel} value={f.supplierId} onChange={(e) => setFilter("supplierId", e.target.value)}>
              <option value="">All Suppliers</option>{suppliers.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}
            </select>
          )}
          {filters.includes("category") && (
            <select className={sel} value={f.category} onChange={(e) => setFilter("category", e.target.value)}>
              <option value="">All Categories</option>{categories.map((c) => <option key={c}>{c}</option>)}
            </select>
          )}
          {filters.includes("expcat") && (
            <select className={sel} value={f.expcat} onChange={(e) => setFilter("expcat", e.target.value)}>
              <option value="">All Expense Types</option>{expenseCategories.map((c) => <option key={c}>{c}</option>)}
            </select>
          )}
          {filters.includes("status") && (
            <select className={sel} value={f.status} onChange={(e) => setFilter("status", e.target.value)}>
              <option value="">All Status</option><option value="paid">Paid</option><option value="partial">Partial</option><option value="udaar">Udaar</option>
            </select>
          )}
          {filters.includes("source") && (
            <select className={sel} value={f.source} onChange={(e) => setFilter("source", e.target.value)}>
              <option value="">POS + Manual</option><option value="pos">POS only</option><option value="manual">Manual only</option>
            </select>
          )}
          {filters.includes("days") && (
            <label className="flex items-center gap-2 text-xs font-semibold text-slate-500">{report.daysLabel || "Days"}
              <input type="number" min="0" value={effective.days} onChange={(e) => setFilter("days", e.target.value)} className="w-20 px-2.5 py-2 rounded-xl border border-slate-200 text-sm text-slate-700 outline-none focus:border-blue-400" />
            </label>
          )}
          <div className="flex-1" />
          {(activeCount > 0 || preset !== "month") && <button onClick={resetFilters} className="text-xs font-bold text-slate-500 hover:text-slate-800">Reset filters</button>}
        </div>

        {/* Summary */}
        {built?.summary?.length > 0 && (
          <div className={`grid grid-cols-2 ${built.summary.length > 3 ? "lg:grid-cols-4" : "lg:grid-cols-3"} gap-3`}>
            {built.summary.map((s) => (
              <div key={s.label} className="bg-white rounded-2xl border border-slate-100 p-4">
                <p className="text-[11px] text-slate-400">{s.label}</p>
                <p className={`text-lg font-black mt-1 ${TONES[s.tone] || TONES.slate}`}>{s.value}</p>
              </div>
            ))}
          </div>
        )}
        {loadingData && <div className="grid grid-cols-3 gap-3"><Skeleton className="h-16" /><Skeleton className="h-16" /><Skeleton className="h-16" /></div>}

        {built?.error ? (
          <div className="bg-red-50 text-red-600 text-sm rounded-xl p-4">Report banane mein masla: {built.error}</div>
        ) : (
          <DataTable
            key={report.id}
            columns={built?.columns || []}
            rows={built?.rows || []}
            rowKey={(r) => r.id ?? r.key ?? r.name ?? JSON.stringify(r)}
            loading={loadingData}
            initialSort={built?.initialSort}
            title={report.title}
            subtitle={subtitle}
            exportName={report.id}
            persistKey={`report_${report.id}`}
            pageSize={20}
            selectable
            bulkActions={[
              { label: "Export selected (CSV)", onClick: (rows, clear) => { exportSelected(report, built, rows); clear(); } },
            ]}
            searchPlaceholder="Is report mein search..."
            emptyTitle="Is filter ke liye koi data nahi"
            emptyHint="Date range ya filters badal kar dekhein."
          />
        )}
      </section>
    </div>
  );
}

import { downloadCSV } from "../../utils/exportUtils";
function exportSelected(report, built, rows) {
  const cols = built.columns;
  downloadCSV(`${report.id}-selected`, cols.map((c) => c.label), rows.map((r) => cols.map((c) => {
    const v = c.accessor ? c.accessor(r) : r[c.key];
    return c.format ? c.format(v) : v ?? "";
  })));
}
