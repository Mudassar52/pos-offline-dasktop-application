import { PageSkeleton } from "./components/ui/Skeleton";
import { useState, useEffect, useCallback, lazy, Suspense } from "react";
import { localAuth, licenseApi } from "./api/client";

import Sidebar from "./components/layout/Sidebar";
import Topbar from "./components/layout/Topbar";
import LoginView from "./components/auth/LoginView";
import LicenseGate from "./components/license/LicenseGate";
import { useProducts } from "./hooks/useProducts";

// ── Lazy-load each page ──────────────────────────────────────────────────
// Previously every page (Dashboard, Products, POS, Invoices, Reports,
// Customers, Settings, Profile) was bundled together into one huge ~1MB+
// JS file that had to be downloaded, parsed, and executed before the app
// could even show the login screen — and again on every full page reload.
// Splitting each page into its own chunk means only the page you're
// actually looking at gets loaded, which noticeably speeds up first load
// and reduces the "whole app feels slow" effect. Pages are cached by the
// browser after their first visit, so switching back to an already-opened
// page is instant.
const DashboardView = lazy(() => import("./components/dashboard/DashboardView"));
const ProductsView = lazy(() => import("./components/products/ProductsView"));
const POSView = lazy(() => import("./components/pos/POSView"));
const InvoiceView = lazy(() => import("./components/invoices/InvoiceView"));
const ReportsView = lazy(() => import("./components/reports/ReportsView"));
const CustomersView = lazy(() => import("./components/customers/CustomersView"));
const SuppliersView = lazy(() => import("./components/suppliers/SuppliersView"));
const ExpensesView = lazy(() => import("./components/expenses/ExpensesView"));
const OrderReturnsView = lazy(() => import("./components/returns/OrderReturnsView"));
const LossManagementView = lazy(() => import("./components/losses/LossManagementView"));
const SettingsView = lazy(() => import("./components/settings/SettingsView"));
const UserProfileView = lazy(() => import("./components/profile/UserProfileView"));

function PageLoader() {
  return <PageSkeleton />;
}

export default function App() {
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [activeNav, setActiveNav] = useState("Dashboard");
  const [mobileSidebar, setMobileSidebar] = useState(false);
  const [currentUser, setCurrentUser] = useState(null);
  const [authLoading, setAuthLoading] = useState(true);
  // License (Supabase) — state electron/license.js se aati hai. Jab tak
  // "active" na ho, na login dikhta hai na data load hota hai.
  const [license, setLicense] = useState(null);
  const licenseActive = license?.state === "active";
  const refreshLicense = useCallback(() => { licenseApi.refresh().then(setLicense).catch(() => {}); }, []);

  const {
    loading: dataLoading,
    products, alerts, stats, allInvoices,
    addProduct, updateProduct, deleteProduct, stockIn, stockOut,
    posStats, completeSale, recordSale,
    createManualInvoice, updateInvoice, deleteInvoice,
    customers, addCustomer, updateCustomer, deleteCustomer, receivePayment, addBalanceAdjustment, addCustomerAdvance,
    categories, addCategory, removeCategory,
    appSettings, updateAppSettings,
    invoiceSettings, updateInvoiceSettings,
    restoreBackup,
    suppliers, addSupplier, updateSupplier, deleteSupplier,
    supplierTransactions, addSupplierTransaction, deleteSupplierTransaction, addSupplierPurchase,
    supplierPurchases, fetchSupplierPurchases, updateSupplierPurchase, paySupplierInvoice, addSupplierAdvance,
    supplierReturns, addSupplierReturn, deleteSupplierReturn, addSupplierOpening, deleteSupplierPurchase,
    expenses, addExpense, updateExpense, deleteExpense,
    expenseCategories, addExpenseCategory, removeExpenseCategory,
    expenseCategoryColors, setExpenseCategoryColor,
    returns, addReturn, deleteReturn,
    losses, addLoss, deleteLoss,
  } = useProducts(licenseActive ? currentUser?.uid : null);

  useEffect(() => {
    let off = () => {};
    licenseApi.status().then(setLicense).catch(() => setLicense({ state: "unactivated", message: "Could not read the license status." }));
    off = licenseApi.onChange(setLicense);
    // Window dobara focus ho to bhi check (app din bhar khuli rehti hai)
    const onFocus = () => licenseApi.refresh().then(setLicense).catch(() => {});
    window.addEventListener("focus", onFocus);
    return () => { off(); window.removeEventListener("focus", onFocus); };
  }, []);

  // ── Local session (no internet, no external auth — just this computer) ──
  // Session sirf localStorage mein rakhte hain taake app dobara khulne par
  // user ko login karna na pare. Password kabhi bhi localStorage mein save
  // nahi hota — sirf bcrypt-hashed form mein SQLite ke andar rehta hai.
  useEffect(() => {
    try {
      const saved = localStorage.getItem("pos_current_user");
      if (saved) {
        setCurrentUser(JSON.parse(saved));
        setActiveNav("Dashboard");
      }
    } catch {
      /* ignore corrupt session */
    }
    setAuthLoading(false);
  }, []);

  const persistUser = (user) => {
    setCurrentUser(user);
    if (user) localStorage.setItem("pos_current_user", JSON.stringify(user));
    else localStorage.removeItem("pos_current_user");
  };

  // ── Auth handlers ───────────────────────────────────────────────────────
  const handleEmailLogin = async (username, password) => {
    const user = await localAuth.login(username, password);
    persistUser({ ...user, uid: user.id, loginMethod: "email" });
    setActiveNav("Dashboard");
  };

  const handleLogout = async () => {
    persistUser(null);
    setActiveNav("Dashboard");
  };

  // ── Loading screen ──────────────────────────────────────────────────────
  if (authLoading || !license || (licenseActive && currentUser && dataLoading)) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50">
        <div className="flex flex-col items-center gap-4">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-blue-600 to-blue-700 flex items-center justify-center shadow-lg shadow-blue-200">
            <svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4" />
            </svg>
          </div>
          <div className="w-5 h-5 border-2 border-blue-500 border-t-transparent rounded-full animate-spin" />
          {currentUser && <p className="text-sm text-slate-500">Loading your data...</p>}
        </div>
      </div>
    );
  }

  // ── License gate ────────────────────────────────────────────────────────
  if (!licenseActive) {
    return (
      <LicenseGate
        license={license}
        onActivate={async (key) => setLicense(await licenseApi.activate(key))}
        onRefresh={async () => { const s = await licenseApi.refresh(); setLicense(s); return s; }}
        onBackup={() => licenseApi.backupDb()}
      />
    );
  }

  // ── Login screen ────────────────────────────────────────────────────────
  if (!currentUser) {
    return <LoginView onEmailLogin={handleEmailLogin} shopName={license.shopName} />;
  }

  const pageConfig = {
    Dashboard: { title: "Dashboard", subtitle: `Welcome back, ${currentUser.name} 👋` },
    Products: { title: "Products", subtitle: "Manage inventory & stock alerts" },
    "Order Returns": { title: "Order Returns", subtitle: "Wapis aaya hua maal record karein" },
    "Loss Management": { title: "Loss Management", subtitle: "Damaged / expired / chori ka hisaab rakhein" },
    "Point of Sale": { title: "Point of Sale", subtitle: "Sell products & process orders" },
    Invoices: { title: "Invoices", subtitle: "Invoice banayein aur manage karein" },
    Reports: { title: "Reports", subtitle: "Sales aur revenue ki detailed reports" },
    Customers: { title: "Customers", subtitle: "Manage your customer directory" },
    Settings: { title: "Settings", subtitle: "Customize categories and app settings" },
    Profile: { title: "My Profile", subtitle: "Manage your account and preferences" },
  };
  const config = pageConfig[activeNav] || pageConfig.Dashboard;

  return (
    <div className="flex h-screen bg-slate-50 font-sans overflow-hidden">
      <Sidebar
        sidebarOpen={sidebarOpen}
        mobileSidebar={mobileSidebar}
        setMobileSidebar={setMobileSidebar}
        activeNav={activeNav}
        setActiveNav={setActiveNav}
        setSidebarOpen={setSidebarOpen}
        appSettings={appSettings}
      />
      <main className="flex-1 flex flex-col min-w-0 overflow-hidden">
        {(license.notice || (license.daysLeft != null && license.daysLeft <= 7)) && (
          <div className="px-4 py-1.5 text-[12px] font-semibold bg-amber-50 text-amber-700 border-b border-amber-200 flex flex-wrap gap-x-4">
            {license.daysLeft != null && license.daysLeft <= 7 && (
              <span>⚠ Your license {license.daysLeft <= 0 ? "expires today" : `expires in ${license.daysLeft} day${license.daysLeft === 1 ? "" : "s"}`} — please renew it.</span>
            )}
            {license.notice && <span>{license.notice}</span>}
          </div>
        )}
        <Topbar
          title={config.title}
          subtitle={config.subtitle}
          onMenuClick={() => setMobileSidebar(true)}
          alerts={alerts}
          currentUser={currentUser}
          onLogout={handleLogout}
          setActiveNav={setActiveNav}
          products={products}
          customers={customers}
          allInvoices={allInvoices}
          suppliers={suppliers}
          expenses={expenses}
          license={license}
          onLicenseExpire={refreshLicense}
        />
        {activeNav === "Products" ? (
          <Suspense fallback={<PageLoader />}>
            <ProductsView
              products={products} stats={stats}
              addProduct={addProduct} updateProduct={updateProduct}
              deleteProduct={deleteProduct} stockIn={stockIn} stockOut={stockOut}
              categories={categories}
            />
          </Suspense>
        ) : activeNav === "Order Returns" ? (
          <Suspense fallback={<PageLoader />}>
            <OrderReturnsView products={products} customers={customers} allInvoices={allInvoices} returns={returns} addReturn={addReturn} deleteReturn={deleteReturn} />
          </Suspense>
        ) : activeNav === "Loss Management" ? (
          <Suspense fallback={<PageLoader />}>
            <LossManagementView products={products} losses={losses} addLoss={addLoss} deleteLoss={deleteLoss} />
          </Suspense>
        ) : activeNav === "Point of Sale" ? (
          <Suspense fallback={<PageLoader />}>
            <POSView
              products={products} posStats={posStats}
              completeSale={completeSale} recordSale={recordSale}
              customers={customers}
              categories={categories}
              invoices={allInvoices}
              invoiceSettings={invoiceSettings}
            />
          </Suspense>
        ) : activeNav === "Invoices" ? (
          <Suspense fallback={<PageLoader />}>
            <InvoiceView
              products={products}
              invoices={allInvoices}
              onCreateInvoice={createManualInvoice}
              onUpdateInvoice={updateInvoice}
              onDeleteInvoice={deleteInvoice}
              onReduceStock={completeSale}
              customers={customers}
              invoiceSettings={invoiceSettings}
            />
          </Suspense>
        ) : activeNav === "Reports" ? (
          <Suspense fallback={<PageLoader />}>
            <ReportsView invoices={allInvoices} products={products} invoiceSettings={invoiceSettings} customers={customers} expenses={expenses} losses={losses} returns={returns} suppliers={suppliers} supplierTransactions={supplierTransactions} supplierReturns={supplierReturns} expenseCategories={expenseCategories} loading={dataLoading} />
          </Suspense>
        ) : activeNav === "Customers" ? (
          <Suspense fallback={<PageLoader />}>
            <CustomersView customers={customers} addCustomer={addCustomer} updateCustomer={updateCustomer} deleteCustomer={deleteCustomer} allInvoices={allInvoices} onReceivePayment={receivePayment} onCreateInvoice={createManualInvoice} onReduceStock={completeSale} onUpdateInvoice={updateInvoice} onDeleteInvoice={deleteInvoice} invoiceSettings={invoiceSettings} products={products} onAddAdvance={addCustomerAdvance} />
          </Suspense>
        ) : activeNav === "Suppliers" ? (
          <Suspense fallback={<PageLoader />}>
            <SuppliersView
              suppliers={suppliers}
              transactions={supplierTransactions}
              addSupplier={addSupplier}
              updateSupplier={updateSupplier}
              deleteSupplier={deleteSupplier}
              addSupplierTransaction={addSupplierTransaction}
              deleteSupplierTransaction={deleteSupplierTransaction}
              addSupplierPurchase={addSupplierPurchase}
              updateSupplierPurchase={updateSupplierPurchase}
              paySupplierInvoice={paySupplierInvoice}
              addSupplierAdvance={addSupplierAdvance}
              returns={supplierReturns}
              loading={dataLoading}
              addSupplierReturn={addSupplierReturn}
              deleteSupplierReturn={deleteSupplierReturn}
              addSupplierOpening={addSupplierOpening}
              deleteSupplierPurchase={deleteSupplierPurchase}
              purchases={supplierPurchases}
              fetchSupplierPurchases={fetchSupplierPurchases}
              products={products}
              invoiceSettings={invoiceSettings}
            />
          </Suspense>
        ) : activeNav === "Expenses" ? (
          <Suspense fallback={<PageLoader />}>
            <ExpensesView
              expenses={expenses}
              expenseCategories={expenseCategories}
              expenseCategoryColors={expenseCategoryColors}
              addExpense={addExpense}
              updateExpense={updateExpense}
              deleteExpense={deleteExpense}
              addExpenseCategory={addExpenseCategory}
              removeExpenseCategory={removeExpenseCategory}
              setExpenseCategoryColor={setExpenseCategoryColor}
            />
          </Suspense>
        ) : activeNav === "Settings" ? (
          <Suspense fallback={<PageLoader />}>
            <SettingsView categories={categories} addCategory={addCategory} removeCategory={removeCategory} appSettings={appSettings} updateAppSettings={updateAppSettings} invoiceSettings={invoiceSettings} updateInvoiceSettings={updateInvoiceSettings} allInvoices={allInvoices} products={products} customers={customers} onRestoreBackup={restoreBackup} suppliers={suppliers} supplierTransactions={supplierTransactions} expenses={expenses} expenseCategories={expenseCategories} expenseCategoryColors={expenseCategoryColors} returns={returns} losses={losses} />
          </Suspense>
        ) : activeNav === "Profile" ? (
          <Suspense fallback={<PageLoader />}>
            <UserProfileView
              appSettings={appSettings}
              currentUser={currentUser}
              onLogout={handleLogout}
              products={products}
              allInvoices={allInvoices}
              license={license}
              onLicenseExpire={refreshLicense}
            />
          </Suspense>
        ) : (
          <Suspense fallback={<PageLoader />}>
            <DashboardView products={products} allInvoices={allInvoices} customers={customers} expenses={expenses} losses={losses} />
          </Suspense>
        )}
      </main>
    </div>
  );
}
