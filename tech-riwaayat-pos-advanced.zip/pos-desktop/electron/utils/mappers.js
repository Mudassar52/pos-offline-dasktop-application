export const num = (v) => (v === null || v === undefined ? 0 : Number(v));

function parseJson(v, fallback) {
  if (v === null || v === undefined) return fallback;
  if (typeof v !== "string") return v;
  try {
    return JSON.parse(v);
  } catch {
    return fallback;
  }
}

export function mapProduct(row) {
  if (!row) return null;
  return {
    id: row.id,
    name: row.name || "",
    category: row.category || "Others",
    salePrice: num(row.sale_price),
    stockPrice: num(row.stock_price),
    costPrice: num(row.cost_price),
    saleShopPrice: num(row.sale_shop_price),
    lowStockAlertQty: num(row.low_stock_alert_qty),
    currentStock: num(row.current_stock),
    ctn: num(row.ctn),
    expiryDate: row.expiry_date || null,
    batchNo: row.batch_no || "",
  };
}

export function mapCustomer(row) {
  if (!row) return null;
  return {
    id: row.id,
    name: row.name,
    phone: row.phone,
    email: row.email || "",
    city: row.city || "",
    totalOrders: row.total_orders || 0,
    totalSpent: num(row.total_spent),
    lastOrder: row.last_order,
    adjustments: parseJson(row.adjustments, []),
  };
}

export function mapInvoice(row, source) {
  if (!row) return null;
  return {
    id: row.id,
    source,
    invoiceNumber: row.invoice_number,
    customerId: row.customer_id,
    items: parseJson(row.items, []),
    total: num(row.total),
    advance: num(row.advance),
    paymentMode: row.payment_mode,
    paymentStatus: row.payment_status,
    payments: parseJson(row.payments, []),
    previousUdaar: num(row.previous_udaar),
    showPreviousUdaarOnInvoice: !!row.show_previous_udaar_on_invoice,
    previousUdaarCleared: !!row.previous_udaar_cleared,
    previousUdaarClearedAt: row.previous_udaar_cleared_at,
    createdAt: row.created_at,
    updatedAt: row.updated_at,
    ...(parseJson(row.extra, {}) || {}),
  };
}

export function mapSupplier(row) {
  if (!row) return null;
  return {
    id: row.id,
    name: row.name,
    phone: row.phone || "",
    city: row.city || "",
    notes: row.notes || "",
    createdAt: row.created_at,
    updatedAt: row.updated_at,
  };
}

export function mapSupplierTransaction(row) {
  if (!row) return null;
  return {
    id: row.id,
    supplierId: row.supplier_id,
    type: row.type, // 'purchase' | 'payment' | 'return' | 'opening'
    amount: num(row.amount),
    description: row.description || "",
    purchaseId: row.purchase_id || null,
    returnId: row.return_id || null,
    date: row.date,
    createdAt: row.created_at,
  };
}

export function mapExpense(row) {
  if (!row) return null;
  return {
    id: row.id,
    category: row.category,
    amount: num(row.amount),
    description: row.description || "",
    date: row.date,
    createdAt: row.created_at,
    updatedAt: row.updated_at,
  };
}

export function mapSettings(row) {
  if (!row) {
    return {
      appSettings: { appName: "Tech Riwaayat POS", tagline: "Pro Dashboard" },
      invoiceSettings: { ownerName: "", businessName: "", phone: "", address: "", logo: "" },
      categories: [],
      expenseCategories: ["Rent", "Utilities", "Salaries", "Transport", "Maintenance", "Other"],
      expenseCategoryColors: {},
      invoiceCounter: 0,
    };
  }
  return {
    appSettings: parseJson(row.app_settings, { appName: "Tech Riwaayat POS", tagline: "Pro Dashboard" }),
    invoiceSettings: parseJson(row.invoice_settings, {}),
    categories: parseJson(row.categories, []),
    expenseCategories: parseJson(row.expense_categories, ["Rent", "Utilities", "Salaries", "Transport", "Maintenance", "Other"]),
    expenseCategoryColors: parseJson(row.expense_category_colors, {}),
    invoiceCounter: row.invoice_counter,
  };
}

export function mapReturn(row) {
  if (!row) return null;
  const price = num(row.price);
  const qty = num(row.qty);
  return {
    id: row.id,
    productId: row.product_id || null,
    productName: row.product_name || "",
    qty,
    price,
    unitCost: num(row.unit_cost),
    amount: price * qty,
    reason: row.reason || "",
    note: row.note || "",
    // Agar ye return kisi invoice se link ho kar banaya gaya tha:
    invoiceId: row.invoice_id || null,
    invoiceSource: row.invoice_source || null,
    invoiceNumber: row.invoice_number ?? null,
    customerId: row.customer_id || null,
    customerName: row.customer_name || "",
    itemIndex: row.item_index ?? null,
    // true = is return ne invoice ka total khud kam kar diya (invoice us
    // waqt pura paid tha). false = sirf record hua, invoice/udhaar nahi chheda.
    deductedFromInvoice: !!row.deducted_from_invoice,
    date: row.date,
    createdAt: row.created_at,
  };
}

export function mapLoss(row) {
  if (!row) return null;
  return {
    id: row.id,
    productId: row.product_id || null,
    productName: row.product_name || "",
    qty: num(row.qty),
    unitCost: num(row.unit_cost),
    value: num(row.value),
    reason: row.reason || "",
    note: row.note || "",
    date: row.date,
    createdAt: row.created_at,
  };
}

export function mapSupplierPurchaseItem(row) {
  if (!row) return null;
  return {
    id: row.id,
    purchaseId: row.purchase_id,
    productId: row.product_id || null,
    productName: row.product_name || "",
    qty: num(row.qty),
    purchasePrice: num(row.purchase_price),
    lineTotal: num(row.line_total),
  };
}

export function mapSupplierPurchasePayment(row) {
  if (!row) return null;
  return {
    id: row.id,
    purchaseId: row.purchase_id,
    transactionId: row.transaction_id || null,
    amount: num(row.amount),
    note: row.note || "",
    kind: row.kind || "payment", // 'advance' | 'balance' | 'payment'
    date: row.date,
    createdAt: row.created_at,
  };
}

export function mapSupplierPurchase(row, items = [], payments = []) {
  if (!row) return null;
  return {
    id: row.id,
    supplierId: row.supplier_id,
    invoiceNumber: row.invoice_number,
    total: num(row.total),
    advance: num(row.advance),
    remaining: num(row.remaining),
    returned: num(row.returned),
    date: row.date,
    createdAt: row.created_at,
    items: items.map(mapSupplierPurchaseItem),
    payments: payments.map(mapSupplierPurchasePayment),
  };
}

export function mapSupplierReturn(row, items = []) {
  if (!row) return null;
  return {
    id: row.id,
    supplierId: row.supplier_id,
    purchaseId: row.purchase_id || null,
    invoiceNumber: row.invoice_number ?? null,
    returnNumber: row.return_number ?? null,
    total: num(row.total),
    applied: num(row.applied),
    reason: row.reason || "",
    note: row.note || "",
    date: row.date,
    createdAt: row.created_at,
    items: items.map((it) => ({
      id: it.id,
      productId: it.product_id || null,
      productName: it.product_name || "",
      qty: num(it.qty),
      purchasePrice: num(it.purchase_price),
      lineTotal: num(it.line_total),
    })),
  };
}
