import db, { uuid, nowIso } from "../db.js";
import { mapSupplier, mapSupplierTransaction, mapSupplierPurchase, mapSupplierReturn } from "../utils/mappers.js";
import products from "./products.js";
import { getNextPurchaseInvoiceNumber, getNextReturnNumber } from "./settings.js";

// Ek purchase invoice ko items + payment history ke sath ek hi jagah se
// banata hai (addPurchase / updatePurchase / payInvoice / listPurchases sab
// isi ko use karte hain).
function buildPurchase(purchaseRow) {
  const items = db.prepare("SELECT * FROM supplier_purchase_items WHERE purchase_id = ?").all(purchaseRow.id);
  const payments = db
    .prepare("SELECT * FROM supplier_purchase_payments WHERE purchase_id = ? ORDER BY date ASC, created_at ASC")
    .all(purchaseRow.id);
  return mapSupplierPurchase(purchaseRow, items, payments);
}

function recordPurchasePayment({ purchaseId, supplierId, transactionId = null, amount, note = "", kind = "payment", date }) {
  db.prepare(
    `INSERT INTO supplier_purchase_payments (id, purchase_id, supplier_id, transaction_id, amount, note, kind, date, created_at)
     VALUES (?,?,?,?,?,?,?,?,?)`
  ).run(uuid(), purchaseId, supplierId, transactionId, Number(amount) || 0, note || "", kind, date, nowIso());
}

// Sab suppliers ki sab purchases (items + payment history ke sath) — sirf
// backup export ke liye. Har purchase mein supplierId bhi hota hai taake
// restore ke waqt sahi supplier se dobara link ho sake.
export function listAllPurchases() {
  const rows = db.prepare("SELECT * FROM supplier_purchases ORDER BY date ASC, created_at ASC").all();
  return rows.map((row) => buildPurchase(row));
}

export function list() {
  const rows = db.prepare("SELECT * FROM suppliers ORDER BY created_at DESC").all();
  return rows.map(mapSupplier);
}

export function create(f) {
  const id = uuid();
  const ts = nowIso();
  db.prepare(
    `INSERT INTO suppliers (id, name, phone, city, notes, created_at, updated_at) VALUES (?,?,?,?,?,?,?)`
  ).run(id, String(f.name || "").trim(), f.phone || "", f.city || "", f.notes || "", ts, ts);
  return mapSupplier(db.prepare("SELECT * FROM suppliers WHERE id = ?").get(id));
}

export function update(id, f) {
  const info = db
    .prepare(`UPDATE suppliers SET name=?, phone=?, city=?, notes=?, updated_at=? WHERE id=?`)
    .run(String(f.name || "").trim(), f.phone || "", f.city || "", f.notes || "", nowIso(), id);
  if (info.changes === 0) {
    const err = new Error("Supplier not found");
    err.status = 404;
    throw err;
  }
  return mapSupplier(db.prepare("SELECT * FROM suppliers WHERE id = ?").get(id));
}

// Deleting a supplier also removes its transaction history. (Handled
// explicitly here rather than relying on SQL's ON DELETE CASCADE, since
// that behavior isn't fully reliable across sql.js builds.)
export const remove = db.transaction((id) => {
  db.prepare("DELETE FROM supplier_return_items WHERE return_id IN (SELECT id FROM supplier_returns WHERE supplier_id = ?)").run(id);
  db.prepare("DELETE FROM supplier_returns WHERE supplier_id = ?").run(id);
  db.prepare("DELETE FROM supplier_purchase_payments WHERE supplier_id = ?").run(id);
  db.prepare("DELETE FROM supplier_transactions WHERE supplier_id = ?").run(id);
  db.prepare("DELETE FROM suppliers WHERE id = ?").run(id);
});

// ── Ledger ───────────────────────────────────────────────────────────────
export function listTransactions(supplierId) {
  const rows = db
    .prepare("SELECT * FROM supplier_transactions WHERE supplier_id = ? ORDER BY date DESC, created_at DESC")
    .all(supplierId);
  return rows.map(mapSupplierTransaction);
}

export function listAllTransactions() {
  const rows = db.prepare("SELECT * FROM supplier_transactions ORDER BY date DESC, created_at DESC").all();
  return rows.map(mapSupplierTransaction);
}

// type: 'purchase' (maal liya, hum par udhaar charhta hai) or
//       'payment'  (hum ne supplier ko paise diye, udhaar kam hota hai)
export function addTransaction(supplierId, { type, amount, description, date }) {
  if (!["purchase", "payment", "opening"].includes(type)) {
    const err = new Error("Invalid transaction type");
    err.status = 400;
    throw err;
  }
  const amt = Number(amount);
  if (!amt || amt <= 0) {
    const err = new Error("Amount must be greater than zero");
    err.status = 400;
    throw err;
  }
  const supplier = db.prepare("SELECT id FROM suppliers WHERE id = ?").get(supplierId);
  if (!supplier) {
    const err = new Error("Supplier not found");
    err.status = 404;
    throw err;
  }
  const id = uuid();
  db.prepare(
    `INSERT INTO supplier_transactions (id, supplier_id, type, amount, description, date, created_at)
     VALUES (?,?,?,?,?,?,?)`
  ).run(id, supplierId, type, amt, description || "", date || nowIso(), nowIso());
  db.prepare("UPDATE suppliers SET updated_at = ? WHERE id = ?").run(nowIso(), supplierId);
  return mapSupplierTransaction(db.prepare("SELECT * FROM supplier_transactions WHERE id = ?").get(id));
}

// Ledger entry delete. Payment delete hone par us payment se jo invoices
// settle hui thin unka advance/remaining wapis theek kiya jata hai (pehle
// sirf ledger row hatti thi aur invoice "paid" hi dikhti rehti thi).
// Purchase/return rows seedha delete nahi hoti — wo apni invoice/return
// ke zariye hi hatayi jati hain taake stock aur hisaab sahi rahe.
export const removeTransaction = db.transaction((id) => {
  const txn = db.prepare("SELECT * FROM supplier_transactions WHERE id = ?").get(id);
  if (!txn) return;
  if (txn.type === "return" || (txn.type === "purchase" && txn.purchase_id)) {
    const err = new Error(
      txn.type === "return"
        ? "Purchase return ki entry yahan se delete nahi hoti — Purchase Returns se delete karein."
        : "Purchase ki entry yahan se delete nahi hoti."
    );
    err.status = 400;
    throw err;
  }
  if (txn.type === "payment") {
    const linked = db.prepare("SELECT * FROM supplier_purchase_payments WHERE transaction_id = ?").all(id);
    for (const pay of linked) {
      const purchase = db.prepare("SELECT * FROM supplier_purchases WHERE id = ?").get(pay.purchase_id);
      if (purchase) {
        const newAdvance = Math.max(0, purchase.advance - pay.amount);
        const newRemaining = Math.max(0, purchase.total - purchase.returned - newAdvance);
        db.prepare("UPDATE supplier_purchases SET advance = ?, remaining = ? WHERE id = ?").run(newAdvance, newRemaining, purchase.id);
      }
    }
    db.prepare("DELETE FROM supplier_purchase_payments WHERE transaction_id = ?").run(id);
  }
  db.prepare("DELETE FROM supplier_transactions WHERE id = ?").run(id);
});

// ── Advance Balance (supplier ko pehle se diye gaye paise) ────────────────
// Hum koi alag column store nahi karte — yeh hamesha ledger se hi nikala
// jata hai: ab tak jitna "payment" diya gaya us mein se jitna "purchase"
// hua wo minus karo. Agar payment purchase se zyada ho, wo faltu amount
// hi asal mein "advance balance" hai — jo agli purchase par khud
// istemal ho jayega.
export function getAdvanceBalance(supplierId) {
  const row = db
    .prepare(
      `SELECT
         SUM(CASE WHEN type IN ('purchase','opening') THEN amount ELSE 0 END) AS credit,
         SUM(CASE WHEN type IN ('payment','return')   THEN amount ELSE 0 END) AS debit
       FROM supplier_transactions WHERE supplier_id = ?`
    )
    .get(supplierId);
  const credit = Number(row?.credit) || 0;
  const debit = Number(row?.debit) || 0;
  return Math.max(0, debit - credit);
}

// Supplier ko advance dena — jab tak koi outstanding invoice hai, pehle
// wahi settle hoti hai (purani se nayi), jo bach jaye wo "advance balance"
// ki tarah pare rehta hai aur agli purchase par khud-ba-khud lag jata hai.
export function addAdvance(supplierId, { amount, note, date }) {
  return payInvoice(supplierId, {
    amount,
    note: note || "Advance Payment",
    date,
    purchaseId: null,
  });
}

// ── Purchase maal from supplier — ek batch mein multiple products ────────
// Ek hi action mein: (a) har product ka stock badhta hai — agar naya
// product hai to wo khud Products page mein add ho jata hai, (b) supplier
// ki ledger mein "purchase" entry (poore order ki total × amount) charhti
// hai, (c) agar advance diya gaya ho to usi waqt ek "payment" entry bhi ban
// jati hai, aur (d) poora batch ek "supplier_purchases" record ki tarah save
// hota hai taake baad mein ek hi thermal receipt (Urdu) par print ho sake.
export function addPurchase(supplierId, f) {
  const supplier = db.prepare("SELECT id, name FROM suppliers WHERE id = ?").get(supplierId);
  if (!supplier) {
    const err = new Error("Supplier not found");
    err.status = 404;
    throw err;
  }

  // Backward-compatible: purana single-item shape { productId/productName,
  // purchasePrice, qty } bhi chalta hai, naya shape { items: [...] } bhi.
  const rawItems = Array.isArray(f.items) && f.items.length > 0
    ? f.items
    : [{ productId: f.productId, productName: f.productName, purchasePrice: f.purchasePrice, qty: f.qty, category: f.category, salePrice: f.salePrice, lowStockAlertQty: f.lowStockAlertQty }];

  if (rawItems.length === 0) {
    const err = new Error("Kam az kam ek product add karein");
    err.status = 400;
    throw err;
  }

  const date = f.date || nowIso();
  const advance = Math.max(0, Number(f.advance) || 0);

  const items = [];
  let total = 0;
  const updatedProducts = [];

  for (const raw of rawItems) {
    const qty = Number(raw.qty);
    if (!qty || qty <= 0) {
      const err = new Error("Har product ki quantity 0 se zyada honi chahiye");
      err.status = 400;
      throw err;
    }
    const purchasePrice = Number(raw.purchasePrice);
    if (!purchasePrice || purchasePrice <= 0) {
      const err = new Error("Har product ki purchase price 0 se zyada honi chahiye");
      err.status = 400;
      throw err;
    }

    let product;
    if (raw.productId) {
      // Existing product — sirf stock badhta hai. Cost price jaan-boojh
      // kar yahan se overwrite NAHI hoti — wo Products page se hi manage
      // hoti hai, taake supplier ka purchase rate use ka apna cost price
      // silently na badal de.
      const existing = products.stockIn(raw.productId, qty);
      product = existing;
    } else {
      const name = String(raw.productName || "").trim();
      if (!name) {
        const err = new Error("Product name is required");
        err.status = 400;
        throw err;
      }
      // Naya product — is purchase se pehli baar catalog mein aa raha hai,
      // isliye iski shuruwati cost price purchase price hi hogi.
      product = products.create({
        name,
        category: raw.category || "Others",
        salePrice: Number(raw.salePrice) || purchasePrice,
        costPrice: purchasePrice,
        stockPrice: purchasePrice,
        currentStock: qty,
        lowStockAlertQty: Number(raw.lowStockAlertQty) || 0,
      });
    }

    const lineTotal = qty * purchasePrice;
    total += lineTotal;
    updatedProducts.push(product);
    items.push({ productId: product.id, productName: product.name, qty, purchasePrice, lineTotal });
  }

  const manualAdvance = Math.min(advance, total);

  // Agar is supplier ka pehle se diya hua "advance balance" maujood hai
  // (purani payments jo kisi purchase ke against nahi lagi), to wo yahan
  // khud-ba-khud is nayi purchase par lag jata hai — jitna zaroorat ho
  // utna hi, taake customer/dukaandar ko dobara se manually advance na
  // dena pare.
  const advanceBalanceAvailable = getAdvanceBalance(supplierId);
  const advanceFromBalance = Math.min(advanceBalanceAvailable, Math.max(0, total - manualAdvance));

  const cappedAdvance = Math.min(manualAdvance + advanceFromBalance, total);
  const remaining = Math.max(0, total - cappedAdvance);

  // Purchase batch save karo (items samet, apna alag invoice number ke sath)
  // — receipt printing aur baad mein view/edit ke liye.
  const purchaseId = uuid();
  const invoiceNumber = getNextPurchaseInvoiceNumber();
  db.prepare(
    `INSERT INTO supplier_purchases (id, supplier_id, invoice_number, total, advance, remaining, date, created_at) VALUES (?,?,?,?,?,?,?,?)`
  ).run(purchaseId, supplierId, invoiceNumber, total, cappedAdvance, remaining, date, nowIso());
  for (const item of items) {
    db.prepare(
      `INSERT INTO supplier_purchase_items (id, purchase_id, product_id, product_name, qty, purchase_price, line_total) VALUES (?,?,?,?,?,?,?)`
    ).run(uuid(), purchaseId, item.productId, item.productName, item.qty, item.purchasePrice, item.lineTotal);
  }

  // Ledger continuity ke liye same purani transaction entries bhi banti hain
  // — `purchase_id` se hamesha wapis isi invoice se link rehti hain (edit/
  // targeted payment ke liye).
  const summaryDesc = items.length === 1
    ? `${items[0].productName} × ${items[0].qty} @ Rs ${items[0].purchasePrice}`
    : `${items.length} products (${items.map((i) => i.productName).join(", ")})`;
  const txnId = uuid();
  db.prepare(
    `INSERT INTO supplier_transactions (id, supplier_id, type, amount, description, purchase_id, date, created_at) VALUES (?,?,?,?,?,?,?,?)`
  ).run(txnId, supplierId, "purchase", total, summaryDesc, purchaseId, date, nowIso());

  // Sirf naye (abhi diye gaye) cash advance ki hi nayi "payment" ledger
  // entry banti hai. Jo hissa purane advance balance se laga hai, uska
  // paisa pehle hi kisi aur payment mein ledger mein record ho chuka tha
  // — dobara entry banane se woh amount do baar count ho jata (double
  // counting), isliye yahan sirf `manualAdvance` hi likha jata hai.
  let paymentTxn = null;
  if (manualAdvance > 0) {
    const paymentId = uuid();
    db.prepare(
      `INSERT INTO supplier_transactions (id, supplier_id, type, amount, description, purchase_id, date, created_at) VALUES (?,?,?,?,?,?,?,?)`
    ).run(paymentId, supplierId, "payment", manualAdvance, `Advance — Invoice #${invoiceNumber}`, purchaseId, date, nowIso());
    paymentTxn = mapSupplierTransaction(db.prepare("SELECT * FROM supplier_transactions WHERE id = ?").get(paymentId));
    // Invoice ki payment history mein bhi likho (khareedte waqt diya gaya advance).
    recordPurchasePayment({ purchaseId, supplierId, transactionId: paymentId, amount: manualAdvance, kind: "advance", date });
  }
  // Jo hissa pehle se jama advance balance se laga, woh bhi is invoice ki
  // payment history mein alag line ban kar dikhna chahiye (ledger mein
  // dobara entry nahi banti, sirf invoice ke record mein).
  if (advanceFromBalance > 0) {
    recordPurchasePayment({ purchaseId, supplierId, amount: advanceFromBalance, kind: "balance", date });
  }

  db.prepare("UPDATE suppliers SET updated_at = ? WHERE id = ?").run(nowIso(), supplierId);

  const purchaseRow = db.prepare("SELECT * FROM supplier_purchases WHERE id = ?").get(purchaseId);

  return {
    purchaseRecord: buildPurchase(purchaseRow),
    purchase: mapSupplierTransaction(db.prepare("SELECT * FROM supplier_transactions WHERE id = ?").get(txnId)),
    payment: paymentTxn,
    products: updatedProducts,
    total,
    advance: cappedAdvance,
    advanceFromBalance,
    remaining,
  };
}

// ── Edit an existing purchase invoice ───────────────────────────────────
// Purane items ka stock pehle "undo" hota hai (jo unhone add kiya tha wo
// wapas kaat diya jata hai), phir naye items ki tarah dobara process hota
// hai — taake product stock hamesha sahi rahe chahe purchase kitni baar
// edit ho. Advance jaan-boojh kar edit nahi hoti (wo alag "payment" action
// se manage hoti hai) — sirf total/remaining naye items ke hisaab se
// recalculate hote hain.
export function updatePurchase(supplierId, purchaseId, f) {
  const purchase = db.prepare("SELECT * FROM supplier_purchases WHERE id = ? AND supplier_id = ?").get(purchaseId, supplierId);
  if (!purchase) {
    const err = new Error("Purchase invoice not found");
    err.status = 404;
    throw err;
  }
  const oldItems = db.prepare("SELECT * FROM supplier_purchase_items WHERE purchase_id = ?").all(purchaseId);

  const rawItems = Array.isArray(f.items) ? f.items : [];
  if (rawItems.length === 0) {
    const err = new Error("Kam az kam ek product add karein");
    err.status = 400;
    throw err;
  }

  // Purane items ka stock reverse karo (jo stockIn hua tha, wapas stockOut).
  for (const old of oldItems) {
    if (old.product_id) {
      try { products.stockOut(old.product_id, old.qty); } catch { /* product deleted or insufficient stock */ }
    }
  }
  db.prepare("DELETE FROM supplier_purchase_items WHERE purchase_id = ?").run(purchaseId);

  const items = [];
  let total = 0;
  const updatedProducts = [];
  for (const raw of rawItems) {
    const qty = Number(raw.qty);
    if (!qty || qty <= 0) {
      const err = new Error("Har product ki quantity 0 se zyada honi chahiye");
      err.status = 400;
      throw err;
    }
    const purchasePrice = Number(raw.purchasePrice);
    if (!purchasePrice || purchasePrice <= 0) {
      const err = new Error("Har product ki purchase price 0 se zyada honi chahiye");
      err.status = 400;
      throw err;
    }
    let product;
    if (raw.productId) {
      // Existing product — cost price yahan se overwrite nahi hoti (see
      // addPurchase ka comment).
      product = products.stockIn(raw.productId, qty);
    } else {
      const name = String(raw.productName || "").trim();
      if (!name) {
        const err = new Error("Product name is required");
        err.status = 400;
        throw err;
      }
      product = products.create({
        name, category: raw.category || "Others", salePrice: Number(raw.salePrice) || purchasePrice,
        costPrice: purchasePrice, stockPrice: purchasePrice, currentStock: qty,
        lowStockAlertQty: Number(raw.lowStockAlertQty) || 0,
      });
    }
    const lineTotal = qty * purchasePrice;
    total += lineTotal;
    updatedProducts.push(product);
    items.push({ productId: product.id, productName: product.name, qty, purchasePrice, lineTotal });
    db.prepare(
      `INSERT INTO supplier_purchase_items (id, purchase_id, product_id, product_name, qty, purchase_price, line_total) VALUES (?,?,?,?,?,?,?)`
    ).run(uuid(), purchaseId, product.id, product.name, qty, purchasePrice, lineTotal);
  }

  const advance = Math.min(purchase.advance, total);
  const remaining = Math.max(0, total - (purchase.returned || 0) - advance);
  const date = f.date || purchase.date;

  db.prepare("UPDATE supplier_purchases SET total = ?, advance = ?, remaining = ?, date = ? WHERE id = ?")
    .run(total, advance, remaining, date, purchaseId);

  const summaryDesc = items.length === 1
    ? `${items[0].productName} × ${items[0].qty} @ Rs ${items[0].purchasePrice}`
    : `${items.length} products (${items.map((i) => i.productName).join(", ")})`;
  db.prepare("UPDATE supplier_transactions SET amount = ?, description = ?, date = ? WHERE purchase_id = ? AND type = 'purchase'")
    .run(total, summaryDesc, date, purchaseId);

  db.prepare("UPDATE suppliers SET updated_at = ? WHERE id = ?").run(nowIso(), supplierId);

  const purchaseRow = db.prepare("SELECT * FROM supplier_purchases WHERE id = ?").get(purchaseId);
  return { purchaseRecord: buildPurchase(purchaseRow), products: updatedProducts };
}

// ── Payment against a purchase — specific invoice, ya overall balance ──
// purchaseId diya ho to sirf usi invoice ka advance/remaining update hota
// hai. Na diya ho ("overall" payment) to jitne bhi invoices ka remaining
// baaki hai, purani se nayi (FIFO) — sab ka remaining khud-ba-khud update
// hota reh ta hai jab tak amount khatam na ho jaye.
export function payInvoice(supplierId, f) {
  const supplier = db.prepare("SELECT id FROM suppliers WHERE id = ?").get(supplierId);
  if (!supplier) {
    const err = new Error("Supplier not found");
    err.status = 404;
    throw err;
  }
  let amount = Number(f.amount);
  if (!amount || amount <= 0) {
    const err = new Error("Amount 0 se zyada hona chahiye");
    err.status = 400;
    throw err;
  }
  const date = f.date || nowIso();
  const affectedPurchases = [];
  // Payment ki ledger entry ki id pehle hi le lete hain taake har invoice
  // ki payment history isi transaction se link ho sake.
  const paymentId = uuid();
  const userNote = String(f.note || "").trim();

  if (f.purchaseId) {
    const purchase = db.prepare("SELECT * FROM supplier_purchases WHERE id = ? AND supplier_id = ?").get(f.purchaseId, supplierId);
    if (!purchase) {
      const err = new Error("Purchase invoice not found");
      err.status = 404;
      throw err;
    }
    const applied = Math.min(amount, purchase.remaining);
    const newAdvance = purchase.advance + applied;
    const newRemaining = Math.max(0, purchase.total - newAdvance);
    db.prepare("UPDATE supplier_purchases SET advance = ?, remaining = ? WHERE id = ?").run(newAdvance, newRemaining, f.purchaseId);
    affectedPurchases.push(f.purchaseId);
    if (applied > 0) {
      recordPurchasePayment({ purchaseId: f.purchaseId, supplierId, transactionId: paymentId, amount: applied, note: userNote, kind: "payment", date });
    }
  } else {
    // Overall payment — sabse purani outstanding invoice se shuru karo.
    const outstanding = db.prepare("SELECT * FROM supplier_purchases WHERE supplier_id = ? AND remaining > 0 ORDER BY date ASC, created_at ASC").all(supplierId);
    for (const purchase of outstanding) {
      if (amount <= 0) break;
      const applied = Math.min(amount, purchase.remaining);
      const newAdvance = purchase.advance + applied;
      const newRemaining = Math.max(0, purchase.total - newAdvance);
      db.prepare("UPDATE supplier_purchases SET advance = ?, remaining = ? WHERE id = ?").run(newAdvance, newRemaining, purchase.id);
      affectedPurchases.push(purchase.id);
      if (applied > 0) {
        recordPurchasePayment({ purchaseId: purchase.id, supplierId, transactionId: paymentId, amount: applied, note: userNote, kind: "payment", date });
      }
      amount -= applied;
    }
  }

  db.prepare(
    `INSERT INTO supplier_transactions (id, supplier_id, type, amount, description, purchase_id, date, created_at) VALUES (?,?,?,?,?,?,?,?)`
  ).run(paymentId, supplierId, "payment", Number(f.amount), f.note || (f.purchaseId ? "Payment against invoice" : "Overall payment"), f.purchaseId || null, date, nowIso());

  db.prepare("UPDATE suppliers SET updated_at = ? WHERE id = ?").run(nowIso(), supplierId);

  const updatedPurchases = affectedPurchases.map((pid) => {
    const row = db.prepare("SELECT * FROM supplier_purchases WHERE id = ?").get(pid);
    return buildPurchase(row);
  });

  return {
    payment: mapSupplierTransaction(db.prepare("SELECT * FROM supplier_transactions WHERE id = ?").get(paymentId)),
    updatedPurchases,
  };
}

// Supplier ki saari purchase receipts (items samet) — Purchases tab ke liye.
export function listPurchases(supplierId) {
  const rows = db.prepare("SELECT * FROM supplier_purchases WHERE supplier_id = ? ORDER BY date DESC, created_at DESC").all(supplierId);
  return rows.map((row) => buildPurchase(row));
}

// ── Ledger (accounting table: Debit / Credit / Running Balance) ──────────
// Supplier ke nazariye se (hum par kitna baaqi hai):
//   CREDIT  = hamari zimmedari barhi  (purchase, opening balance)
//   DEBIT   = hamari zimmedari kam hui (payment diya, maal wapis kiya)
//   BALANCE = credit - debit  (+ve => hum ne supplier ko dena hai "Payable",
//                              -ve => supplier ne hamein dena hai "Advance/CR")
const TYPE_LABEL = { purchase: "Purchase", payment: "Payment", return: "Purchase Return", opening: "Opening Balance" };
const TYPE_ORDER = { opening: 0, purchase: 1, return: 2, payment: 3 };

function ledgerSort(a, b) {
  const da = String(a.date).slice(0, 10), dbb = String(b.date).slice(0, 10);
  if (da !== dbb) return da < dbb ? -1 : 1;
  const o = (TYPE_ORDER[a.type] ?? 9) - (TYPE_ORDER[b.type] ?? 9);
  if (o !== 0) return o;
  return String(a.created_at).localeCompare(String(b.created_at));
}

// from/to: "YYYY-MM-DD" (optional). Range se pehle ka hisaab "Opening
// Balance (B/F)" ki ek row ban kar aata hai, taake running balance hamesha
// sahi rahe.
export function getLedger(supplierId, query = {}) {
  const rows = db.prepare("SELECT * FROM supplier_transactions WHERE supplier_id = ?").all(supplierId).sort(ledgerSort);
  const invoiceByPurchase = new Map(
    db.prepare("SELECT id, invoice_number FROM supplier_purchases WHERE supplier_id = ?").all(supplierId).map((p) => [p.id, p.invoice_number])
  );
  const from = query.from || null;
  const to = query.to || null;

  let running = 0;
  let broughtForward = 0;
  const entries = [];
  let totalDebit = 0;
  let totalCredit = 0;

  for (const r of rows) {
    const amount = Number(r.amount) || 0;
    const isCredit = r.type === "purchase" || r.type === "opening";
    const debit = isCredit ? 0 : amount;
    const credit = isCredit ? amount : 0;
    const day = String(r.date).slice(0, 10);

    if (from && day < from) {
      broughtForward += credit - debit;
      running = broughtForward;
      continue;
    }
    if (to && day > to) continue;

    running += credit - debit;
    totalDebit += debit;
    totalCredit += credit;
    const inv = r.purchase_id ? invoiceByPurchase.get(r.purchase_id) : null;
    entries.push({
      id: r.id,
      date: r.date,
      type: r.type,
      typeLabel: TYPE_LABEL[r.type] || r.type,
      description: r.description || "",
      reference: inv ? `INV-${inv}` : "",
      purchaseId: r.purchase_id || null,
      returnId: r.return_id || null,
      debit,
      credit,
      balance: running,
    });
  }

  const closing = broughtForward + totalCredit - totalDebit;
  return {
    supplierId,
    from,
    to,
    broughtForward,
    totalDebit,
    totalCredit,
    closingBalance: closing,
    entries,
  };
}

// Sab suppliers ka ek-line summary (opening/debit/credit/closing) — Reports ke liye.
export function getLedgerSummary(query = {}) {
  return db.prepare("SELECT id, name, phone FROM suppliers ORDER BY name ASC").all().map((s) => {
    const l = getLedger(s.id, query);
    return { supplierId: s.id, name: s.name, phone: s.phone || "", broughtForward: l.broughtForward, totalDebit: l.totalDebit, totalCredit: l.totalCredit, closingBalance: l.closingBalance };
  });
}

// ── Purchase Returns (supplier ko maal wapis) ────────────────────────────
function buildReturn(row) {
  const items = db.prepare("SELECT * FROM supplier_return_items WHERE return_id = ?").all(row.id);
  return mapSupplierReturn(row, items);
}

export function listReturns(supplierId) {
  const rows = supplierId
    ? db.prepare("SELECT * FROM supplier_returns WHERE supplier_id = ? ORDER BY date DESC, created_at DESC").all(supplierId)
    : db.prepare("SELECT * FROM supplier_returns ORDER BY date DESC, created_at DESC").all();
  return rows.map(buildReturn);
}

function bad(msg, status = 400) {
  const err = new Error(msg);
  err.status = status;
  return err;
}

// Body: { purchaseId?, items:[{ productId?, productName, qty, purchasePrice }], reason, note, date }
// Effects (ek hi transaction mein):
//  1. har product ka stock kam hota hai (stock se zyada wapis nahi ho sakta)
//  2. ledger mein 'return' (DEBIT) entry banti hai
//  3. agar purchaseId diya ho: us invoice ka remaining kam hota hai (jitna
//     baaqi tha utna tak); zyada hissa supplier ke paas hamara credit hai
export const createReturn = db.transaction((supplierId, f) => {
  const supplier = db.prepare("SELECT id FROM suppliers WHERE id = ?").get(supplierId);
  if (!supplier) throw bad("Supplier not found", 404);
  const rawItems = Array.isArray(f.items) ? f.items : [];
  if (rawItems.length === 0) throw bad("Kam az kam ek product add karein");

  let purchase = null;
  let alreadyReturned = new Map();
  if (f.purchaseId) {
    purchase = db.prepare("SELECT * FROM supplier_purchases WHERE id = ? AND supplier_id = ?").get(f.purchaseId, supplierId);
    if (!purchase) throw bad("Purchase invoice not found", 404);
    const prev = db
      .prepare(
        `SELECT i.product_id, i.product_name, SUM(i.qty) AS qty FROM supplier_return_items i
         JOIN supplier_returns r ON r.id = i.return_id WHERE r.purchase_id = ? GROUP BY i.product_id, i.product_name`
      )
      .all(f.purchaseId);
    for (const p of prev) alreadyReturned.set(p.product_id || p.product_name, Number(p.qty) || 0);
  }
  const purchasedItems = purchase ? db.prepare("SELECT * FROM supplier_purchase_items WHERE purchase_id = ?").all(purchase.id) : [];

  const date = f.date || nowIso();
  const items = [];
  let total = 0;
  const seen = new Map();
  for (const raw of rawItems) {
    const qty = Number(raw.qty);
    const price = Number(raw.purchasePrice);
    if (!qty || qty <= 0) throw bad("Har product ki quantity 0 se zyada honi chahiye");
    if (!price || price <= 0) throw bad("Har product ki purchase price 0 se zyada honi chahiye");
    const name = String(raw.productName || "").trim();
    if (!name && !raw.productId) throw bad("Product name is required");
    const key = raw.productId || name;
    seen.set(key, (seen.get(key) || 0) + qty);

    if (purchase) {
      const src = purchasedItems.find((it) => (raw.productId ? it.product_id === raw.productId : it.product_name === name));
      if (!src) throw bad(`"${name}" is invoice mein nahi hai`);
      const max = src.qty - (alreadyReturned.get(src.product_id || src.product_name) || 0);
      if (seen.get(key) > max + 1e-9) throw bad(`"${src.product_name}": sirf ${max} qty wapis ho sakti hai`);
    }
    items.push({ productId: raw.productId || null, productName: name, qty, purchasePrice: price, lineTotal: qty * price });
    total += qty * price;
  }

  // Stock kam karo (insufficient stock par error — poori transaction rollback)
  for (const it of items) {
    if (it.productId) {
      const prod = db.prepare("SELECT name FROM products WHERE id = ?").get(it.productId);
      if (!prod) throw bad(`Product "${it.productName}" ab maujood nahi`);
      if (!it.productName) it.productName = prod.name;
      try {
        products.stockOut(it.productId, it.qty);
      } catch {
        throw bad(`"${prod.name}" ka itna stock maujood nahi (${it.qty} wapis nahi ho sakta)`);
      }
    }
  }

  const returnId = uuid();
  const returnNumber = getNextReturnNumber();
  const applied = purchase ? Math.min(total, purchase.remaining) : 0;
  db.prepare(
    `INSERT INTO supplier_returns (id, supplier_id, purchase_id, invoice_number, return_number, total, applied, reason, note, date, created_at)
     VALUES (?,?,?,?,?,?,?,?,?,?,?)`
  ).run(returnId, supplierId, purchase?.id || null, purchase?.invoice_number ?? null, returnNumber, total, applied, f.reason || "", f.note || "", date, nowIso());
  for (const it of items) {
    db.prepare(
      `INSERT INTO supplier_return_items (id, return_id, product_id, product_name, qty, purchase_price, line_total) VALUES (?,?,?,?,?,?,?)`
    ).run(uuid(), returnId, it.productId, it.productName, it.qty, it.purchasePrice, it.lineTotal);
  }

  if (purchase) {
    db.prepare("UPDATE supplier_purchases SET returned = returned + ?, remaining = ? WHERE id = ?").run(total, Math.max(0, purchase.remaining - applied), purchase.id);
  }

  const desc = `Purchase Return #${returnNumber}${purchase ? ` (Invoice #${purchase.invoice_number})` : ""}${f.reason ? ` — ${f.reason}` : ""}`;
  const txnId = uuid();
  db.prepare(
    `INSERT INTO supplier_transactions (id, supplier_id, type, amount, description, purchase_id, return_id, date, created_at) VALUES (?,?,?,?,?,?,?,?,?)`
  ).run(txnId, supplierId, "return", total, desc, purchase?.id || null, returnId, date, nowIso());
  db.prepare("UPDATE suppliers SET updated_at = ? WHERE id = ?").run(nowIso(), supplierId);

  return {
    returnRecord: buildReturn(db.prepare("SELECT * FROM supplier_returns WHERE id = ?").get(returnId)),
    transaction: mapSupplierTransaction(db.prepare("SELECT * FROM supplier_transactions WHERE id = ?").get(txnId)),
    purchase: purchase ? buildPurchase(db.prepare("SELECT * FROM supplier_purchases WHERE id = ?").get(purchase.id)) : null,
    products: items.filter((i) => i.productId).map((i) => mapProductById(i.productId)),
  };
});

// ── Purchase invoice delete ──────────────────────────────────────────────
// Ek hi transaction mein: stock wapis kam (current stock se neeche nahi
// jata), invoice ki purchase/advance ledger entries hatti hain, items aur
// payment-links delete hote hain. Invoice ke baad ki alag se di gayi
// payments supplier ki ledger mein rehti hain (wo paisa gaya hai, isliye
// supplier ke paas hamara advance/credit ban jata hai). Agar is invoice par
// purchase return ho chuka hai to pehle wo return delete karna zaroori hai.
export const removePurchase = db.transaction((supplierId, purchaseId) => {
  const purchase = db.prepare("SELECT * FROM supplier_purchases WHERE id = ? AND supplier_id = ?").get(purchaseId, supplierId);
  if (!purchase) throw bad("Purchase invoice not found", 404);
  const hasReturns = db.prepare("SELECT COUNT(*) AS c FROM supplier_returns WHERE purchase_id = ?").get(purchaseId).c;
  if (hasReturns > 0) throw bad("Is invoice par Purchase Return ho chuka hai. Pehle Returns tab se wo return delete karein, phir invoice delete hoga.");

  const items = db.prepare("SELECT * FROM supplier_purchase_items WHERE purchase_id = ?").all(purchaseId);
  const touched = [];
  for (const it of items) {
    if (!it.product_id) continue;
    const prod = db.prepare("SELECT current_stock FROM products WHERE id = ?").get(it.product_id);
    if (!prod) continue;
    const dec = Math.min(Number(it.qty) || 0, Number(prod.current_stock) || 0);
    if (dec > 0) products.stockOut(it.product_id, dec);
    touched.push(it.product_id);
  }

  // 'purchase' entry aur is invoice ke saath di gayi 'advance' payment entries hatao
  db.prepare("DELETE FROM supplier_transactions WHERE purchase_id = ? AND type = 'purchase'").run(purchaseId);
  const advanceTxns = db.prepare("SELECT transaction_id FROM supplier_purchase_payments WHERE purchase_id = ? AND kind = 'advance' AND transaction_id IS NOT NULL").all(purchaseId);
  for (const a of advanceTxns) db.prepare("DELETE FROM supplier_transactions WHERE id = ?").run(a.transaction_id);
  // baqi payment entries ka link tootta hai, entry ledger mein rehti hai
  db.prepare("UPDATE supplier_transactions SET purchase_id = NULL WHERE purchase_id = ?").run(purchaseId);

  db.prepare("DELETE FROM supplier_purchase_payments WHERE purchase_id = ?").run(purchaseId);
  db.prepare("DELETE FROM supplier_purchase_items WHERE purchase_id = ?").run(purchaseId);
  db.prepare("DELETE FROM supplier_purchases WHERE id = ?").run(purchaseId);
  db.prepare("UPDATE suppliers SET updated_at = ? WHERE id = ?").run(nowIso(), supplierId);

  return { id: purchaseId, products: touched.map((id) => mapProductById(id)).filter(Boolean) };
});

function mapProductById(id) {
  return products.list().find((p) => p.id === id) || null;
}

export const removeReturn = db.transaction((supplierId, returnId) => {
  const ret = db.prepare("SELECT * FROM supplier_returns WHERE id = ? AND supplier_id = ?").get(returnId, supplierId);
  if (!ret) throw bad("Return not found", 404);
  const items = db.prepare("SELECT * FROM supplier_return_items WHERE return_id = ?").all(returnId);
  for (const it of items) {
    if (it.product_id) {
      try { products.stockIn(it.product_id, it.qty); } catch { /* product deleted */ }
    }
  }
  if (ret.purchase_id) {
    const p = db.prepare("SELECT * FROM supplier_purchases WHERE id = ?").get(ret.purchase_id);
    if (p) {
      db.prepare("UPDATE supplier_purchases SET returned = ?, remaining = ? WHERE id = ?").run(
        Math.max(0, p.returned - ret.total),
        Math.min(p.total, p.remaining + ret.applied),
        p.id
      );
    }
  }
  db.prepare("DELETE FROM supplier_transactions WHERE return_id = ?").run(returnId);
  db.prepare("DELETE FROM supplier_return_items WHERE return_id = ?").run(returnId);
  db.prepare("DELETE FROM supplier_returns WHERE id = ?").run(returnId);
  return { id: returnId };
});

// Shuruwati (purana) baaqi — supplier ka jo hisaab software se pehle ka tha.
export function addOpeningBalance(supplierId, { amount, note, date }) {
  return addTransaction(supplierId, { type: "opening", amount, description: note || "Opening Balance", date });
}

export default {
  list, create, update, remove,
  listTransactions, listAllTransactions, addTransaction, removeTransaction,
  getAdvanceBalance, addAdvance,
  addPurchase, updatePurchase, payInvoice, listPurchases, listAllPurchases,
  getLedger, getLedgerSummary, listReturns, createReturn, removeReturn, addOpeningBalance, removePurchase,
};
