import { useCallback, useEffect, useMemo, useState } from "react";
import { getClient } from "../lib/supabase";
import { statusOf, daysLeft, fmtDate, ago, lastSeenOf, copy, money, isThisMonth } from "../lib/util";
import { Badge, Btn, Spinner, inputCls } from "./ui";
import { Icon } from "./icons";
import CreateModal from "./CreateModal";
import LicenseDrawer from "./LicenseDrawer";
import PlansView from "./PlansView";
import PaymentsView from "./PaymentsView";

const FILTERS = [
  ["all", "All"], ["active", "Active"], ["expiring", "Expiring"], ["expired", "Expired"], ["blocked", "Blocked"],
];
const TABS = [["licenses", "Licenses", "key"], ["plans", "Plans", "tag"], ["payments", "Payments", "wallet"]];

function Stat({ label, value, icon, tone }) {
  return (
    <div className="bg-white rounded-xl border border-slate-200 px-4 py-4 flex items-center gap-3">
      <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${tone}`}><Icon name={icon} size={20} /></div>
      <div className="min-w-0">
        <p className="text-xs text-slate-500">{label}</p>
        <p className="text-xl font-semibold text-slate-800 truncate">{value}</p>
      </div>
    </div>
  );
}

export default function Dashboard({ onLogout }) {
  const [tab, setTab] = useState("licenses");
  const [rows, setRows] = useState([]);
  const [plans, setPlans] = useState([]);
  const [payments, setPayments] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [q, setQ] = useState("");
  const [filter, setFilter] = useState("all");
  const [showCreate, setShowCreate] = useState(false);
  const [openId, setOpenId] = useState(null);
  const [toast, setToast] = useState("");

  const flash = useCallback((m) => { setToast(m); setTimeout(() => setToast(""), 2600); }, []);

  const load = useCallback(async () => {
    setLoading(true); setError("");
    const sb = getClient();
    const [l, p, pay] = await Promise.all([
      sb.from("licenses").select("*, license_devices(*)").order("created_at", { ascending: false }),
      sb.from("plans").select("*").order("price", { ascending: true }),
      sb.from("payments").select("*").order("paid_at", { ascending: false }),
    ]);
    const err = l.error || p.error || pay.error;
    if (err) setError(err.message + " — did you run the latest schema.sql?");
    setRows(l.data || []); setPlans(p.data || []); setPayments(pay.data || []);
    setLoading(false);
  }, []);
  useEffect(() => { load(); }, [load]);

  const counts = useMemo(() => {
    const c = { all: rows.length, active: 0, expiring: 0, expired: 0, blocked: 0 };
    rows.forEach((r) => { c[statusOf(r)]++; });
    return c;
  }, [rows]);
  const monthRevenue = useMemo(() => payments.filter((p) => isThisMonth(p.paid_at)).reduce((a, p) => a + Number(p.amount), 0), [payments]);

  const shown = useMemo(() => {
    const t = q.trim().toLowerCase();
    return rows.filter((r) => {
      if (filter !== "all" && statusOf(r) !== filter) return false;
      if (!t) return true;
      return [r.shop_name, r.owner_name, r.phone, r.license_key, r.admin_username].some((x) => (x || "").toLowerCase().includes(t));
    });
  }, [rows, q, filter]);

  const open = rows.find((r) => r.id === openId);

  return (
    <div className="min-h-full">
      <header className="bg-white border-b border-slate-200 px-6 py-3 flex items-center justify-between sticky top-0 z-10">
        <div className="flex items-center gap-6">
          <div className="flex items-center gap-3">
            <img src="./logo.png" alt="" className="w-9 h-9 rounded-lg" />
            <div>
              <h1 className="font-semibold text-slate-800 leading-tight">Tech Riwaayat POS</h1>
              <p className="text-xs text-slate-500 leading-tight">Super Admin</p>
            </div>
          </div>
          <nav className="flex gap-1">
            {TABS.map(([k, label, icon]) => (
              <button key={k} onClick={() => setTab(k)}
                className={`inline-flex items-center gap-2 px-3 py-2 rounded-lg text-sm font-medium ${tab === k ? "bg-blue-50 text-blue-700" : "text-slate-600 hover:bg-slate-100"}`}>
                <Icon name={icon} size={16} /> {label}
              </button>
            ))}
          </nav>
        </div>
        <div className="flex items-center gap-2">
          <Btn icon="refresh" onClick={load}>Refresh</Btn>
          {tab === "licenses" && <Btn kind="primary" icon="plus" onClick={() => setShowCreate(true)}>New License</Btn>}
          <Btn icon="logout" onClick={onLogout}>Sign out</Btn>
        </div>
      </header>

      <main className="px-6 py-6 max-w-[1400px] mx-auto">
        {error && <p className="mb-4 px-4 py-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</p>}

        {tab === "licenses" && (
          <>
            <div className="grid grid-cols-2 lg:grid-cols-6 gap-3 mb-6">
              <Stat label="Total clients" value={counts.all} icon="users" tone="bg-slate-100 text-slate-600" />
              <Stat label="Active" value={counts.active} icon="check-circle" tone="bg-emerald-50 text-emerald-600" />
              <Stat label="Expiring in 7 days" value={counts.expiring} icon="clock" tone="bg-amber-50 text-amber-600" />
              <Stat label="Expired" value={counts.expired} icon="x-circle" tone="bg-red-50 text-red-600" />
              <Stat label="Blocked" value={counts.blocked} icon="ban" tone="bg-slate-200 text-slate-700" />
              <Stat label="Revenue this month" value={money(monthRevenue)} icon="trend" tone="bg-blue-50 text-blue-600" />
            </div>

            <div className="flex flex-wrap items-center gap-3 mb-4">
              <div className="relative">
                <Icon name="search" size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                <input className={`${inputCls} pl-9 w-72`} placeholder="Search shop, owner, phone or key" value={q} onChange={(e) => setQ(e.target.value)} />
              </div>
              <div className="flex gap-1.5">
                {FILTERS.map(([k, label]) => (
                  <button key={k} onClick={() => setFilter(k)}
                    className={`px-3 py-1.5 rounded-full text-sm border ${filter === k ? "bg-slate-800 text-white border-slate-800" : "bg-white text-slate-600 border-slate-300 hover:bg-slate-50"}`}>
                    {label} <span className="opacity-60">{counts[k]}</span>
                  </button>
                ))}
              </div>
            </div>

            <div className="bg-white rounded-xl border border-slate-200 overflow-hidden">
              <table className="w-full text-sm">
                <thead>
                  <tr className="text-left text-xs font-medium text-slate-500 bg-slate-50 border-b border-slate-200">
                    <th className="px-4 py-3">Shop</th><th className="px-3 py-3">License key</th><th className="px-3 py-3">Plan</th>
                    <th className="px-3 py-3">Expires</th><th className="px-3 py-3">Computers</th><th className="px-3 py-3">Last seen</th><th className="px-3 py-3">Status</th>
                  </tr>
                </thead>
                <tbody>
                  {loading && <tr><td colSpan={7} className="py-14"><div className="flex justify-center"><Spinner /></div></td></tr>}
                  {!loading && shown.length === 0 && (
                    <tr><td colSpan={7} className="py-14 text-center text-slate-400">{rows.length ? "No licenses match your search." : "No licenses yet. Click “New License” to add your first client."}</td></tr>
                  )}
                  {!loading && shown.map((r) => {
                    const d = daysLeft(r.expires_at);
                    return (
                      <tr key={r.id} onClick={() => setOpenId(r.id)} className="border-b border-slate-100 hover:bg-slate-50 cursor-pointer">
                        <td className="px-4 py-3">
                          <p className="font-medium text-slate-800">{r.shop_name}</p>
                          <p className="text-xs text-slate-500">{[r.owner_name, r.phone].filter(Boolean).join(" • ") || "—"}</p>
                        </td>
                        <td className="px-3 py-3">
                          <button onClick={(e) => { e.stopPropagation(); copy(r.license_key).then(() => flash("License key copied")); }}
                            className="inline-flex items-center gap-1.5 font-mono text-xs text-slate-600 hover:text-blue-600" title="Copy key">
                            {r.license_key} <Icon name="copy" size={12} />
                          </button>
                        </td>
                        <td className="px-3 py-3">
                          <p className="text-slate-700">{r.plan}</p>
                          <p className="text-xs text-slate-500">{money(r.price)} / month</p>
                        </td>
                        <td className="px-3 py-3">
                          <p className="text-slate-700">{fmtDate(r.expires_at)}</p>
                          <p className={`text-xs ${d < 0 ? "text-red-500" : d <= 7 ? "text-amber-600" : "text-slate-500"}`}>{d < 0 ? `Expired ${-d} day${d === -1 ? "" : "s"} ago` : `${d} day${d === 1 ? "" : "s"} left`}</p>
                        </td>
                        <td className="px-3 py-3 text-slate-600">{(r.license_devices || []).length} / {r.max_devices}</td>
                        <td className="px-3 py-3 text-slate-500">{ago(lastSeenOf(r))}</td>
                        <td className="px-3 py-3"><Badge status={statusOf(r)} /></td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </>
        )}

        {tab === "plans" && <PlansView plans={plans} licenses={rows} loading={loading} onChanged={load} flash={flash} />}
        {tab === "payments" && <PaymentsView payments={payments} loading={loading} onChanged={load} flash={flash} />}
      </main>

      {showCreate && <CreateModal plans={plans} onClose={() => setShowCreate(false)} onCreated={load} />}
      {open && <LicenseDrawer license={open} plans={plans} payments={payments.filter((p) => p.license_id === open.id)} onClose={() => setOpenId(null)} onChanged={load} flash={flash} />}
      {toast && <div className="fixed bottom-6 left-1/2 -translate-x-1/2 z-50 bg-slate-900 text-white text-sm px-4 py-2.5 rounded-lg shadow-xl">{toast}</div>}
    </div>
  );
}
