import { useState } from "react";
import { getClient } from "../lib/supabase";
import { renewedExpiry, fmtDate, money } from "../lib/util";
import { Btn, Field, Modal, ErrorBox, inputCls } from "./ui";

export default function RenewModal({ license: l, onClose, onDone }) {
  const [months, setMonths] = useState(1);
  const [amount, setAmount] = useState(String(Number(l.price || 0)));
  const [note, setNote] = useState("");
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");

  const newExpiry = renewedExpiry(l.expires_at, +months);
  const changeMonths = (e) => { setMonths(e.target.value); setAmount(String(Number(l.price || 0) * Number(e.target.value))); };

  const submit = async () => {
    setBusy(true); setErr("");
    const sb = getClient();
    const { error } = await sb.from("licenses").update({ expires_at: newExpiry }).eq("id", l.id);
    if (error) { setBusy(false); return setErr(error.message); }
    const paid = Number(amount) || 0;
    if (paid > 0) {
      const { error: e2 } = await sb.from("payments").insert({
        license_id: l.id, shop_name: l.shop_name, plan: l.plan, amount: paid, months: +months, note: note.trim() || null,
      });
      if (e2) { setBusy(false); return setErr("Renewed, but the payment could not be saved: " + e2.message); }
    }
    setBusy(false);
    onDone(`Renewed for ${months} month${months > 1 ? "s" : ""}${paid > 0 ? ` • ${money(paid)} recorded` : ""}`);
    onClose();
  };

  return (
    <Modal title={`Renew — ${l.shop_name}`} onClose={onClose}>
      <ErrorBox message={err} />
      <div className="space-y-3">
        <Field label="Renew for">
          <select className={inputCls} value={months} onChange={changeMonths}>{[1, 2, 3, 6, 12, 24].map((m) => <option key={m} value={m}>{m} month{m > 1 ? "s" : ""}</option>)}</select>
        </Field>
        <Field label="Amount received (Rs)" hint={`${l.plan} plan at ${money(l.price)} per month. Enter 0 for a free extension (no payment recorded).`}>
          <input type="number" min="0" className={inputCls} value={amount} onChange={(e) => setAmount(e.target.value)} />
        </Field>
        <Field label="Note (optional)"><input className={inputCls} value={note} onChange={(e) => setNote(e.target.value)} placeholder="e.g. Paid by bank transfer" /></Field>
      </div>
      <div className="mt-4 px-3 py-2.5 rounded-lg bg-slate-50 border border-slate-200 text-sm text-slate-600">
        Current expiry: <b>{fmtDate(l.expires_at)}</b> → New expiry: <b className="text-emerald-700">{fmtDate(newExpiry)}</b>
      </div>
      <div className="flex justify-end gap-2 mt-5">
        <Btn onClick={onClose}>Cancel</Btn>
        <Btn kind="ok" icon="check" disabled={busy} onClick={submit}>{busy ? "Saving..." : "Renew & record payment"}</Btn>
      </div>
    </Modal>
  );
}
