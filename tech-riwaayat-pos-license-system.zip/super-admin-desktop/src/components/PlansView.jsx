import { useState } from "react";
import { getClient } from "../lib/supabase";
import { money } from "../lib/util";
import { Btn, Field, Modal, ErrorBox, Spinner, inputCls } from "./ui";
import { Icon } from "./icons";

function PlanModal({ plan, onClose, onSaved }) {
  const [f, setF] = useState({ name: plan?.name || "", price: plan?.price ?? "", max_devices: plan?.max_devices ?? 1 });
  const [err, setErr] = useState("");
  const [busy, setBusy] = useState(false);
  const set = (k) => (e) => setF((s) => ({ ...s, [k]: e.target.value }));

  const save = async () => {
    if (!f.name.trim()) return setErr("Plan name is required.");
    if (f.price === "" || Number(f.price) < 0) return setErr("Enter the monthly price (0 or more).");
    setBusy(true); setErr("");
    const row = { name: f.name.trim(), price: Number(f.price), max_devices: Math.max(1, +f.max_devices || 1) };
    const sb = getClient();
    const { error } = plan ? await sb.from("plans").update(row).eq("id", plan.id) : await sb.from("plans").insert(row);
    setBusy(false);
    if (error) return setErr(error.code === "23505" ? "A plan with this name already exists." : error.message);
    onSaved();
    onClose();
  };

  return (
    <Modal title={plan ? "Edit plan" : "New plan"} onClose={onClose}>
      <ErrorBox message={err} />
      <div className="space-y-3">
        <Field label="Plan name"><input className={inputCls} value={f.name} onChange={set("name")} autoFocus /></Field>
        <Field label="Price per month (Rs)"><input type="number" min="0" className={inputCls} value={f.price} onChange={set("price")} /></Field>
        <Field label="Computers allowed" hint="Default for new licenses on this plan.">
          <input type="number" min="1" className={inputCls} value={f.max_devices} onChange={set("max_devices")} />
        </Field>
      </div>
      <p className="text-xs text-slate-500 mt-3">Changing a plan's price does not change what existing clients already pay. Edit a client's price in their license.</p>
      <div className="flex justify-end gap-2 mt-5">
        <Btn onClick={onClose}>Cancel</Btn>
        <Btn kind="primary" icon="check" disabled={busy} onClick={save}>{busy ? "Saving..." : "Save plan"}</Btn>
      </div>
    </Modal>
  );
}

export default function PlansView({ plans, licenses, loading, onChanged, flash }) {
  const [editing, setEditing] = useState(null); // null | "new" | plan

  const remove = async (p) => {
    const used = licenses.filter((l) => l.plan === p.name).length;
    const msg = used
      ? `${used} client(s) use the "${p.name}" plan. They will keep it, but the plan will no longer appear in the list. Delete anyway?`
      : `Delete the "${p.name}" plan?`;
    if (!confirm(msg)) return;
    const { error } = await getClient().from("plans").delete().eq("id", p.id);
    if (error) return flash("Error: " + error.message);
    flash("Plan deleted");
    onChanged();
  };

  return (
    <>
      <div className="flex items-center justify-between mb-4">
        <div>
          <h2 className="text-lg font-semibold text-slate-800">Plans</h2>
          <p className="text-sm text-slate-500">Set the monthly price for each plan. Prices are used when you create or renew a license.</p>
        </div>
        <Btn kind="primary" icon="plus" onClick={() => setEditing("new")}>New plan</Btn>
      </div>

      <div className="bg-white rounded-xl border border-slate-200 overflow-hidden">
        <table className="w-full text-sm">
          <thead>
            <tr className="text-left text-xs font-medium text-slate-500 bg-slate-50 border-b border-slate-200">
              <th className="px-4 py-3">Plan</th><th className="px-3 py-3">Price / month</th><th className="px-3 py-3">Computers</th><th className="px-3 py-3">Clients</th><th className="px-3 py-3 w-40" />
            </tr>
          </thead>
          <tbody>
            {loading && <tr><td colSpan={5} className="py-12"><div className="flex justify-center"><Spinner /></div></td></tr>}
            {!loading && plans.length === 0 && <tr><td colSpan={5} className="py-12 text-center text-slate-400">No plans yet.</td></tr>}
            {!loading && plans.map((p) => (
              <tr key={p.id} className="border-b border-slate-100">
                <td className="px-4 py-3 font-medium text-slate-800"><span className="inline-flex items-center gap-2"><Icon name="tag" size={15} className="text-slate-400" />{p.name}</span></td>
                <td className="px-3 py-3 text-slate-700">{money(p.price)}</td>
                <td className="px-3 py-3 text-slate-600">{p.max_devices}</td>
                <td className="px-3 py-3 text-slate-600">{licenses.filter((l) => l.plan === p.name).length}</td>
                <td className="px-3 py-3">
                  <div className="flex gap-2 justify-end">
                    <Btn icon="edit" onClick={() => setEditing(p)}>Edit</Btn>
                    <Btn kind="danger" icon="trash" onClick={() => remove(p)} aria-label="Delete plan" />
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      {editing && <PlanModal plan={editing === "new" ? null : editing} onClose={() => setEditing(null)} onSaved={() => { flash("Plan saved"); onChanged(); }} />}
    </>
  );
}
