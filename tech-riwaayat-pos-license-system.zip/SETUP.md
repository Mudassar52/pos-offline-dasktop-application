# Tech Riwaayat POS — License / Rent System (Setup Guide)

| Folder | Kya hai |
|---|---|
| `pos-desktop/` | **Tech Riwaayat POS** — client ko dene wali app (license se locked) |
| `super-admin-desktop/` | **Tech Riwaayat POS Super Admin** — licenses, plans, prices aur payments |
| `supabase/schema.sql` | Supabase database setup (dobara run karna safe hai) |

## Naya kya hai
- Dono app ka naam ab **Tech Riwaayat POS** hai (Super Admin ke naam ke saath "Super Admin").
- Super Admin app ka poora text English mein aur simple font/style; stats aur buttons par icons.
- Super Admin mein "Supabase Connect" screen khatam — URL/key app mein pehle se hai, seedha login aata hai.
- **Plans tab:** har plan ki monthly price set karein.
- **Payments tab:** har renewal ki payment record hoti hai; is mahine / pichle mahine / total revenue dikhta hai.
- License banate aur renew karte waqt plan ki price se amount khud bhar jata hai (aap badal sakte hain, 0 likhein to payment record nahi hoti).
- POS mein **My Profile → Change Password khatam**. Password sirf Super Admin se badalta hai.
- POS mein **live countdown timer**: top bar mein aur My Profile → "My Plan" card mein (Days/Hours/Minutes/Seconds).
- Purana data safe hai: POS purane "Shakir POS" data folder ko hi use karti hai, aur database mein naam khud "Tech Riwaayat POS" ho jata hai (agar aap ne custom naam nahi rakha tha).

## Setup — ek dafa

### 1. Supabase
1. SQL Editor → `supabase/schema.sql` ka **poora** content paste → Run.
   (Agar pehle run kar chuke hain to bhi dobara run karein — isse Plans/Payments tables add ho jayenge, purana data safe rahega.)
2. Authentication → Users → Add user (apna email + password, Auto Confirm ON).
3. SQL Editor mein (apna email likh kar):
   ```sql
   insert into public.super_admins (user_id)
   select id from auth.users where email = 'YOUR-EMAIL@example.com';
   ```
   (Agar pehle kar chuke hain to dobara karne ki zaroorat nahi.)
4. Authentication → Sign In / Providers → "Allow new users to sign up" OFF.

### 2. Super Admin app
```bash
cd super-admin-desktop
npm install
npm run dev          # test
npm run dist:win     # installer (release/ folder)
```
Login ke baad pehle **Plans** tab mein apne plans ki price set karein (Basic / Standard / Premium pehle se bane hain, price 0 hai).

### 3. POS app
`pos-desktop/electron/licenseConfig.js` mein sirf `SUPPORT_CONTACT` mein apna phone likhein (URL, key, secret bhare hue hain).
```bash
cd pos-desktop
npm install
npm run dist:win
```
Development test (license bypass, sirf `npm run dev` par): `POS_SKIP_LICENSE=1 npm run dev`

## Roz ka kaam
- **Naya client:** Licenses → New License → plan chunein (price khud aayegi) → amount → Create → "Copy message" → client ko bhej dein.
- **Rent aaya:** client kholein → **Renew & record payment** → muddat aur amount → done. Payment "Payments" tab mein chali jati hai.
- **Rent nahi aaya:** expiry guzarne dein ya **Block** karein. Timer zero hone par app khud lock ho jati hai (client backup le sakta hai).
- **Password bhool gaya:** client → "Login & password" → New password → "Set password & copy message".
- **PC change:** client → Computers → purana Remove → naye PC par wahi key.

## Icons (aap khud badlenge) — kahan aur kaunsa size
| App | File | Kaam |
|---|---|---|
| POS | `pos-desktop/build/icon.png` | Installer + app icon (**1024×1024 PNG**, square) |
| POS | `pos-desktop/public/logo.png` | App ke andar (login, sidebar) logo (512×512 PNG) |
| Super Admin | `super-admin-desktop/build/icon.png` | Installer + app icon (**1024×1024 PNG**) |
| Super Admin | `super-admin-desktop/public/logo.png` | App ke andar logo (512×512 PNG) |

Bas same naam se file replace karein, phir dobara `npm run dist:win` chalayein. Windows ke liye behtar hai ke `build/` mein `icon.ico` (256×256 multi-size) bhi rakhein aur `package.json` ke `"win": { "icon": ... }` mein `build/icon.ico` likh dein.

## Security ke baare mein
- Desktop app mein 100% protection mumkin nahi; yeh system aam clients ko rokne ke liye kaafi hai, asal control server-side check se aata hai.
- `LICENSE_SECRET` baad mein na badlein. Installer ko sirf clients ko dein, source code nahi.
- Rent ka written agreement alag se likh lein.
