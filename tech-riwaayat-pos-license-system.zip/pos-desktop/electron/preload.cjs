// IMPORTANT: this file must stay CommonJS (.cjs, require/module.exports —
// no import/export). Electron loads the preload script through Node's
// CommonJS loader regardless of the project's package.json "type" field;
// naming it .cjs guarantees that no matter what, so contextBridge actually
// runs and window.electronAPI shows up in the renderer.
const { contextBridge, ipcRenderer } = require("electron");

function fail(res, fallback) {
  const err = new Error(res.error || fallback);
  err.status = res.status;
  err.code = res.code;
  return err;
}

contextBridge.exposeInMainWorld("electronAPI", {
  // Generic data request — matches { method, path, body } -> data (or throws)
  request: async (method, path, body) => {
    const res = await ipcRenderer.invoke("api-request", { method, path, body });
    if (!res.ok) throw fail(res, "Request failed");
    return res.data;
  },

  // Local auth (login only — register / forgot / change password were removed)
  login: async (username, password) => {
    const res = await ipcRenderer.invoke("auth-login", { username, password });
    if (!res.ok) throw fail(res, "Login failed");
    return res.data;
  },

  // License
  licenseStatus: () => ipcRenderer.invoke("license-status"),
  licenseRefresh: () => ipcRenderer.invoke("license-refresh"),
  licenseActivate: async (key) => {
    const res = await ipcRenderer.invoke("license-activate", key);
    if (!res.ok) throw new Error(res.error || "Activation failed");
    return res.data;
  },
  licenseBackupDb: () => ipcRenderer.invoke("license-backup-db"),
  onLicenseChange: (cb) => {
    const handler = (_e, state) => cb(state);
    ipcRenderer.on("license-changed", handler);
    return () => ipcRenderer.removeListener("license-changed", handler);
  },
});
