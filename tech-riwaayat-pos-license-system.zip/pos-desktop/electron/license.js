// ── License engine (Supabase) ────────────────────────────────────────────
// Yeh file sirf Electron ke MAIN process mein chalti hai (renderer ko iska
// secret/config kabhi nahi milta). Flow:
//   1. activate(key)  → Supabase RPC "activate_license" → local license.json
//   2. refresh()      → har 30 min + app start par "check_license"
//   3. getState()     → active / expired / blocked / verify_required / ...
// Offline chalne ke liye "grace days" milte hain; uske baad internet se
// verify karna zaroori hai. Local file HMAC se signed hai aur is computer ki
// machine-id se bandhi hui hai (copy karke doosre PC par nahi chalegi).
import fs from "fs";
import path from "path";
import os from "os";
import crypto from "crypto";
import { execSync } from "child_process";
import * as cfg from "./licenseConfig.js";

const DAY = 86400000;
const ERR_TEXT = {
  invalid_key: "This license key is invalid or has been deleted.",
  blocked: "This license is blocked. Please contact your service provider.",
  device_limit: "The maximum number of computers for this license has been reached.",
  not_activated: "This computer was deactivated. Please activate again.",
  invalid_request: "Invalid request. Please try again.",
};

let filePath = null;
let appVersion = "1.0.0";
let hooks = { applyCredentials: null, hasUser: null, onChange: null };
let cached = null;
let tampered = false;
let lastError = null;
let lastTouch = 0;
let lastPublic = "";
let refreshing = null;
let skipAll = false;
let timers = [];

class UserError extends Error {}
class NetworkError extends Error {}

// ── Machine ID (OS ka apna unique ID; na mile to hostname+MAC) ───────────
let _mid = null;
export function machineId() {
  if (_mid) return _mid;
  let raw = "";
  try {
    const opt = { encoding: "utf8", windowsHide: true, timeout: 5000, stdio: ["ignore", "pipe", "ignore"] };
    if (process.platform === "win32") {
      const out = execSync("reg query HKLM\\SOFTWARE\\Microsoft\\Cryptography /v MachineGuid", opt);
      raw = (out.match(/MachineGuid\s+REG_SZ\s+(\S+)/i) || [])[1] || "";
    } else if (process.platform === "darwin") {
      const out = execSync("ioreg -rd1 -c IOPlatformExpertDevice", opt);
      raw = (out.match(/"IOPlatformUUID"\s*=\s*"([^"]+)"/) || [])[1] || "";
    } else {
      for (const p of ["/etc/machine-id", "/var/lib/dbus/machine-id"]) {
        try { raw = fs.readFileSync(p, "utf8").trim(); if (raw) break; } catch { /* next */ }
      }
    }
  } catch { /* fallback below */ }
  if (!raw) {
    const macs = Object.values(os.networkInterfaces()).flat()
      .filter((i) => i && !i.internal && i.mac && i.mac !== "00:00:00:00:00:00").map((i) => i.mac).sort();
    raw = `${os.hostname()}|${macs.join(",")}|${os.cpus()[0]?.model || ""}`;
  }
  _mid = crypto.createHash("sha256").update("shakir-pos|" + raw).digest("hex").slice(0, 32);
  return _mid;
}

// ── Signed local file ────────────────────────────────────────────────────
function sign(data) {
  const { sig, ...rest } = data;
  const payload = JSON.stringify(Object.keys(rest).sort().map((k) => [k, rest[k]]));
  return crypto.createHmac("sha256", `${cfg.LICENSE_SECRET}|${machineId()}`).update(payload).digest("hex");
}
function writeState(rec) {
  rec.sig = sign(rec);
  cached = rec;
  fs.writeFileSync(filePath, JSON.stringify(rec));
}
function readState() {
  tampered = false;
  cached = null;
  if (!fs.existsSync(filePath)) return;
  try {
    const rec = JSON.parse(fs.readFileSync(filePath, "utf8"));
    if (rec && rec.sig && rec.sig === sign(rec)) cached = rec;
    else tampered = true;
  } catch { tampered = true; }
}
function clearState() {
  cached = null;
  try { fs.unlinkSync(filePath); } catch { /* ignore */ }
}

const configured = () =>
  cfg.SUPABASE_URL && cfg.SUPABASE_ANON_KEY &&
  !cfg.SUPABASE_URL.includes("YOUR-PROJECT") && !cfg.SUPABASE_ANON_KEY.includes("YOUR-ANON");

// ── Supabase RPC (plain fetch, koi extra dependency nahi) ────────────────
async function rpc(fn, args) {
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), 12000);
  let res;
  try {
    res = await fetch(`${cfg.SUPABASE_URL.replace(/\/$/, "")}/rest/v1/rpc/${fn}`, {
      method: "POST",
      headers: { apikey: cfg.SUPABASE_ANON_KEY, "Content-Type": "application/json" },
      body: JSON.stringify(args),
      signal: ctrl.signal,
    });
  } catch {
    throw new NetworkError("Could not connect to the license server. Check your internet.");
  } finally {
    clearTimeout(t);
  }
  let json = null;
  try { json = await res.json(); } catch { /* not json */ }
  if (res.status >= 500) throw new NetworkError("The license server is not available right now.");
  if (!res.ok) throw new UserError(json?.message || `License server error (${res.status})`);
  return json;
}

// ── State calculation ────────────────────────────────────────────────────
function fmtDate(iso) {
  try { return new Date(iso).toISOString().slice(0, 10); } catch { return ""; }
}
function compute() {
  const now = Date.now();
  if (skipAll) return { state: "active", message: "" };
  if (!configured()) return { state: "not_configured", message: "License settings are missing (fill in the Supabase URL/key in electron/licenseConfig.js)." };
  if (tampered) return { state: "tampered", message: "The license file is damaged or was modified. Please activate again (internet required)." };
  if (!cached) return { state: "unactivated", message: "Enter your license key to activate the software." };
  const c = cached;
  const eff = now + (c.skewMs || 0);
  const exp = Date.parse(c.expiresAt);
  const base = {
    shopName: c.shopName, ownerName: c.ownerName, plan: c.plan, expiresAt: c.expiresAt,
    daysLeft: Math.ceil((exp - eff) / DAY), notice: c.notice || "", lastVerifiedAt: c.lastVerifiedAt, skewMs: c.skewMs || 0,
  };
  if (c.serverStatus === "blocked")
    return { ...base, state: "blocked", message: "Your license has been blocked. Please contact your service provider." };
  if (now < (c.lastSeenAt || 0) - 10 * 60000)
    return { ...base, state: "verify_required", message: "The computer date/time was set back. Connect to the internet to verify your license." };
  if (now - c.lastVerifiedAt > (c.graceDays ?? 7) * DAY)
    return { ...base, state: "verify_required", message: `The license has not been verified for ${c.graceDays ?? 7} days. Connect to the internet to verify it.` };
  if (c.serverStatus === "expired" || eff > exp)
    return { ...base, state: "expired", message: `Your license expired on ${fmtDate(c.expiresAt)}. Please renew it.` };
  if (typeof hooks.hasUser === "function" && !hooks.hasUser(c.adminUsername))
    return { ...base, state: "needs_password", message: "The account is not ready on this computer yet. Ask your service provider to set a password, then press Check Again." };
  return { ...base, state: "active", message: "" };
}

export function getState() {
  touch();
  const s = compute();
  return { ...s, support: cfg.SUPPORT_CONTACT, error: lastError, machine: machineId().slice(0, 8).toUpperCase() };
}
export const isActive = () => compute().state === "active";

function emit() {
  const s = getState();
  const j = JSON.stringify({ ...s, lastVerifiedAt: 0 });
  if (j !== lastPublic) {
    lastPublic = j;
    if (typeof hooks.onChange === "function") hooks.onChange(s);
  }
}

// lastSeenAt sirf aage badhta hai — is se clock peeche karne ka pata chalta hai
function touch() {
  if (!cached || skipAll) return;
  const now = Date.now();
  if (now - lastTouch < 60000 || now < (cached.lastSeenAt || 0)) return;
  lastTouch = now;
  try { writeState({ ...cached, lastSeenAt: now }); } catch { /* ignore */ }
}

// ── Server result → local file ───────────────────────────────────────────
async function applyServerResult(key, res) {
  const now = Date.now();
  let skew = 0;
  const st = Date.parse(res.server_time);
  if (!Number.isNaN(st)) skew = st - now;
  writeState({
    v: 1, key, machineId: machineId(),
    shopName: res.shop_name || "", ownerName: res.owner_name || "", plan: res.plan || "",
    expiresAt: res.expires_at, serverStatus: res.status, graceDays: res.offline_grace_days ?? 7,
    notice: res.notice || "", adminUsername: res.admin_username || "",
    lastVerifiedAt: now, lastSeenAt: now, skewMs: Math.abs(skew) > 60000 ? skew : 0,
  });
  lastTouch = now;
  lastError = null;
  if (res.pending_password && res.admin_username && hooks.applyCredentials) {
    hooks.applyCredentials({ username: res.admin_username, password: res.pending_password });
    try { await rpc("ack_credentials", { p_key: key, p_machine_id: machineId() }); } catch { /* will be applied again next time */ }
  }
  emit();
}

// ── Public API ───────────────────────────────────────────────────────────
export function initLicense({ userDataPath, version, applyCredentials, hasUser, onChange, skip }) {
  filePath = path.join(userDataPath, "license.json");
  appVersion = version || "1.0.0";
  hooks = { applyCredentials, hasUser, onChange };
  skipAll = !!skip;
  readState();
  lastPublic = JSON.stringify({ ...getState(), lastVerifiedAt: 0 });
}

export function startBackground() {
  if (skipAll) return;
  refresh();
  timers.push(setInterval(() => emit(), 60 * 1000).unref?.() ?? 0);
  timers.push(setInterval(() => refresh(), 30 * 60 * 1000).unref?.() ?? 0);
}

export async function activate(rawKey) {
  if (skipAll) return getState();
  if (!configured()) throw new UserError(compute().message);
  const key = String(rawKey || "").trim().toUpperCase();
  if (key.length < 8) throw new UserError("Please enter a valid license key.");
  let res;
  try {
    res = await rpc("activate_license", {
      p_key: key, p_machine_id: machineId(), p_machine_name: os.hostname(), p_app_version: appVersion,
    });
  } catch (e) {
    if (e instanceof NetworkError) throw new UserError("Internet is required to activate. " + e.message);
    throw e;
  }
  if (!res?.ok) throw new UserError(ERR_TEXT[res?.error] || "Activation failed.");
  await applyServerResult(key, res);
  return getState();
}

async function doRefresh() {
  if (skipAll || !cached || !configured()) return getState();
  try {
    const res = await rpc("check_license", { p_key: cached.key, p_machine_id: machineId(), p_app_version: appVersion });
    if (res?.ok) await applyServerResult(cached.key, res);
    else if (res?.error === "invalid_key" || res?.error === "not_activated") {
      clearState();
      lastError = ERR_TEXT[res.error];
      emit();
    }
  } catch (e) {
    if (!(e instanceof NetworkError)) lastError = e.message; // network band ho to purani state hi chalti rahe (grace)
  }
  emit();
  return getState();
}
export function refresh() {
  if (refreshing) return refreshing;
  refreshing = doRefresh().finally(() => { refreshing = null; });
  return refreshing;
}

export function friendlyError(e) {
  return e instanceof UserError ? e.message : e?.message || "Something went wrong.";
}
export default { initLicense, startBackground, activate, refresh, getState, isActive, machineId, friendlyError };
