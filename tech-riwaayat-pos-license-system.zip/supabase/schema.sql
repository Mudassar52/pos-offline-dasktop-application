-- ════════════════════════════════════════════════════════════════════════
--  Tech Riwaayat POS — License System (Supabase)
--  Supabase Dashboard → SQL Editor → New query → yeh poori file paste → Run
-- ════════════════════════════════════════════════════════════════════════
--  Security design:
--   • Tables par RLS ON hai. Sirf "super admin" (super_admins table wala
--     login) licenses dekh/badal sakta hai.
--   • POS app sirf 3 chhote functions (RPC) call kar sakti hai: activate /
--     check / ack. Woh table ko seedha kabhi nahi padh sakti, isliye ek
--     client doosre clients ka data nahi dekh sakta.
-- ════════════════════════════════════════════════════════════════════════

-- ── Tables ───────────────────────────────────────────────────────────────
create table if not exists public.licenses (
  id                 uuid primary key default gen_random_uuid(),
  license_key        text not null unique,
  shop_name          text not null,
  owner_name         text,
  phone              text,
  plan               text not null default 'Standard',
  max_devices        int  not null default 1 check (max_devices >= 1),
  offline_grace_days int  not null default 7 check (offline_grace_days >= 0),
  expires_at         timestamptz not null,
  status             text not null default 'active' check (status in ('active','blocked')),
  admin_username     text not null,          -- shop ka login username
  pending_password   text,                   -- ek-martaba password (apply hote hi NULL ho jata hai)
  notice             text,                   -- client ko dikhne wala message
  notes              text,                   -- sirf aapke liye private notes
  created_at         timestamptz not null default now(),
  updated_at         timestamptz not null default now()
);

create table if not exists public.license_devices (
  id           uuid primary key default gen_random_uuid(),
  license_id   uuid not null references public.licenses(id) on delete cascade,
  machine_id   text not null,
  machine_name text,
  app_version  text,
  first_seen   timestamptz not null default now(),
  last_seen    timestamptz not null default now(),
  unique (license_id, machine_id)
);

create table if not exists public.super_admins (
  user_id uuid primary key references auth.users(id) on delete cascade
);

create or replace function public.touch_updated_at() returns trigger
language plpgsql as $$ begin new.updated_at = now(); return new; end $$;
drop trigger if exists licenses_touch on public.licenses;
create trigger licenses_touch before update on public.licenses
  for each row execute function public.touch_updated_at();

-- ── Row Level Security ───────────────────────────────────────────────────
alter table public.licenses        enable row level security;
alter table public.license_devices enable row level security;
alter table public.super_admins    enable row level security;

create or replace function public.is_super_admin() returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.super_admins where user_id = auth.uid());
$$;
revoke all on function public.is_super_admin() from public, anon;
grant execute on function public.is_super_admin() to authenticated;

drop policy if exists sa_licenses on public.licenses;
create policy sa_licenses on public.licenses for all to authenticated
  using (public.is_super_admin()) with check (public.is_super_admin());

drop policy if exists sa_devices on public.license_devices;
create policy sa_devices on public.license_devices for all to authenticated
  using (public.is_super_admin()) with check (public.is_super_admin());

drop policy if exists sa_self on public.super_admins;
create policy sa_self on public.super_admins for select to authenticated
  using (user_id = auth.uid());

revoke all on public.licenses, public.license_devices, public.super_admins from anon;

-- ── Plans, prices and payments ───────────────────────────────────────────
-- Safe to run again on an existing project: everything is "if not exists".
alter table public.licenses add column if not exists price numeric(12,2) not null default 0;  -- monthly price for this client

create table if not exists public.plans (
  id          uuid primary key default gen_random_uuid(),
  name        text not null unique,
  price       numeric(12,2) not null default 0 check (price >= 0),   -- price per month
  max_devices int not null default 1 check (max_devices >= 1),
  created_at  timestamptz not null default now()
);

create table if not exists public.payments (
  id         uuid primary key default gen_random_uuid(),
  license_id uuid references public.licenses(id) on delete set null,
  shop_name  text not null,          -- kept even if the license is deleted later
  plan       text,
  amount     numeric(12,2) not null check (amount >= 0),
  months     int,
  note       text,
  paid_at    timestamptz not null default now()
);
create index if not exists payments_paid_at_idx on public.payments (paid_at desc);

alter table public.plans    enable row level security;
alter table public.payments enable row level security;

drop policy if exists sa_plans on public.plans;
create policy sa_plans on public.plans for all to authenticated
  using (public.is_super_admin()) with check (public.is_super_admin());
drop policy if exists sa_payments on public.payments;
create policy sa_payments on public.payments for all to authenticated
  using (public.is_super_admin()) with check (public.is_super_admin());
revoke all on public.plans, public.payments from anon;

insert into public.plans (name, price, max_devices) values
  ('Basic', 0, 1), ('Standard', 0, 1), ('Premium', 0, 3)
on conflict (name) do nothing;

-- ── Internal helper (public ko access nahi) ──────────────────────────────
create or replace function public._license_payload(l public.licenses) returns jsonb
language sql stable set search_path = public as $$
  select jsonb_build_object(
    'status', case when l.status = 'blocked' then 'blocked'
                   when l.expires_at < now() then 'expired' else 'active' end,
    'shop_name', l.shop_name, 'owner_name', l.owner_name, 'plan', l.plan,
    'expires_at', l.expires_at, 'offline_grace_days', l.offline_grace_days,
    'notice', l.notice, 'admin_username', l.admin_username,
    'pending_password', l.pending_password, 'server_time', now());
$$;
revoke all on function public._license_payload(public.licenses) from public, anon, authenticated;

-- ── RPC 1: pehli dafa activate (computer register hota hai) ──────────────
create or replace function public.activate_license(
  p_key text, p_machine_id text, p_machine_name text default null, p_app_version text default null
) returns jsonb language plpgsql security definer set search_path = public as $$
declare l public.licenses; dev_id uuid; dev_count int;
begin
  if p_key is null or p_machine_id is null or length(p_machine_id) < 8 then
    return jsonb_build_object('ok', false, 'error', 'invalid_request');
  end if;
  select * into l from public.licenses where license_key = upper(trim(p_key));
  if not found then return jsonb_build_object('ok', false, 'error', 'invalid_key'); end if;
  if l.status = 'blocked' then return jsonb_build_object('ok', false, 'error', 'blocked'); end if;

  select id into dev_id from public.license_devices where license_id = l.id and machine_id = p_machine_id;
  if dev_id is null then
    select count(*) into dev_count from public.license_devices where license_id = l.id;
    if dev_count >= l.max_devices then
      return jsonb_build_object('ok', false, 'error', 'device_limit', 'max_devices', l.max_devices);
    end if;
    insert into public.license_devices (license_id, machine_id, machine_name, app_version)
    values (l.id, p_machine_id, p_machine_name, p_app_version);
  else
    update public.license_devices
       set last_seen = now(), machine_name = coalesce(p_machine_name, machine_name),
           app_version = coalesce(p_app_version, app_version)
     where id = dev_id;
  end if;
  return jsonb_build_object('ok', true) || public._license_payload(l);
end $$;

-- ── RPC 2: regular check (har app start + har 30 min) ────────────────────
create or replace function public.check_license(
  p_key text, p_machine_id text, p_app_version text default null
) returns jsonb language plpgsql security definer set search_path = public as $$
declare l public.licenses; dev_id uuid;
begin
  select * into l from public.licenses where license_key = upper(trim(coalesce(p_key, '')));
  if not found then return jsonb_build_object('ok', false, 'error', 'invalid_key'); end if;
  select id into dev_id from public.license_devices where license_id = l.id and machine_id = p_machine_id;
  if dev_id is null then return jsonb_build_object('ok', false, 'error', 'not_activated'); end if;
  update public.license_devices set last_seen = now(), app_version = coalesce(p_app_version, app_version) where id = dev_id;
  return jsonb_build_object('ok', true) || public._license_payload(l);
end $$;

-- ── RPC 3: password apply ho gaya — ek-martaba password server se hata do ─
create or replace function public.ack_credentials(p_key text, p_machine_id text)
returns jsonb language plpgsql security definer set search_path = public as $$
declare l public.licenses;
begin
  select * into l from public.licenses where license_key = upper(trim(coalesce(p_key, '')));
  if not found then return jsonb_build_object('ok', false); end if;
  if not exists (select 1 from public.license_devices where license_id = l.id and machine_id = p_machine_id) then
    return jsonb_build_object('ok', false);
  end if;
  update public.licenses set pending_password = null where id = l.id;
  return jsonb_build_object('ok', true);
end $$;

revoke all on function public.activate_license(text, text, text, text) from public;
revoke all on function public.check_license(text, text, text)          from public;
revoke all on function public.ack_credentials(text, text)              from public;
grant execute on function public.activate_license(text, text, text, text) to anon, authenticated;
grant execute on function public.check_license(text, text, text)          to anon, authenticated;
grant execute on function public.ack_credentials(text, text)              to anon, authenticated;

-- ════════════════════════════════════════════════════════════════════════
--  AAKHRI STEP (sirf ek dafa):
--  1) Dashboard → Authentication → Users → "Add user" → apna email + password
--     (Auto Confirm User ON rakhein). Yehi Super Admin app ka login hoga.
--  2) Neeche ki line mein apna email likh kar alag se Run karein:
--
--  insert into public.super_admins (user_id)
--  select id from auth.users where email = 'YOUR-EMAIL@example.com';
--
--  3) Authentication → Sign In / Providers → "Allow new users to sign up" OFF
--     karein, taake koi aur khud account bana kar admin na ban sake.
-- ════════════════════════════════════════════════════════════════════════
