import { useCallback, useEffect, useState } from "react";
import { cloudBackupApi } from "../../api/client";

const fmtSize = (n) => {
  const b = Number(n) || 0;
  return b >= 1048576 ? `${(b / 1048576).toFixed(1)} MB` : `${Math.max(1, Math.round(b / 1024))} KB`;
};
const fmtTime = (t) =>
  new Date(t).toLocaleString("en-GB", { day: "2-digit", month: "short", year: "numeric", hour: "2-digit", minute: "2-digit" });

function Cloud() {
  return (
    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M18 10h-1.26A8 8 0 1 0 9 20h9a5 5 0 0 0 0-10z" />
    </svg>
  );
}

export default function CloudBackupCard() {
  const [status, setStatus] = useState(null);
  const [backups, setBackups] = useState([]);
  const [listError, setListError] = useState("");
  const [msg, setMsg] = useState({ type: "", text: "" });
  const [busy, setBusy] = useState(false);
  const [confirm, setConfirm] = useState(null); // backup being restored
  const [typed, setTyped] = useState("");

  const loadList = useCallback(async () => {
    setListError("");
    try {
      setBackups(await cloudBackupApi.list());
    } catch (e) {
      setListError(e.message);
    }
  }, []);

  useEffect(() => {
    let alive = true;
    cloudBackupApi.status().then((s) => alive && setStatus(s)).catch(() => {});
    const off = cloudBackupApi.onChange((s) => alive && setStatus(s));
    return () => { alive = false; off(); };
  }, []);
  useEffect(() => { if (status?.allowed) loadList(); }, [status?.allowed, loadList]);

  const backupNow = async () => {
    setMsg({ type: "", text: "" });
    setBusy(true);
    try {
      await cloudBackupApi.now();
      setMsg({ type: "ok", text: "Backup uploaded to the cloud." });
      loadList();
    } catch (e) {
      setMsg({ type: "error", text: e.message });
    } finally {
      setBusy(false);
      cloudBackupApi.status().then(setStatus).catch(() => {});
    }
  };

  const toggleAuto = async () => setStatus(await cloudBackupApi.setAuto(!status.auto));

  const doRestore = async () => {
    setBusy(true);
    setMsg({ type: "", text: "" });
    try {
      await cloudBackupApi.restore(confirm.id); // the app restarts when this succeeds
    } catch (e) {
      setMsg({ type: "error", text: e.message });
      setBusy(false);
      setConfirm(null);
      setTyped("");
    }
  };

  const restoreFile = async () => {
    setMsg({ type: "", text: "" });
    if (!window.confirm("Restoring from a file will replace ALL current data on this computer. A safety copy is saved first and the app will restart. Continue?")) return;
    try {
      const r = await cloudBackupApi.restoreFromFile();
      if (r?.canceled) return;
    } catch (e) {
      setMsg({ type: "error", text: e.message });
    }
  };

  const running = busy || status?.running;
  const pct = status?.progress?.percent ?? 0;

  return (
    <div className="bg-white rounded-2xl border border-slate-100 shadow-sm overflow-hidden">
      <div className="flex items-center gap-3 px-5 py-4 border-b border-slate-100 bg-slate-50/60">
        <div className="w-8 h-8 rounded-xl bg-blue-100 flex items-center justify-center text-blue-600"><Cloud /></div>
        <div>
          <h2 className="font-bold text-slate-800 leading-tight">Cloud Backup</h2>
          <p className="text-xs text-slate-400">Your shop data is stored safely online, so a broken or lost computer never loses your business.</p>
        </div>
      </div>

      <div className="p-5 space-y-4">
        {!status && <p className="text-sm text-slate-400">Loading...</p>}

        {status && !status.allowed && (
          <div className="px-4 py-3 rounded-xl bg-amber-50 border border-amber-200 text-sm text-amber-800">
            {status.reason === "plan"
              ? "Cloud backup is not included in your current plan. Contact your service provider to enable it."
              : "Cloud backup is unavailable because the license is not active."}
          </div>
        )}

        {status?.allowed && (
          <>
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div>
                <p className="text-xs font-semibold text-slate-400">Last backup</p>
                <p className="text-sm font-semibold text-slate-800">
                  {status.lastSuccessAt ? `${fmtTime(status.lastSuccessAt)} • ${fmtSize(status.lastSize)}` : "No backup yet"}
                </p>
              </div>
              <label className="flex items-center gap-2.5 cursor-pointer select-none">
                <span className="text-sm text-slate-600">Automatic daily backup</span>
                <button
                  type="button"
                  onClick={toggleAuto}
                  className={`relative w-10 h-6 rounded-full transition-colors ${status.auto ? "bg-blue-600" : "bg-slate-300"}`}
                  aria-pressed={status.auto}
                >
                  <span className={`absolute top-0.5 w-5 h-5 bg-white rounded-full shadow transition-all ${status.auto ? "left-[18px]" : "left-0.5"}`} />
                </button>
              </label>
            </div>

            {status.lastError && !running && (
              <p className="text-xs text-red-500 font-medium">Last attempt failed: {status.lastError}</p>
            )}

            {running && status.progress && (
              <div>
                <div className="flex justify-between text-xs text-slate-500 mb-1"><span>{status.progress.label}</span><span>{pct}%</span></div>
                <div className="h-2 rounded-full bg-slate-100 overflow-hidden"><div className="h-full bg-blue-600 transition-all" style={{ width: `${pct}%` }} /></div>
              </div>
            )}

            <div className="flex flex-wrap gap-2">
              <button onClick={backupNow} disabled={running} className="px-4 py-2.5 rounded-xl text-white text-sm font-bold disabled:opacity-60" style={{ background: "#1D6FDB" }}>
                {running ? "Working..." : "Back up now"}
              </button>
              <button onClick={loadList} disabled={running} className="px-4 py-2.5 rounded-xl text-sm font-semibold text-slate-600 bg-slate-100 hover:bg-slate-200 disabled:opacity-60">Refresh list</button>
              <button onClick={restoreFile} disabled={running} className="px-4 py-2.5 rounded-xl text-sm font-semibold text-slate-600 bg-slate-100 hover:bg-slate-200 disabled:opacity-60">Restore from a file...</button>
            </div>

            {msg.text && <p className={`text-sm font-medium ${msg.type === "ok" ? "text-emerald-600" : "text-red-500"}`}>{msg.text}</p>}

            <div>
              <p className="text-sm font-semibold text-slate-700 mb-2">Backups in the cloud <span className="text-xs font-normal text-slate-400">(newest {status.keep} are kept)</span></p>
              {listError && <p className="text-xs text-red-500 mb-2">{listError}</p>}
              {!listError && backups.length === 0 && <p className="text-sm text-slate-400">No backups in the cloud yet.</p>}
              <div className="space-y-2">
                {backups.map((b) => (
                  <div key={b.id} className="flex items-center justify-between gap-3 px-3.5 py-2.5 rounded-xl bg-slate-50">
                    <div className="min-w-0">
                      <p className="text-sm font-semibold text-slate-700">{fmtTime(b.created_at)}</p>
                      <p className="text-xs text-slate-400 truncate">{fmtSize(b.size_bytes)}{b.machine_name ? ` • from ${b.machine_name}` : ""}</p>
                    </div>
                    <button onClick={() => { setConfirm(b); setTyped(""); }} disabled={running} className="shrink-0 px-3 py-1.5 rounded-lg text-xs font-bold text-red-600 bg-red-50 hover:bg-red-100 disabled:opacity-60">Restore</button>
                  </div>
                ))}
              </div>
            </div>
          </>
        )}
      </div>

      {confirm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm">
          <div className="bg-white rounded-2xl w-full max-w-md shadow-2xl p-6">
            <h3 className="font-bold text-slate-800 text-lg mb-1">Restore this backup?</h3>
            <p className="text-sm text-slate-500">
              This will <b>replace all data on this computer</b> with the backup from <b>{fmtTime(confirm.created_at)}</b>. Anything you entered after that time will be lost.
              A safety copy of your current data is saved first, and the app will restart.
            </p>
            <p className="text-xs font-semibold text-slate-500 mt-4 mb-1.5">Type RESTORE to confirm</p>
            <input value={typed} onChange={(e) => setTyped(e.target.value)} autoFocus className="w-full px-3 py-2.5 rounded-xl text-sm bg-slate-50 border border-slate-200 outline-none focus:border-red-400" />
            {running && status?.progress && <p className="text-xs text-slate-500 mt-3">{status.progress.label} {pct}%</p>}
            <div className="flex gap-3 mt-5">
              <button onClick={() => { setConfirm(null); setTyped(""); }} disabled={running} className="flex-1 py-2.5 rounded-xl border border-slate-200 text-sm font-semibold text-slate-600 hover:bg-slate-50 disabled:opacity-60">Cancel</button>
              <button onClick={doRestore} disabled={typed !== "RESTORE" || running} className="flex-1 py-2.5 rounded-xl bg-red-500 hover:bg-red-600 text-white text-sm font-bold disabled:opacity-50">
                {running ? "Restoring..." : "Restore"}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
