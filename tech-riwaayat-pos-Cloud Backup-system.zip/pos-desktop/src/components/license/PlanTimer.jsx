import { useEffect, useRef, useState } from "react";

// Live countdown to the license/plan expiry. Uses the server-corrected clock
// offset (skewMs) so changing the PC's date does not change the timer.
function useCountdown(license, onExpire) {
  const target = license?.expiresAt ? Date.parse(license.expiresAt) : null;
  const skew = license?.skewMs || 0;
  const [left, setLeft] = useState(() => (target ? target - (Date.now() + skew) : null));
  const fired = useRef(false);

  useEffect(() => {
    if (!target) return undefined;
    fired.current = false;
    const tick = () => {
      const ms = target - (Date.now() + skew);
      setLeft(ms);
      if (ms <= 0 && !fired.current) {
        fired.current = true;
        onExpire?.();
      }
    };
    tick();
    const id = setInterval(tick, 1000);
    return () => clearInterval(id);
  }, [target, skew, onExpire]);

  return left;
}

export function splitTime(ms) {
  const s = Math.max(0, Math.floor(ms / 1000));
  return {
    d: Math.floor(s / 86400),
    h: Math.floor((s % 86400) / 3600),
    m: Math.floor((s % 3600) / 60),
    s: s % 60,
  };
}
const pad = (n) => String(n).padStart(2, "0");

export function formatCountdown(ms) {
  const t = splitTime(ms);
  return `${t.d}d ${pad(t.h)}h ${pad(t.m)}m ${pad(t.s)}s`;
}

const tone = (ms) =>
  ms <= 86400000 ? "bg-red-50 text-red-600 border-red-200"
  : ms <= 7 * 86400000 ? "bg-amber-50 text-amber-700 border-amber-200"
  : "bg-emerald-50 text-emerald-700 border-emerald-200";

// Small pill for the top bar
export function PlanTimerChip({ license, onExpire }) {
  const left = useCountdown(license, onExpire);
  if (left == null) return null;
  return (
    <div
      className={`hidden md:flex items-center gap-2 px-3 py-2 rounded-xl border text-xs font-semibold ${tone(left)}`}
      title={`${license.plan || "Plan"} — expires ${new Date(license.expiresAt).toLocaleString()}`}
    >
      <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <circle cx="12" cy="12" r="10" /><polyline points="12 6 12 12 16 14" />
      </svg>
      <span>{license.plan || "Plan"}</span>
      <span className="font-mono tabular-nums">{left > 0 ? formatCountdown(left) : "Expired"}</span>
    </div>
  );
}

// Bigger card for the profile page
export function PlanTimerCard({ license, onExpire }) {
  const left = useCountdown(license, onExpire);
  if (left == null) return null;
  const t = splitTime(left);
  const box = (v, label) => (
    <div className="flex-1 rounded-xl bg-white/15 py-2.5 text-center">
      <p className="text-xl font-bold tabular-nums leading-none">{pad(v)}</p>
      <p className="text-[10px] opacity-70 mt-1">{label}</p>
    </div>
  );
  return (
    <div className="p-4 rounded-2xl bg-gradient-to-br from-blue-600 to-indigo-700 text-white">
      <div className="flex items-center justify-between">
        <div>
          <p className="text-xs font-semibold opacity-70">Current Plan</p>
          <p className="font-bold text-lg leading-tight">{license.plan || "Standard"}</p>
        </div>
        <span className="text-[11px] font-semibold px-2.5 py-1 rounded-full bg-white/20">
          {left > 0 ? "Active" : "Expired"}
        </span>
      </div>
      <div className="flex gap-2 mt-4">
        {box(t.d, "Days")}{box(t.h, "Hours")}{box(t.m, "Minutes")}{box(t.s, "Seconds")}
      </div>
      <p className="text-xs opacity-80 mt-3">
        Valid until {new Date(license.expiresAt).toLocaleDateString("en-GB", { day: "2-digit", month: "short", year: "numeric" })}
      </p>
    </div>
  );
}
