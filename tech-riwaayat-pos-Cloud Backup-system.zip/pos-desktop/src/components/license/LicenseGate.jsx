import { useState } from "react";

// Poori screen ka lock/activation page. Jab tak license "active" nahi hota,
// app ka baqi hissa (login, POS, data) dikhaya hi nahi jata — aur main
// process bhi data API band rakhta hai, isliye isay bypass karna mushkil hai.

const TITLES = {
  unactivated: "Activate Your Software",
  tampered: "Activate License Again",
  not_configured: "License Settings Missing",
  blocked: "License Blocked",
  expired: "License Expired",
  verify_required: "License Verification Required",
  needs_password: "Account Not Ready",
};
const ACCENT = {
  blocked: "bg-red-50 text-red-600",
  expired: "bg-amber-50 text-amber-600",
  verify_required: "bg-blue-50 text-blue-600",
  needs_password: "bg-blue-50 text-blue-600",
  not_configured: "bg-red-50 text-red-600",
};

export default function LicenseGate({ license, onActivate, onRefresh, onBackup }) {
  const [key, setKey] = useState("");
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState({ type: "", text: "" });

  const state = license?.state || "unactivated";
  const needsKey = state === "unactivated" || state === "tampered";
  const canBackup = !needsKey && state !== "not_configured";

  const run = async (fn) => {
    setBusy(true);
    setMsg({ type: "", text: "" });
    try {
      await fn();
    } catch (e) {
      setMsg({ type: "error", text: e.message || "Something went wrong." });
    } finally {
      setBusy(false);
    }
  };

  const activate = () => run(async () => {
    if (key.trim().length < 8) throw new Error("Please enter a valid license key.");
    await onActivate(key.trim());
  });
  const refresh = () => run(async () => {
    const s = await onRefresh();
    if (s && s.state !== "active") setMsg({ type: "info", text: s.error || "The license is still not active." });
  });
  const backup = () => run(async () => {
    const r = await onBackup();
    if (r?.ok) setMsg({ type: "ok", text: `Backup saved: ${r.path}` });
    else if (!r?.canceled) throw new Error(r?.error || "Backup failed.");
  });

  return (
    <div className="min-h-screen flex items-center justify-center bg-slate-100 p-4" style={{ fontFamily: "'Plus Jakarta Sans','DM Sans','Segoe UI',sans-serif" }}>
      <div className="w-full max-w-[460px] rounded-2xl shadow-2xl shadow-slate-300/60 border border-slate-200/60 bg-white p-8">
        <div className="flex items-center gap-2.5 mb-6">
          <img src="./logo.png" alt="Tech Riwaayat POS" className="w-9 h-9 rounded-xl shadow-sm" />
          <span className="font-bold text-slate-800 text-base tracking-tight">Tech Riwaayat POS</span>
        </div>

        <div className="mb-5">
          <h1 className="text-[21px] font-extrabold text-slate-800 tracking-tight leading-tight">{TITLES[state] || "License"}</h1>
          {license?.shopName && <p className="text-xs text-slate-400 mt-1">{license.shopName}</p>}
        </div>

        <div className={`px-3.5 py-3 rounded-xl text-[13px] font-medium leading-relaxed ${ACCENT[state] || "bg-slate-50 text-slate-600"}`}>
          {license?.message}
        </div>
        {license?.error && !msg.text && <p className="text-xs text-red-500 mt-2 font-medium">{license.error}</p>}

        {needsKey && (
          <div className="mt-5">
            <label className="block text-[10px] font-bold uppercase tracking-widest text-slate-400 mb-1.5">License Key</label>
            <input
              value={key}
              onChange={(e) => setKey(e.target.value.toUpperCase())}
              onKeyDown={(e) => e.key === "Enter" && !busy && activate()}
              placeholder="TRP-XXXX-XXXX-XXXX"
              spellCheck={false}
              autoFocus
              className="w-full px-3 py-2.5 rounded-xl text-sm outline-none bg-slate-50 border border-slate-200 font-mono font-semibold tracking-wider text-slate-800 placeholder-slate-300 focus:bg-white focus:border-blue-500 focus:ring-2 focus:ring-blue-100"
            />
            <button onClick={activate} disabled={busy} className="w-full mt-4 py-2.5 rounded-xl text-white text-sm font-bold disabled:opacity-60" style={{ background: "#1D6FDB" }}>
              {busy ? "Please wait..." : "Activate"}
            </button>
          </div>
        )}

        {!needsKey && state !== "not_configured" && (
          <button onClick={refresh} disabled={busy} className="w-full mt-5 py-2.5 rounded-xl text-white text-sm font-bold disabled:opacity-60" style={{ background: "#1D6FDB" }}>
            {busy ? "Checking..." : "Check Again"}
          </button>
        )}

        {canBackup && (
          <button onClick={backup} disabled={busy} className="w-full mt-2.5 py-2.5 rounded-xl text-slate-600 text-sm font-semibold bg-slate-100 hover:bg-slate-200 disabled:opacity-60">
            Back Up My Data
          </button>
        )}

        {msg.text && (
          <p className={`mt-3 text-xs font-medium break-words ${msg.type === "ok" ? "text-emerald-600" : msg.type === "info" ? "text-slate-500" : "text-red-500"}`}>{msg.text}</p>
        )}

        <div className="mt-6 pt-4 border-t border-slate-100 flex items-center justify-between gap-3">
          <p className="text-[11px] text-slate-400">{license?.support}</p>
          {license?.machine && <p className="text-[10px] text-slate-300 font-mono shrink-0">ID {license.machine}</p>}
        </div>
      </div>
    </div>
  );
}
