// ── API client (talks to the local SQLite database via Electron's main
// process — no internet, no external server, everything stays on this
// computer). Kept the same get/post/put/delete shape as before so none of
// the existing components/hooks needed to change.
async function request(path, { method = "GET", body } = {}) {
  if (!window.electronAPI) {
    throw new Error("electronAPI not available — this app must run inside the Electron desktop shell.");
  }
  return window.electronAPI.request(method, path, body);
}

export const api = {
  get: (path) => request(path),
  post: (path, body) => request(path, { method: "POST", body }),
  put: (path, body) => request(path, { method: "PUT", body }),
  delete: (path) => request(path, { method: "DELETE" }),
};

// ── Local auth (bridges to electron/routes/auth.js via preload.cjs) ──────
// Login only. Register, forgot-password and change-password were removed:
// accounts and password resets are managed from the Super Admin app.
export const localAuth = {
  login: (username, password) => window.electronAPI.login(username, password),
};

// ── Cloud backup (electron/cloudBackup.js) ───────────────────────────────
export const cloudBackupApi = {
  status: () => window.electronAPI.cloudBackup.status(),
  setAuto: (v) => window.electronAPI.cloudBackup.setAuto(v),
  now: () => window.electronAPI.cloudBackup.now(),
  list: () => window.electronAPI.cloudBackup.list(),
  restore: (id) => window.electronAPI.cloudBackup.restore(id),
  restoreFromFile: () => window.electronAPI.cloudBackup.restoreFromFile(),
  onChange: (cb) => window.electronAPI.cloudBackup.onChange(cb),
};

// ── License (Supabase-backed; logic electron/license.js mein hai) ─────────
export const licenseApi = {
  status: () => window.electronAPI.licenseStatus(),
  refresh: () => window.electronAPI.licenseRefresh(),
  activate: (key) => window.electronAPI.licenseActivate(key),
  backupDb: () => window.electronAPI.licenseBackupDb(),
  onChange: (cb) => window.electronAPI.onLicenseChange(cb),
};
