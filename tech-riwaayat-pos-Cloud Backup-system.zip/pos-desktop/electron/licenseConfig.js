// ─────────────────────────────────────────────────────────────────────────
//  LICENSE SETTINGS — installer banane se PEHLE yeh 4 cheezein bhar dein.
// ─────────────────────────────────────────────────────────────────────────
//  Supabase Dashboard → Project Settings → API se URL aur anon/publishable
//  key copy karein. (service_role key yahan KABHI na lagayein!)
export const SUPABASE_URL = "https://mymorgvlnkggjnuhtjra.supabase.co";
export const SUPABASE_ANON_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im15bW9yZ3ZsbmtnZ2pudWh0anJhIiwicm9sZSI6ImFub24iLCJpYXQiOjE3OTA2NjEyNTgsImV4cCI6MjEwNjIzNzI1OH0.TUCHuKbcePUN5eRTagyLNQMWIfKBF4uxPoMJbtzgAF8";

//  Koi bhi lamba random text (30+ characters). Yeh local license file ko
//  tamper-proof rakhta hai. Ek baar set karke installer banayein; baad mein
//  badla to sab clients ko dobara activate karna parega.
export const LICENSE_SECRET = "2dYLgosqPrXuTy7r1gMTVv3yUyLVZDUMeWqI27oFQCSQF3HSvo1WdQ";

//  Lock screen par clients ko yeh rabta dikhega.
export const SUPPORT_CONTACT = "Need help? Contact your service provider: 03XX-XXXXXXX";
