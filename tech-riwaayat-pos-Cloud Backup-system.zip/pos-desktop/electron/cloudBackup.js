// ── Cloud backup (shop database -> Supabase) ─────────────────────────────
// The database file is compressed (gzip), cut into small chunks and uploaded
// through the license-checked functions in supabase/schema.sql. Nothing here
// can touch another shop's backups: the server checks the license key and
// this computer's registration on every call.
//
//   backupNow()       compress + upload (manual, or automatic once a day)
//   listBackups()     the newest backups stored for this license
//   restoreBackup()   download + verify + replace the local database
//   restoreFromBytes  the same replace step for a local .db file
import fs from "fs";
import path from "path";
import zlib from "zlib";
import crypto from "crypto";
import { promisify } from "util";
import * as license from "./license.js";

const gzip = promisify(zlib.gzip);
const gunzip = promisify(zlib.gunzip);

const CHUNK_RAW = 384 * 1024;          // 384 KB -> ~512 KB base64 (server limit: 1,000,000 chars)
const MAX_COMPRESSED = 40 * 1024 * 1024;
const DAY = 86400000;
const SQLITE_MAGIC = "SQLite format 3\u0000";

let opts = null;
let state = { auto: true, lastSuccessAt: 0, lastAttemptAt: 0, lastError: null, lastSize: 0 };
let progress = null;   // { label, percent }
let running = null;
let stateFile = null;

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

export function initCloudBackup(o) {
  // o: { userDataPath, dbPath, flush(), applyRestore(buffer), onChange(status), version }
  opts = o;
  stateFile = path.join(o.userDataPath, "cloud-backup.json");
  try { state = { ...state, ...JSON.parse(fs.readFileSync(stateFile, "utf8")) }; } catch { /* first run */ }
}
function persist() {
  try { fs.writeFileSync(stateFile, JSON.stringify(state)); } catch { /* ignore */ }
}
function setProgress(label, percent) {
  progress = label ? { label, percent: Math.max(0, Math.min(100, Math.round(percent))) } : null;
  opts?.onChange?.(getStatus());
}

export function getStatus() {
  const lic = license.getState();
  const allowed = lic.state === "active" && lic.backupEnabled !== false;
  return {
    allowed,
    reason: lic.state !== "active" ? "license" : lic.backupEnabled === false ? "plan" : null,
    auto: state.auto,
    lastSuccessAt: state.lastSuccessAt,
    lastAttemptAt: state.lastAttemptAt,
    lastError: state.lastError,
    lastSize: state.lastSize,
    keep: lic.backupKeep || 5,
    running: !!running,
    progress,
  };
}

export function setAuto(v) {
  state.auto = !!v;
  persist();
  opts?.onChange?.(getStatus());
  return getStatus();
}

// One server call with retries for flaky networks. Server-side refusals
// ({ok:false,error}) are turned into readable errors and never retried.
async function call(fn, args, { timeout = 60000, tries = 3 } = {}) {
  let lastErr;
  for (let i = 0; i < tries; i++) {
    try {
      const res = await license.licenseRpc(fn, args, timeout);
      if (res && res.ok === false) {
        const e = new Error(license.errorText(res.error) || `Cloud backup failed (${res.error}).`);
        e.final = true;
        throw e;
      }
      return res;
    } catch (e) {
      lastErr = e;
      if (e.final || !license.isNetworkError(e) || i === tries - 1) break;
      await sleep(1500 * (i + 1));
    }
  }
  if (license.isNetworkError(lastErr)) throw new Error("No internet connection to the cloud. Please try again when you are online.");
  throw lastErr;
}

function guard() {
  const lic = license.getState();
  if (lic.state !== "active") throw new Error("The license is not active.");
  if (lic.backupEnabled === false) throw new Error("Cloud backup is not included in your plan.");
  const creds = license.getCreds();
  if (!creds) throw new Error("This computer is not activated.");
  return creds;
}

export function backupNow(reason = "manual") {
  if (running) return Promise.reject(new Error("A backup is already running."));
  running = (async () => {
    state.lastAttemptAt = Date.now();
    try {
      const { key, machineId } = guard();
      setProgress("Preparing backup...", 2);
      opts.flush();                                   // write pending changes to the file first
      const raw = fs.readFileSync(opts.dbPath);
      const packed = await gzip(raw, { level: 6 });
      if (packed.length > MAX_COMPRESSED) throw new Error(license.errorText("too_large"));
      const sha = crypto.createHash("sha256").update(packed).digest("hex");
      const total = Math.max(1, Math.ceil(packed.length / CHUNK_RAW));

      const begin = await call("backup_begin", {
        p_key: key, p_machine_id: machineId, p_chunks: total, p_size: packed.length, p_raw: raw.length, p_sha: sha,
        p_machine_name: (await import("os")).hostname(), p_app_version: opts.version || "1.0.0",
      }, { timeout: 20000 });

      for (let i = 0; i < total; i++) {
        const part = packed.subarray(i * CHUNK_RAW, (i + 1) * CHUNK_RAW);
        await call("backup_put_chunk", {
          p_key: key, p_machine_id: machineId, p_backup_id: begin.backup_id, p_idx: i, p_data: part.toString("base64"),
        });
        setProgress(`Uploading... (${i + 1}/${total})`, 5 + ((i + 1) / total) * 90);
      }
      await call("backup_finish", { p_key: key, p_machine_id: machineId, p_backup_id: begin.backup_id }, { timeout: 30000 });

      state.lastSuccessAt = Date.now();
      state.lastSize = packed.length;
      state.lastError = null;
      return { size: packed.length, rawSize: raw.length, reason };
    } catch (e) {
      state.lastError = e.message;
      throw e;
    } finally {
      persist();
    }
  })().finally(() => {
    running = null;
    setProgress(null);
  });
  return running;
}

export async function listBackups() {
  const { key, machineId } = guard();
  const res = await call("backup_list", { p_key: key, p_machine_id: machineId }, { timeout: 20000 });
  return res.backups || [];
}

// Replace step for a raw (uncompressed) SQLite file — used by cloud restore
// and by "restore from a .db file".
export function restoreFromBytes(bytes) {
  if (!Buffer.isBuffer(bytes)) bytes = Buffer.from(bytes);
  if (bytes.length < 1024 || bytes.subarray(0, 16).toString("latin1") !== SQLITE_MAGIC)
    throw new Error("This is not a valid POS database file.");
  opts.applyRestore(bytes);      // makes a safety copy, swaps the file, restarts the app
}

export function restoreBackup(backupId) {
  if (running) return Promise.reject(new Error("A backup is already running."));
  running = (async () => {
    const { key, machineId } = guard();
    setProgress("Reading backup info...", 2);
    const meta = (await listBackups()).find((b) => b.id === backupId);
    if (!meta) throw new Error("That backup is no longer available.");
    const parts = [];
    for (let i = 0; i < meta.chunks; i++) {
      const c = await call("backup_get_chunk", { p_key: key, p_machine_id: machineId, p_backup_id: backupId, p_idx: i });
      parts.push(Buffer.from(c.data, "base64"));
      setProgress(`Downloading... (${i + 1}/${meta.chunks})`, 5 + ((i + 1) / meta.chunks) * 85);
    }
    const packed = Buffer.concat(parts);
    if (packed.length !== Number(meta.size_bytes)) throw new Error("The downloaded backup is incomplete. Please try again.");
    if (meta.sha256 && crypto.createHash("sha256").update(packed).digest("hex") !== meta.sha256)
      throw new Error("The downloaded backup is corrupted (checksum mismatch). Nothing was changed.");
    setProgress("Restoring...", 95);
    const raw = await gunzip(packed);
    restoreFromBytes(raw);       // the app restarts here
    return { ok: true };
  })().finally(() => {
    running = null;
    setProgress(null);
  });
  return running;
}

// Automatic daily backup while the app is open.
let timers = [];
async function maybeAuto() {
  if (!state.auto || running) return;
  const now = Date.now();
  if (now - state.lastSuccessAt < DAY || now - state.lastAttemptAt < 60 * 60 * 1000) return;
  const s = getStatus();
  if (!s.allowed) return;
  try { await backupNow("auto"); } catch { /* recorded in lastError, retried in an hour */ }
}
export function startCloudBackupScheduler() {
  timers.push(setTimeout(maybeAuto, 2 * 60 * 1000).unref?.());
  timers.push(setInterval(maybeAuto, 15 * 60 * 1000).unref?.());
}
export default { initCloudBackup, getStatus, setAuto, backupNow, listBackups, restoreBackup, restoreFromBytes, startCloudBackupScheduler };
