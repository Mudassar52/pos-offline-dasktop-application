import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

export default defineConfig({
  base: "./", // Electron file:// se load karta hai, isliye relative paths
  plugins: [react()],
  server: { port: 5174, strictPort: true },
});
