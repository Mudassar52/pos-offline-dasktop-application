import { useEffect, useState } from "react";
import { getClient, resetClient } from "./lib/supabase";
import Login from "./components/Login";
import Dashboard from "./components/Dashboard";
import { Spinner } from "./components/ui";

export default function App() {
  const [view, setView] = useState("boot"); // boot | login | app

  useEffect(() => {
    (async () => {
      try {
        const sb = getClient();
        const { data } = await sb.auth.getSession();
        if (data.session) {
          const { data: ok } = await sb.rpc("is_super_admin");
          if (ok) return setView("app");
          await sb.auth.signOut();
        }
      } catch { /* fall through to login */ }
      setView("login");
    })();
  }, []);

  if (view === "boot") return <div className="h-full flex items-center justify-center"><Spinner /></div>;
  if (view === "login") return <Login onLoggedIn={() => setView("app")} />;
  return (
    <Dashboard
      onLogout={async () => {
        await getClient().auth.signOut();
        resetClient();
        setView("login");
      }}
    />
  );
}
