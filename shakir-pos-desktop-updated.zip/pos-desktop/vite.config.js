import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

export default defineConfig({
  base: "./", // Electron loads index.html via file://, so paths must be relative
  plugins: [react()],
  server: {
    port: 5173,
    strictPort: true,
  },
});
