// IMPORTANT: this file must stay CommonJS (.cjs, require/module.exports —
// no import/export). Electron loads the preload script through Node's
// CommonJS loader regardless of the project's package.json "type" field;
// naming it .cjs guarantees that no matter what, so contextBridge actually
// runs and window.electronAPI shows up in the renderer.
const { contextBridge, ipcRenderer } = require("electron");

contextBridge.exposeInMainWorld("electronAPI", {
  // Generic data request — matches { method, path, body } -> data (or throws)
  request: async (method, path, body) => {
    const res = await ipcRenderer.invoke("api-request", { method, path, body });
    if (!res.ok) {
      const err = new Error(res.error || "Request failed");
      err.status = res.status;
      throw err;
    }
    return res.data;
  },

  // Local auth
  login: async (username, password) => {
    const res = await ipcRenderer.invoke("auth-login", { username, password });
    if (!res.ok) {
      const err = new Error(res.error || "Login failed");
      err.code = res.code;
      throw err;
    }
    return res.data;
  },
  register: async (username, password, name, securityQuestion, securityAnswer) => {
    const res = await ipcRenderer.invoke("auth-register", { username, password, name, securityQuestion, securityAnswer });
    if (!res.ok) {
      const err = new Error(res.error || "Registration failed");
      err.code = res.code;
      throw err;
    }
    return res.data;
  },
  updatePassword: async (userId, currentPassword, newPassword) => {
    const res = await ipcRenderer.invoke("auth-update-password", { userId, currentPassword, newPassword });
    if (!res.ok) {
      const err = new Error(res.error || "Password update failed");
      err.code = res.code;
      throw err;
    }
    return res.data;
  },
  getSecurityQuestion: async (username) => {
    const res = await ipcRenderer.invoke("auth-get-security-question", { username });
    if (!res.ok) {
      const err = new Error(res.error || "Could not find security question");
      err.code = res.code;
      throw err;
    }
    return res.data;
  },
  resetPassword: async (username, securityAnswer, newPassword) => {
    const res = await ipcRenderer.invoke("auth-reset-password", { username, securityAnswer, newPassword });
    if (!res.ok) {
      const err = new Error(res.error || "Password reset failed");
      err.code = res.code;
      throw err;
    }
    return res.data;
  },
});
