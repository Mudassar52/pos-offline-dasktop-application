import products from "./routes/products.js";
import customers from "./routes/customers.js";
import pos from "./routes/pos.js";
import invoices from "./routes/invoices.js";
import reports from "./routes/reports.js";
import settings from "./routes/settings.js";
import backup from "./routes/backup.js";
import suppliers from "./routes/suppliers.js";
import expenses from "./routes/expenses.js";
import returns from "./routes/returns.js";
import losses from "./routes/losses.js";

// Parses "/api/invoices/abc123?source=manual" into { path: "/api/invoices/abc123", query: { source: "manual" } }
function splitPath(fullPath) {
  const [path, qs] = fullPath.split("?");
  const query = {};
  if (qs) {
    for (const pair of qs.split("&")) {
      const [k, v] = pair.split("=");
      if (k) query[decodeURIComponent(k)] = decodeURIComponent(v || "");
    }
  }
  return { path, query };
}

// Handles one request: { method, path, body } -> result (thrown errors carry .status)
export function handleApiRequest({ method, path: fullPath, body }) {
  const { path, query } = splitPath(fullPath);
  const segs = path.split("/").filter(Boolean); // e.g. ["api","products","123","stock-in"]

  if (segs[0] !== "api") throw notFound();
  const resource = segs[1];

  // ── /api/bootstrap ───────────────────────────────────────────────────
  if (resource === "bootstrap" && method === "GET") {
    return {
      products: products.list(),
      customers: customers.list(),
      sales: pos.list(),
      manualInvoices: invoices.list(),
      settings: settings.getSettings(),
      suppliers: suppliers.list(),
      supplierTransactions: suppliers.listAllTransactions(),
      expenses: expenses.list(),
      returns: returns.list(),
      losses: losses.list(),
    };
  }

  // ── /api/products ────────────────────────────────────────────────────
  if (resource === "products") {
    if (segs.length === 2 && method === "GET") return products.list();
    if (segs.length === 2 && method === "POST") return products.create(body);
    if (segs.length === 3 && method === "PUT") return products.update(segs[2], body);
    if (segs.length === 3 && method === "DELETE") return products.remove(segs[2]);
    if (segs.length === 4 && segs[3] === "stock-in" && method === "POST") return products.stockIn(segs[2], body.qty);
    if (segs.length === 4 && segs[3] === "stock-out" && method === "POST") return products.stockOut(segs[2], body.qty);
  }

  // ── /api/customers ───────────────────────────────────────────────────
  if (resource === "customers") {
    if (segs.length === 2 && method === "GET") return customers.list();
    if (segs.length === 2 && method === "POST") return customers.create(body);
    if (segs.length === 3 && method === "PUT") return customers.update(segs[2], body);
    if (segs.length === 3 && method === "DELETE") return customers.remove(segs[2]);
    if (segs.length === 4 && segs[3] === "adjustments" && method === "POST") return customers.addAdjustment(segs[2], body);
    if (segs.length === 4 && segs[3] === "advance" && method === "POST") return customers.addAdvance(segs[2], body);
  }

  // ── /api/pos ─────────────────────────────────────────────────────────
  if (resource === "pos") {
    if (segs.length === 2 && method === "GET") return pos.list();
    if (segs.length === 3 && segs[2] === "sales" && method === "POST") return pos.recordSale(body);
    if (segs.length === 3 && segs[2] === "complete-sale" && method === "POST") return pos.completeSale(body.items || []);
    if (segs.length === 3 && method === "DELETE") return pos.deleteSale(segs[2]);
  }

  // ── /api/invoices ────────────────────────────────────────────────────
  if (resource === "invoices") {
    if (segs.length === 2 && method === "GET") return invoices.list();
    if (segs.length === 3 && segs[2] === "manual" && method === "POST") return invoices.createManual(body);
    if (segs.length === 3 && segs[2] === "receive-payment" && method === "POST") return invoices.receivePayment(body);
    if (segs.length === 3 && method === "PUT") return invoices.update(segs[2], query.source === "manual" ? "manual" : "pos", body);
    if (segs.length === 3 && method === "DELETE") return invoices.remove(segs[2], query.source === "manual" ? "manual" : "pos");
  }

  // ── /api/reports ─────────────────────────────────────────────────────
  if (resource === "reports" && method === "GET") {
    return reports.getReport(query.period || "month");
  }

  // ── /api/settings ────────────────────────────────────────────────────
  if (resource === "settings") {
    if (segs.length === 2 && method === "GET") return settings.getSettings();
    if (segs.length === 3 && segs[2] === "app-settings" && method === "PUT") return settings.updateAppSettings(body);
    if (segs.length === 3 && segs[2] === "invoice-settings" && method === "PUT") return settings.updateInvoiceSettings(body);
    if (segs.length === 3 && segs[2] === "categories" && method === "POST") return settings.addCategory(body.name);
    if (segs.length === 4 && segs[2] === "categories" && method === "DELETE") return settings.removeCategory(segs[3]);
    if (segs.length === 3 && segs[2] === "expense-categories" && method === "POST") return settings.addExpenseCategory(body.name);
    if (segs.length === 4 && segs[2] === "expense-categories" && method === "DELETE") return settings.removeExpenseCategory(segs[3]);
    if (segs.length === 3 && segs[2] === "expense-category-colors" && method === "PUT") return settings.setExpenseCategoryColor(body.name, body.color);
  }

  // ── /api/backup ──────────────────────────────────────────────────────
  if (resource === "backup" && segs[2] === "restore" && method === "POST") {
    return backup.restore(body);
  }

  // ── /api/suppliers ───────────────────────────────────────────────────
  if (resource === "suppliers") {
    if (segs.length === 2 && method === "GET") return suppliers.list();
    if (segs.length === 2 && method === "POST") return suppliers.create(body);
    if (segs.length === 3 && method === "PUT") return suppliers.update(segs[2], body);
    if (segs.length === 3 && method === "DELETE") return suppliers.remove(segs[2]);
    if (segs.length === 4 && segs[3] === "transactions" && method === "GET") return suppliers.listTransactions(segs[2]);
    if (segs.length === 4 && segs[3] === "transactions" && method === "POST") return suppliers.addTransaction(segs[2], body);
    if (segs.length === 5 && segs[3] === "transactions" && method === "DELETE") return suppliers.removeTransaction(segs[4]);
    if (segs.length === 4 && segs[3] === "purchase" && method === "POST") return suppliers.addPurchase(segs[2], body);
    if (segs.length === 4 && segs[3] === "purchases" && method === "GET") return suppliers.listPurchases(segs[2]);
    if (segs.length === 5 && segs[3] === "purchases" && method === "PUT") return suppliers.updatePurchase(segs[2], segs[4], body);
    if (segs.length === 4 && segs[3] === "pay" && method === "POST") return suppliers.payInvoice(segs[2], body);
    if (segs.length === 4 && segs[3] === "advance" && method === "POST") return suppliers.addAdvance(segs[2], body);
  }

  // ── /api/supplier-purchases (all suppliers' purchase invoices at once,
  // with items + payment history — used by the backup export) ───────────
  if (resource === "supplier-purchases" && method === "GET") {
    return suppliers.listAllPurchases();
  }

  // ── /api/supplier-transactions (all suppliers at once, for the frontend
  // to load in a single request instead of one call per supplier) ───────
  if (resource === "supplier-transactions" && method === "GET") {
    return suppliers.listAllTransactions();
  }

  // ── /api/expenses ────────────────────────────────────────────────────
  if (resource === "expenses") {
    if (segs.length === 2 && method === "GET") return expenses.list();
    if (segs.length === 2 && method === "POST") return expenses.create(body);
    if (segs.length === 3 && method === "PUT") return expenses.update(segs[2], body);
    if (segs.length === 3 && method === "DELETE") return expenses.remove(segs[2]);
  }

  // ── /api/returns (Order Returns) ────────────────────────────────────
  if (resource === "returns") {
    if (segs.length === 2 && method === "GET") return returns.list();
    if (segs.length === 2 && method === "POST") return returns.create(body);
    if (segs.length === 3 && method === "DELETE") return returns.remove(segs[2]);
  }

  // ── /api/losses (Loss Management) ───────────────────────────────────
  if (resource === "losses") {
    if (segs.length === 2 && method === "GET") return losses.list();
    if (segs.length === 2 && method === "POST") return losses.create(body);
    if (segs.length === 3 && method === "DELETE") return losses.remove(segs[2]);
  }

  throw notFound();
}

function notFound() {
  const err = new Error(`No route for this request`);
  err.status = 404;
  return err;
}

export default handleApiRequest;
