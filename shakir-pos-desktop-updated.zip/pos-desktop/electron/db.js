import initSqlJs from "sql.js";
import fs from "fs";
import path from "path";
import crypto from "crypto";
import { createRequire } from "module";

const require = createRequire(import.meta.url);

export function uuid() {
  return crypto.randomUUID();
}
export function nowIso() {
  return new Date().toISOString();
}

let sqlDb = null;
let dbFilePath = null;

const SCHEMA_SQL = `
CREATE TABLE IF NOT EXISTS users (
  id                   TEXT PRIMARY KEY,
  username             TEXT UNIQUE NOT NULL,
  password_hash        TEXT NOT NULL,
  full_name            TEXT,
  role                 TEXT DEFAULT 'admin',
  security_question    TEXT,
  security_answer_hash TEXT,
  created_at           TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS products (
  id                  TEXT PRIMARY KEY,
  name                TEXT NOT NULL,
  category            TEXT,
  sale_price          REAL DEFAULT 0,
  stock_price         REAL DEFAULT 0,
  cost_price          REAL DEFAULT 0,
  sale_shop_price     REAL DEFAULT 0,
  low_stock_alert_qty REAL DEFAULT 0,
  current_stock       REAL DEFAULT 0,
  ctn                 REAL DEFAULT 0,
  created_at          TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at          TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS customers (
  id            TEXT PRIMARY KEY,
  name          TEXT NOT NULL,
  phone         TEXT,
  email         TEXT,
  city          TEXT,
  total_orders  INTEGER DEFAULT 0,
  total_spent   REAL DEFAULT 0,
  last_order    TEXT,
  adjustments   TEXT DEFAULT '[]',
  created_at    TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at    TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS sales (
  id               TEXT PRIMARY KEY,
  invoice_number   INTEGER,
  customer_id      TEXT REFERENCES customers(id) ON DELETE SET NULL,
  items            TEXT DEFAULT '[]',
  total            REAL DEFAULT 0,
  advance          REAL DEFAULT 0,
  payment_mode     TEXT,
  payment_status   TEXT,
  payments         TEXT DEFAULT '[]',
  previous_udaar             REAL DEFAULT 0,
  show_previous_udaar_on_invoice INTEGER DEFAULT 0,
  previous_udaar_cleared     INTEGER DEFAULT 0,
  previous_udaar_cleared_at  TEXT,
  extra            TEXT DEFAULT '{}',
  created_at       TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at       TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS manual_invoices (
  id               TEXT PRIMARY KEY,
  invoice_number   INTEGER,
  customer_id      TEXT REFERENCES customers(id) ON DELETE SET NULL,
  items            TEXT DEFAULT '[]',
  total            REAL DEFAULT 0,
  advance          REAL DEFAULT 0,
  payment_mode     TEXT,
  payment_status   TEXT,
  payments         TEXT DEFAULT '[]',
  previous_udaar             REAL DEFAULT 0,
  show_previous_udaar_on_invoice INTEGER DEFAULT 0,
  previous_udaar_cleared     INTEGER DEFAULT 0,
  previous_udaar_cleared_at  TEXT,
  extra            TEXT DEFAULT '{}',
  created_at       TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at       TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS app_settings (
  id                 INTEGER PRIMARY KEY CHECK (id = 1),
  app_settings       TEXT DEFAULT '{"appName":"Shakir POS","tagline":"Pro Dashboard"}',
  invoice_settings   TEXT DEFAULT '{"ownerName":"","businessName":"","phone":"","address":"","logo":""}',
  categories         TEXT DEFAULT '[]',
  expense_categories TEXT DEFAULT '["Rent","Utilities","Salaries","Transport","Maintenance","Other"]',
  invoice_counter    INTEGER DEFAULT 0,
  updated_at         TEXT NOT NULL DEFAULT (datetime('now'))
);

-- ── Suppliers (jin se hum maal khareedte hain) ────────────────────────
CREATE TABLE IF NOT EXISTS suppliers (
  id             TEXT PRIMARY KEY,
  name           TEXT NOT NULL,
  phone          TEXT,
  city           TEXT,
  notes          TEXT,
  created_at     TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at     TEXT NOT NULL DEFAULT (datetime('now'))
);

-- Har supplier ki ledger: 'purchase' entry = un se maal liya (hum par udhaar
-- charhta hai), 'payment' entry = hum ne unhein paise diye (udhaar utarta hai).
CREATE TABLE IF NOT EXISTS supplier_transactions (
  id             TEXT PRIMARY KEY,
  supplier_id    TEXT NOT NULL REFERENCES suppliers(id) ON DELETE CASCADE,
  type           TEXT NOT NULL CHECK (type IN ('purchase','payment')),
  amount         REAL NOT NULL DEFAULT 0,
  description    TEXT,
  purchase_id    TEXT,
  date           TEXT NOT NULL,
  created_at     TEXT NOT NULL DEFAULT (datetime('now'))
);

-- ── Expenses (dukaan ke rozana kharche) ───────────────────────────────
CREATE TABLE IF NOT EXISTS expenses (
  id             TEXT PRIMARY KEY,
  category       TEXT NOT NULL,
  amount         REAL NOT NULL DEFAULT 0,
  description    TEXT,
  date           TEXT NOT NULL,
  created_at     TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at     TEXT NOT NULL DEFAULT (datetime('now'))
);

-- ── Order Returns (customer se wapis aaya hua maal — stock wapis charhta hai) ─
CREATE TABLE IF NOT EXISTS product_returns (
  id             TEXT PRIMARY KEY,
  product_id     TEXT,
  product_name   TEXT NOT NULL,
  qty            REAL NOT NULL DEFAULT 0,
  price          REAL NOT NULL DEFAULT 0,
  reason         TEXT,
  note           TEXT,
  date           TEXT NOT NULL,
  created_at     TEXT NOT NULL DEFAULT (datetime('now'))
);

-- ── Loss Management (damaged/expired/chori waghera — stock kam hota hai) ─
CREATE TABLE IF NOT EXISTS product_losses (
  id             TEXT PRIMARY KEY,
  product_id     TEXT,
  product_name   TEXT NOT NULL,
  qty            REAL NOT NULL DEFAULT 0,
  unit_cost      REAL NOT NULL DEFAULT 0,
  value          REAL NOT NULL DEFAULT 0,
  reason         TEXT,
  note           TEXT,
  date           TEXT NOT NULL,
  created_at     TEXT NOT NULL DEFAULT (datetime('now'))
);

-- ── Supplier Purchases (ek purchase mein multiple products) ──────────────
-- Har purchase ek "batch" hai — is mein ek ya zyada products ho sakte hain,
-- taake ek hi thermal receipt par poora order print ho sake (Urdu mein).
CREATE TABLE IF NOT EXISTS supplier_purchases (
  id             TEXT PRIMARY KEY,
  supplier_id    TEXT NOT NULL,
  invoice_number INTEGER,
  total          REAL NOT NULL DEFAULT 0,
  advance        REAL NOT NULL DEFAULT 0,
  remaining      REAL NOT NULL DEFAULT 0,
  date           TEXT NOT NULL,
  created_at     TEXT NOT NULL DEFAULT (datetime('now')),
  FOREIGN KEY (supplier_id) REFERENCES suppliers(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS supplier_purchase_items (
  id             TEXT PRIMARY KEY,
  purchase_id    TEXT NOT NULL,
  product_id     TEXT,
  product_name   TEXT NOT NULL,
  qty            REAL NOT NULL DEFAULT 0,
  purchase_price REAL NOT NULL DEFAULT 0,
  line_total     REAL NOT NULL DEFAULT 0,
  FOREIGN KEY (purchase_id) REFERENCES supplier_purchases(id) ON DELETE CASCADE
);

-- ── Supplier Purchase Payments ────────────────────────────────────────────
-- Har purchase invoice ki har payment ka alag record (kab, kitni, kis tarah)
-- — taake invoice view/print mein "is invoice ki kab kab payment hui"
-- dikhaya ja sake. kind: 'advance' (khareedte waqt diya), 'balance'
-- (pehle se jama advance balance se laga), 'payment' (baad mein payment).
CREATE TABLE IF NOT EXISTS supplier_purchase_payments (
  id             TEXT PRIMARY KEY,
  purchase_id    TEXT NOT NULL,
  supplier_id    TEXT NOT NULL,
  transaction_id TEXT,
  amount         REAL NOT NULL DEFAULT 0,
  note           TEXT,
  kind           TEXT NOT NULL DEFAULT 'payment',
  date           TEXT NOT NULL,
  created_at     TEXT NOT NULL DEFAULT (datetime('now')),
  FOREIGN KEY (purchase_id) REFERENCES supplier_purchases(id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_supplier_pp_purchase ON supplier_purchase_payments(purchase_id);

CREATE INDEX IF NOT EXISTS idx_supplier_txn_supplier_id ON supplier_transactions(supplier_id);
CREATE INDEX IF NOT EXISTS idx_supplier_txn_date         ON supplier_transactions(date);
CREATE INDEX IF NOT EXISTS idx_expenses_category          ON expenses(category);
CREATE INDEX IF NOT EXISTS idx_expenses_date               ON expenses(date);
CREATE INDEX IF NOT EXISTS idx_returns_date                ON product_returns(date);
CREATE INDEX IF NOT EXISTS idx_losses_date                 ON product_losses(date);
CREATE INDEX IF NOT EXISTS idx_supplier_purchases_supplier  ON supplier_purchases(supplier_id);
CREATE INDEX IF NOT EXISTS idx_supplier_purchase_items_pid  ON supplier_purchase_items(purchase_id);

-- Indexes: keep lookups/reports fast even once there are thousands of
-- products, customers, and invoices in the shop's history.
CREATE INDEX IF NOT EXISTS idx_products_category      ON products(category);
CREATE INDEX IF NOT EXISTS idx_customers_phone         ON customers(phone);
CREATE INDEX IF NOT EXISTS idx_sales_customer_id       ON sales(customer_id);
CREATE INDEX IF NOT EXISTS idx_sales_created_at        ON sales(created_at);
CREATE INDEX IF NOT EXISTS idx_manual_customer_id      ON manual_invoices(customer_id);
CREATE INDEX IF NOT EXISTS idx_manual_created_at       ON manual_invoices(created_at);
`;

// ── Initialize the database (must be awaited once before app is used) ─────
// Loads any existing pos-data.db from disk, or creates a fresh in-memory one
// and writes it out. sql.js is pure WebAssembly, so this needs zero native
// compilation / build tools on any OS (this is exactly what avoids the
// Windows "node-gyp / Visual Studio / EALLOWGIT" install problems).
export async function initDb(userDataPath) {
  const wasmPath = require.resolve("sql.js/dist/sql-wasm.wasm");
  const SQL = await initSqlJs({ wasmBinary: fs.readFileSync(wasmPath) });

  if (!fs.existsSync(userDataPath)) fs.mkdirSync(userDataPath, { recursive: true });
  dbFilePath = path.join(userDataPath, "pos-data.db");

  if (fs.existsSync(dbFilePath)) {
    sqlDb = new SQL.Database(fs.readFileSync(dbFilePath));
  } else {
    sqlDb = new SQL.Database();
  }
  sqlDb.run("PRAGMA foreign_keys = ON;");

  // Pehle se maujood database mein "supplier_purchase_payments" table hai
  // ya nahi — agar nahi thi to neeche purani payments se ek baar backfill
  // hoga taake purani invoices mein bhi payment history nazar aaye.
  const hadPurchasePaymentsTable = !!db
    .prepare("SELECT name FROM sqlite_master WHERE type = 'table' AND name = 'supplier_purchase_payments'")
    .get();

  sqlDb.run(SCHEMA_SQL);

  // Migration: older databases created before "expense_categories" existed
  // won't have that column (CREATE TABLE IF NOT EXISTS doesn't add columns
  // to an already-existing table) — add it if missing, so upgrading never
  // loses existing app_settings data.
  const cols = db.prepare("PRAGMA table_info(app_settings)").all();
  const hasExpenseCategories = cols.some((c) => c.name === "expense_categories");
  if (!hasExpenseCategories) {
    sqlDb.run(
      `ALTER TABLE app_settings ADD COLUMN expense_categories TEXT DEFAULT '["Rent","Utilities","Salaries","Transport","Maintenance","Other"]'`
    );
  }

  // Migration: "expense_category_colors" — custom colors picked by the
  // shop owner for each expense category (used to badge/legend them on
  // the Expenses page instead of a fixed hardcoded palette).
  const hasExpenseCategoryColors = cols.some((c) => c.name === "expense_category_colors");
  if (!hasExpenseCategoryColors) {
    sqlDb.run(`ALTER TABLE app_settings ADD COLUMN expense_category_colors TEXT DEFAULT '{}'`);
  }

  // Migration: "purchase_counter" — separate auto-increment counter for
  // supplier purchase invoice numbers (so they never clash with sale
  // invoice numbers, and never repeat).
  const hasPurchaseCounter = cols.some((c) => c.name === "purchase_counter");
  if (!hasPurchaseCounter) {
    sqlDb.run(`ALTER TABLE app_settings ADD COLUMN purchase_counter INTEGER DEFAULT 0`);
  }

  // Migration: supplier_purchases.invoice_number — older purchase batches
  // (created before this column existed) won't have it.
  const purchaseCols = db.prepare("PRAGMA table_info(supplier_purchases)").all();
  if (purchaseCols.length && !purchaseCols.some((c) => c.name === "invoice_number")) {
    sqlDb.run(`ALTER TABLE supplier_purchases ADD COLUMN invoice_number INTEGER`);
  }

  // Migration: supplier_transactions.purchase_id — links a payment/purchase
  // ledger entry back to the specific purchase invoice it belongs to, so a
  // payment can target one invoice instead of only the overall balance.
  const txnCols = db.prepare("PRAGMA table_info(supplier_transactions)").all();
  if (txnCols.length && !txnCols.some((c) => c.name === "purchase_id")) {
    sqlDb.run(`ALTER TABLE supplier_transactions ADD COLUMN purchase_id TEXT`);
  }

  // Backfill (sirf ek baar): jo payments pehle se kisi specific purchase
  // invoice ke sath linked thi (purchase_id wali ledger entries), unhein
  // naye per-invoice payment history table mein copy karo. "Overall"
  // payments (jo kai invoices mein FIFO baant di gayi thi) ka invoice-wise
  // hisaab purane data mein save hi nahi hua tha, isliye woh yahan nahi aati.
  if (!hadPurchasePaymentsTable) {
    const purchasesForBackfill = db.prepare("SELECT id, supplier_id, advance FROM supplier_purchases").all();
    for (const purchase of purchasesForBackfill) {
      const oldPayments = db
        .prepare("SELECT * FROM supplier_transactions WHERE type = 'payment' AND purchase_id = ? ORDER BY date ASC, created_at ASC")
        .all(purchase.id);
      // Kisi purani payment ne agar invoice ke "ada shuda" se zyada amount
      // record ki thi (jitna baaki tha usse zyada di gayi), to sirf utna hi
      // hissa is invoice ka maana jaye jitna asal mein invoice par laga.
      let left = Number(purchase.advance) || 0;
      for (const t of oldPayments) {
        const amt = Math.min(Number(t.amount) || 0, left);
        if (amt <= 0) continue;
        left -= amt;
        const desc = String(t.description || "");
        const isAdvance = desc.startsWith("Advance —");
        const isDefaultNote = isAdvance || desc === "Payment against invoice" || desc === "Overall payment" || desc === "Advance Payment";
        db.prepare(
          `INSERT INTO supplier_purchase_payments (id, purchase_id, supplier_id, transaction_id, amount, note, kind, date, created_at)
           VALUES (?,?,?,?,?,?,?,?,?)`
        ).run(uuid(), purchase.id, purchase.supplier_id, t.id, amt, isDefaultNote ? "" : desc, isAdvance ? "advance" : "payment", t.date, t.created_at || nowIso());
      }
    }
  }

  // Migration: product_returns.price — unit price captured at the time of
  // the return (so "kitne paise ka maal wapis aaya" can be calculated).
  // Older return records won't have this column.
  const returnCols = db.prepare("PRAGMA table_info(product_returns)").all();
  if (returnCols.length && !returnCols.some((c) => c.name === "price")) {
    sqlDb.run(`ALTER TABLE product_returns ADD COLUMN price REAL NOT NULL DEFAULT 0`);
  }

  // Migration: users.security_question / security_answer_hash — older
  // databases (created before "forgot password" existed) won't have these
  // columns; add them so existing accounts can still be upgraded to use
  // the feature once they set a security question via "update password".
  const userCols = db.prepare("PRAGMA table_info(users)").all();
  if (userCols.length && !userCols.some((c) => c.name === "security_question")) {
    sqlDb.run(`ALTER TABLE users ADD COLUMN security_question TEXT`);
  }
  if (userCols.length && !userCols.some((c) => c.name === "security_answer_hash")) {
    sqlDb.run(`ALTER TABLE users ADD COLUMN security_answer_hash TEXT`);
  }

  save();
}

// Persists the whole in-memory database out to pos-data.db. Called after
// every write request (see electron/main.js) and on app quit as a safety
// net, so data always ends up on disk.
export function save() {
  if (!sqlDb || !dbFilePath) return;
  const data = sqlDb.export();
  fs.writeFileSync(dbFilePath, Buffer.from(data));
}

// ── Debounced save (performance) ────────────────────────────────────────
// Exporting + writing the *entire* database on every single request gets
// slower as the shop's data grows (thousands of products/invoices). Most
// requests are reads (GET) that don't need a save at all, and rapid bursts
// of writes (e.g. finishing a sale, which touches products + customers +
// sales in one go) only need one disk write, not three. scheduleSave()
// batches writes so the UI never waits on disk I/O; flushSave() forces an
// immediate write for moments where we must not lose data (app closing).
let saveTimer = null;
const SAVE_DEBOUNCE_MS = 400;

export function scheduleSave() {
  if (saveTimer) clearTimeout(saveTimer);
  saveTimer = setTimeout(() => {
    saveTimer = null;
    save();
  }, SAVE_DEBOUNCE_MS);
}

export function flushSave() {
  if (saveTimer) {
    clearTimeout(saveTimer);
    saveTimer = null;
  }
  save();
}

function requireDb() {
  if (!sqlDb) throw new Error("Database not initialized yet — initDb() must be awaited first.");
  return sqlDb;
}

// ── better-sqlite3-compatible shim ─────────────────────────────────────
// Route files were written against better-sqlite3's synchronous
// db.prepare(sql).run(...)/.get(...)/.all(...) API. sql.js's own API is
// different (prepare/bind/step/getAsObject), so this shim adapts it,
// meaning none of the route files needed to change.
export const db = {
  prepare(sql) {
    return {
      run(...params) {
        const stmt = requireDb().prepare(sql);
        try {
          if (params.length) stmt.bind(params);
          stmt.step();
        } finally {
          stmt.free();
        }
        return { changes: requireDb().getRowsModified() };
      },
      get(...params) {
        const stmt = requireDb().prepare(sql);
        try {
          if (params.length) stmt.bind(params);
          if (stmt.step()) return stmt.getAsObject();
          return undefined;
        } finally {
          stmt.free();
        }
      },
      all(...params) {
        const stmt = requireDb().prepare(sql);
        const rows = [];
        try {
          if (params.length) stmt.bind(params);
          while (stmt.step()) rows.push(stmt.getAsObject());
        } finally {
          stmt.free();
        }
        return rows;
      },
    };
  },

  // Mirrors better-sqlite3's db.transaction(fn) helper: returns a function
  // that, when called, runs fn(...args) wrapped in BEGIN/COMMIT, rolling
  // back on any thrown error.
  transaction(fn) {
    return (...args) => {
      requireDb().run("BEGIN;");
      try {
        const result = fn(...args);
        requireDb().run("COMMIT;");
        return result;
      } catch (err) {
        try {
          requireDb().run("ROLLBACK;");
        } catch {
          /* ignore rollback failure */
        }
        throw err;
      }
    };
  },
};

export default db;
