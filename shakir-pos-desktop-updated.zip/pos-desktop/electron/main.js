import { app, BrowserWindow, ipcMain } from "electron";
import path from "path";
import { fileURLToPath } from "url";

import { initDb, save, scheduleSave, flushSave } from "./db.js";
import handleApiRequest from "./apiRouter.js";
import * as auth from "./routes/auth.js";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
// Only treat this as "dev" (load the Vite dev server) when explicitly asked
// via NODE_ENV=development (see the "dev" npm script). Running the built
// app — packaged or via `npx electron .` after `npm run build` — always
// loads the compiled dist/index.html.
const isDev = !app.isPackaged && process.env.NODE_ENV === "development";

function createWindow() {
  const win = new BrowserWindow({
    width: 1400,
    height: 900,
    minWidth: 1024,
    minHeight: 640,
    autoHideMenuBar: true,
    icon: path.join(__dirname, "..", "build", "icon.png"),
    webPreferences: {
      preload: path.join(__dirname, "preload.cjs"),
      contextIsolation: true,
      nodeIntegration: false,
    },
  });

  if (isDev) {
    win.loadURL("http://localhost:5173");
    win.webContents.openDevTools({ mode: "detach" });
  } else {
    win.loadFile(path.join(__dirname, "..", "dist", "index.html"));
  }

  // If the preload script ever fails to load (wrong path, syntax error,
  // etc.), window.electronAPI would be missing in the renderer and every
  // login/data call would throw "Cannot read properties of undefined".
  // Logging it here makes that failure visible instead of silent.
  win.webContents.on("preload-error", (_event, preloadPath, error) => {
    console.error("Preload script failed to load:", preloadPath, error);
  });
}

app.whenReady().then(async () => {
  // sql.js is pure WebAssembly (no native compilation needed on any OS),
  // which is why it replaced better-sqlite3 — but it must finish loading
  // and reading pos-data.db from disk before anything else touches it.
  await initDb(app.getPath("userData"));
  auth.ensureDefaultUser();
  save();

  // ── Generic data API (mirrors the old REST routes 1:1) ─────────────────
  ipcMain.handle("api-request", (_event, { method, path: reqPath, body }) => {
    try {
      const result = handleApiRequest({ method, path: reqPath, body });
      // Only writes (POST/PUT/DELETE) need to touch disk — GET requests
      // (which are most of them: loading products, reports, dashboards)
      // never change data, so skipping the save there is a big speed win
      // once the shop has a lot of products/invoices. Writes are also
      // debounced/batched (see db.js) instead of blocking on disk I/O.
      if (method !== "GET") scheduleSave();
      return { ok: true, data: result === undefined ? null : result };
    } catch (err) {
      return { ok: false, status: err.status || 500, error: err.message || "Internal error" };
    }
  });

  // ── Local auth ───────────────────────────────────────────────────────
  ipcMain.handle("auth-login", (_e, creds) => {
    try {
      return { ok: true, data: auth.login(creds) };
    } catch (err) {
      return { ok: false, code: err.code, error: err.message };
    }
  });
  ipcMain.handle("auth-register", (_e, creds) => {
    try {
      const data = auth.register(creds);
      scheduleSave();
      return { ok: true, data };
    } catch (err) {
      return { ok: false, code: err.code, error: err.message };
    }
  });
  ipcMain.handle("auth-update-password", (_e, payload) => {
    try {
      const data = auth.updatePassword(payload);
      scheduleSave();
      return { ok: true, data };
    } catch (err) {
      return { ok: false, code: err.code, error: err.message };
    }
  });
  ipcMain.handle("auth-get-security-question", (_e, payload) => {
    try {
      return { ok: true, data: auth.getSecurityQuestion(payload) };
    } catch (err) {
      return { ok: false, code: err.code, error: err.message };
    }
  });
  ipcMain.handle("auth-reset-password", (_e, payload) => {
    try {
      const data = auth.resetPassword(payload);
      scheduleSave();
      return { ok: true, data };
    } catch (err) {
      return { ok: false, code: err.code, error: err.message };
    }
  });

  createWindow();

  app.on("activate", () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on("window-all-closed", () => {
  flushSave();
  if (process.platform !== "darwin") app.quit();
});

app.on("before-quit", () => {
  flushSave();
});

