import db, { uuid, nowIso } from "../db.js";
import { mapProduct } from "../utils/mappers.js";

export function list() {
  const rows = db.prepare("SELECT * FROM products ORDER BY created_at ASC").all();
  return rows.map(mapProduct);
}

export function create(f) {
  const id = uuid();
  const ts = nowIso();
  db.prepare(
    `INSERT INTO products
      (id, name, category, sale_price, stock_price, cost_price, sale_shop_price, low_stock_alert_qty, current_stock, ctn, created_at, updated_at)
     VALUES (?,?,?,?,?,?,?,?,?,?,?,?)`
  ).run(
    id,
    String(f.name || "").trim(),
    f.category || null,
    Number(f.salePrice) || 0,
    Number(f.stockPrice ?? f.costPrice) || 0,
    Number(f.costPrice) || 0,
    Number(f.saleShopPrice) || 0,
    Number(f.lowStockAlertQty) || 0,
    Number(f.currentStock) || 0,
    Number(f.ctn) || 0,
    ts,
    ts
  );
  return mapProduct(db.prepare("SELECT * FROM products WHERE id = ?").get(id));
}

export function update(id, f) {
  const info = db
    .prepare(
      `UPDATE products SET
        name=?, category=?, sale_price=?, stock_price=?, cost_price=?,
        sale_shop_price=?, low_stock_alert_qty=?, current_stock=?, ctn=?, updated_at=?
       WHERE id=?`
    )
    .run(
      String(f.name || "").trim(),
      f.category || null,
      Number(f.salePrice) || 0,
      Number(f.stockPrice ?? f.costPrice) || 0,
      Number(f.costPrice) || 0,
      Number(f.saleShopPrice) || 0,
      Number(f.lowStockAlertQty) || 0,
      Number(f.currentStock) || 0,
      Number(f.ctn) || 0,
      nowIso(),
      id
    );
  if (info.changes === 0) {
    const err = new Error("Product not found");
    err.status = 404;
    throw err;
  }
  return mapProduct(db.prepare("SELECT * FROM products WHERE id = ?").get(id));
}

export function remove(id) {
  db.prepare("DELETE FROM products WHERE id = ?").run(id);
}

export function stockIn(id, qty) {
  const amount = Number(qty);
  if (!amount || amount <= 0) {
    const err = new Error("Invalid quantity");
    err.status = 400;
    throw err;
  }
  const info = db
    .prepare("UPDATE products SET current_stock = current_stock + ?, updated_at = ? WHERE id = ?")
    .run(amount, nowIso(), id);
  if (info.changes === 0) {
    const err = new Error("Product not found");
    err.status = 404;
    throw err;
  }
  return mapProduct(db.prepare("SELECT * FROM products WHERE id = ?").get(id));
}

export function stockOut(id, qty) {
  const amount = Number(qty);
  if (!amount || amount <= 0) {
    const err = new Error("Invalid quantity");
    err.status = 400;
    throw err;
  }
  const info = db
    .prepare(
      "UPDATE products SET current_stock = current_stock - ?, updated_at = ? WHERE id = ? AND current_stock >= ?"
    )
    .run(amount, nowIso(), id, amount);
  if (info.changes === 0) {
    const err = new Error("Insufficient stock or product not found");
    err.status = 400;
    throw err;
  }
  return mapProduct(db.prepare("SELECT * FROM products WHERE id = ?").get(id));
}

export default { list, create, update, remove, stockIn, stockOut };
