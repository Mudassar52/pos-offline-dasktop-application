import db, { uuid, nowIso } from "../db.js";
import { mapCustomer } from "../utils/mappers.js";

export function list() {
  const rows = db.prepare("SELECT * FROM customers ORDER BY created_at ASC").all();
  return rows.map(mapCustomer);
}

export function create(f) {
  const id = uuid();
  const ts = nowIso();
  db.prepare(
    `INSERT INTO customers (id, name, phone, email, city, total_orders, total_spent, last_order, adjustments, created_at, updated_at)
     VALUES (?,?,?,?,?,0,0,?,'[]',?,?)`
  ).run(id, String(f.name || "").trim(), String(f.phone || "").trim(), f.email || "", f.city || "", ts, ts, ts);
  return mapCustomer(db.prepare("SELECT * FROM customers WHERE id = ?").get(id));
}

export function update(id, f) {
  const info = db
    .prepare(`UPDATE customers SET name=?, phone=?, email=?, city=?, updated_at=? WHERE id=?`)
    .run(String(f.name || "").trim(), String(f.phone || "").trim(), f.email || "", f.city || "", nowIso(), id);
  if (info.changes === 0) {
    const err = new Error("Customer not found");
    err.status = 404;
    throw err;
  }
  return mapCustomer(db.prepare("SELECT * FROM customers WHERE id = ?").get(id));
}

export function remove(id) {
  db.prepare("DELETE FROM customers WHERE id = ?").run(id);
}

export function addAdjustment(id, { type, amount, reason, date }) {
  const row = db.prepare("SELECT * FROM customers WHERE id = ?").get(id);
  if (!row) {
    const err = new Error("Customer not found");
    err.status = 404;
    throw err;
  }
  const current = JSON.parse(row.adjustments || "[]");
  current.push({ type, amount, reason, date });
  db.prepare("UPDATE customers SET adjustments = ?, updated_at = ? WHERE id = ?").run(
    JSON.stringify(current),
    nowIso(),
    id
  );
  return mapCustomer(db.prepare("SELECT * FROM customers WHERE id = ?").get(id));
}

// Internal helper used by sale/invoice creation & deletion to keep customer totals in sync.
export function bumpCustomerStats(customerId, deltaOrders, deltaSpent, lastOrder) {
  if (!customerId) return;
  const row = db.prepare("SELECT * FROM customers WHERE id = ?").get(customerId);
  if (!row) return;
  const newOrders = Math.max(0, (row.total_orders || 0) + deltaOrders);
  const newSpent = Math.max(0, (row.total_spent || 0) + deltaSpent);
  const newLastOrder = lastOrder || row.last_order;
  db.prepare("UPDATE customers SET total_orders=?, total_spent=?, last_order=?, updated_at=? WHERE id=?").run(
    newOrders,
    newSpent,
    newLastOrder,
    nowIso(),
    customerId
  );
}

export default { list, create, update, remove, addAdjustment, bumpCustomerStats };
