import db, { uuid, nowIso } from "../db.js";
import { mapExpense } from "../utils/mappers.js";

export function list() {
  const rows = db.prepare("SELECT * FROM expenses ORDER BY date DESC, created_at DESC").all();
  return rows.map(mapExpense);
}

export function create(f) {
  const amt = Number(f.amount);
  if (!amt || amt <= 0) {
    const err = new Error("Amount must be greater than zero");
    err.status = 400;
    throw err;
  }
  if (!String(f.category || "").trim()) {
    const err = new Error("Category is required");
    err.status = 400;
    throw err;
  }
  const id = uuid();
  const ts = nowIso();
  db.prepare(
    `INSERT INTO expenses (id, category, amount, description, date, created_at, updated_at)
     VALUES (?,?,?,?,?,?,?)`
  ).run(id, String(f.category).trim(), amt, f.description || "", f.date || ts, ts, ts);
  return mapExpense(db.prepare("SELECT * FROM expenses WHERE id = ?").get(id));
}

export function update(id, f) {
  const info = db
    .prepare(`UPDATE expenses SET category=?, amount=?, description=?, date=?, updated_at=? WHERE id=?`)
    .run(String(f.category || "").trim(), Number(f.amount) || 0, f.description || "", f.date || nowIso(), nowIso(), id);
  if (info.changes === 0) {
    const err = new Error("Expense not found");
    err.status = 404;
    throw err;
  }
  return mapExpense(db.prepare("SELECT * FROM expenses WHERE id = ?").get(id));
}

export function remove(id) {
  db.prepare("DELETE FROM expenses WHERE id = ?").run(id);
}

export default { list, create, update, remove };
