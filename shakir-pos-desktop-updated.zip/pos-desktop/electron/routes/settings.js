import db, { nowIso } from "../db.js";
import { mapSettings } from "../utils/mappers.js";
import { PRODUCT_CATEGORIES } from "../defaultCategories.js";

// Ensures the single settings row exists (id = 1, single-shop local app)
export function ensureSettingsRow() {
  let row = db.prepare("SELECT * FROM app_settings WHERE id = 1").get();
  if (row) return row;
  db.prepare(
    "INSERT INTO app_settings (id, categories, updated_at) VALUES (1, ?, ?)"
  ).run(JSON.stringify(PRODUCT_CATEGORIES), nowIso());
  return db.prepare("SELECT * FROM app_settings WHERE id = 1").get();
}

export function getSettings() {
  return mapSettings(ensureSettingsRow());
}

export function updateAppSettings(body) {
  const row = ensureSettingsRow();
  const current = JSON.parse(row.app_settings || "{}");
  const next = { ...current, ...body };
  db.prepare("UPDATE app_settings SET app_settings = ?, updated_at = ? WHERE id = 1").run(
    JSON.stringify(next),
    nowIso()
  );
  return mapSettings(db.prepare("SELECT * FROM app_settings WHERE id = 1").get());
}

export function updateInvoiceSettings(body) {
  const row = ensureSettingsRow();
  const current = JSON.parse(row.invoice_settings || "{}");
  const next = { ...current, ...body };
  db.prepare("UPDATE app_settings SET invoice_settings = ?, updated_at = ? WHERE id = 1").run(
    JSON.stringify(next),
    nowIso()
  );
  return mapSettings(db.prepare("SELECT * FROM app_settings WHERE id = 1").get());
}

export function addCategory(name) {
  const row = ensureSettingsRow();
  const clean = String(name || "").trim();
  const current = JSON.parse(row.categories || "[]");
  if (!clean || current.includes(clean)) return mapSettings(row);
  const next = [...current, clean];
  db.prepare("UPDATE app_settings SET categories = ?, updated_at = ? WHERE id = 1").run(
    JSON.stringify(next),
    nowIso()
  );
  return mapSettings(db.prepare("SELECT * FROM app_settings WHERE id = 1").get());
}

export function removeCategory(name) {
  const row = ensureSettingsRow();
  const current = JSON.parse(row.categories || "[]");
  const next = current.filter((c) => c !== name);
  db.prepare("UPDATE app_settings SET categories = ?, updated_at = ? WHERE id = 1").run(
    JSON.stringify(next),
    nowIso()
  );
  return mapSettings(db.prepare("SELECT * FROM app_settings WHERE id = 1").get());
}

// ── Expense categories (separate list from product categories) ─────────
export function addExpenseCategory(name) {
  const row = ensureSettingsRow();
  const clean = String(name || "").trim();
  const current = JSON.parse(row.expense_categories || "[]");
  if (!clean || current.includes(clean)) return mapSettings(row);
  const next = [...current, clean];
  db.prepare("UPDATE app_settings SET expense_categories = ?, updated_at = ? WHERE id = 1").run(
    JSON.stringify(next),
    nowIso()
  );
  return mapSettings(db.prepare("SELECT * FROM app_settings WHERE id = 1").get());
}

export function removeExpenseCategory(name) {
  const row = ensureSettingsRow();
  const current = JSON.parse(row.expense_categories || "[]");
  const next = current.filter((c) => c !== name);
  db.prepare("UPDATE app_settings SET expense_categories = ?, updated_at = ? WHERE id = 1").run(
    JSON.stringify(next),
    nowIso()
  );
  return mapSettings(db.prepare("SELECT * FROM app_settings WHERE id = 1").get());
}

// ── Custom color per expense category (for the color-picker on the
// Expenses → Manage Categories page) ─────────────────────────────────────
export function setExpenseCategoryColor(name, color) {
  const row = ensureSettingsRow();
  const clean = String(name || "").trim();
  if (!clean) return mapSettings(row);
  const current = JSON.parse(row.expense_category_colors || "{}");
  const next = { ...current, [clean]: color };
  db.prepare("UPDATE app_settings SET expense_category_colors = ?, updated_at = ? WHERE id = 1").run(
    JSON.stringify(next),
    nowIso()
  );
  return mapSettings(db.prepare("SELECT * FROM app_settings WHERE id = 1").get());
}

// Helper used by pos.js / invoices.js to reserve the next invoice number.
// Loop guards against any drift (e.g. an old backup restore, or manual DB
// edits) so the same invoice number can never be reused for a new invoice.
export function getNextInvoiceNumber() {
  ensureSettingsRow();
  let next;
  let guard = 0;
  do {
    db.prepare("UPDATE app_settings SET invoice_counter = invoice_counter + 1, updated_at = ? WHERE id = 1").run(nowIso());
    next = db.prepare("SELECT invoice_counter FROM app_settings WHERE id = 1").get().invoice_counter;
    guard += 1;
  } while (
    guard < 100000 &&
    (db.prepare("SELECT 1 FROM sales WHERE invoice_number = ?").get(next) ||
      db.prepare("SELECT 1 FROM manual_invoices WHERE invoice_number = ?").get(next))
  );
  return next;
}

// Supplier purchase invoices get their own separate counter/sequence —
// kept apart from sale invoice numbers so the two never clash.
export function getNextPurchaseInvoiceNumber() {
  ensureSettingsRow();
  let next;
  let guard = 0;
  do {
    db.prepare("UPDATE app_settings SET purchase_counter = purchase_counter + 1, updated_at = ? WHERE id = 1").run(nowIso());
    next = db.prepare("SELECT purchase_counter FROM app_settings WHERE id = 1").get().purchase_counter;
    guard += 1;
  } while (guard < 100000 && db.prepare("SELECT 1 FROM supplier_purchases WHERE invoice_number = ?").get(next));
  return next;
}

export default {
  getSettings,
  updateAppSettings,
  updateInvoiceSettings,
  addCategory,
  removeCategory,
  addExpenseCategory,
  removeExpenseCategory,
  setExpenseCategoryColor,
  ensureSettingsRow,
  getNextInvoiceNumber,
};
