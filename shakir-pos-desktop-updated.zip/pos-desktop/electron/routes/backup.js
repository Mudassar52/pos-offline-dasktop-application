import db, { uuid, nowIso } from "../db.js";
import { ensureSettingsRow } from "./settings.js";

// Invoice ke woh fields jo apne alag columns mein save hote hain. Baqi sab
// kuch (customerName, customerPhone, customerAddress, notes, discount, tax,
// grossProfit, isOldUdaar, note ... ) invoice ke "extra" JSON column mein
// rehta hai — restore ke waqt yeh dobara "extra" mein likhna zaroori hai,
// warna invoice se customer ka naam/address, discount aur profit ghayab ho
// jate hain.
const INVOICE_COLUMN_KEYS = new Set([
  "id", "source", "invoiceNumber", "customerId", "items", "total", "advance",
  "paymentMode", "paymentStatus", "payments", "previousUdaar",
  "showPreviousUdaarOnInvoice", "previousUdaarCleared", "previousUdaarClearedAt",
  "createdAt", "updatedAt",
]);

// POST /api/backup/restore
// body: { products, customers, allInvoices, settings, suppliers, supplierTransactions, supplierPurchases, expenses }
export const restore = db.transaction(({ products = [], customers = [], allInvoices = [], settings = {}, suppliers = [], supplierTransactions = [], supplierPurchases = [], expenses = [], returns = [], losses = [] }) => {
  // Purchase items/payments delete honi chahiye purchases se pehle (foreign
  // key ON DELETE CASCADE waise bhi in ko hata deta, lekin explicit rakhna
  // safe hai chahe pragma kisi wajah se load na hua ho).
  db.prepare("DELETE FROM supplier_purchase_payments").run();
  db.prepare("DELETE FROM supplier_purchase_items").run();
  db.prepare("DELETE FROM supplier_purchases").run();
  db.prepare("DELETE FROM products").run();
  db.prepare("DELETE FROM customers").run();
  db.prepare("DELETE FROM sales").run();
  db.prepare("DELETE FROM manual_invoices").run();
  db.prepare("DELETE FROM supplier_transactions").run();
  db.prepare("DELETE FROM suppliers").run();
  db.prepare("DELETE FROM expenses").run();
  db.prepare("DELETE FROM product_returns").run();
  db.prepare("DELETE FROM product_losses").run();

  const customerIdMap = new Map();
  const customerNameByOldId = new Map(customers.filter((c) => c.id !== undefined).map((c) => [String(c.id), c.name || ""]));

  for (const c of customers) {
    const id = uuid();
    db.prepare(
      `INSERT INTO customers (id, name, phone, email, city, total_orders, total_spent, last_order, adjustments, created_at, updated_at)
       VALUES (?,?,?,?,?,?,?,?,?,?,?)`
    ).run(
      id,
      c.name || "",
      c.phone || "",
      c.email || "",
      c.city || "",
      c.totalOrders || 0,
      c.totalSpent || 0,
      c.lastOrder || null,
      JSON.stringify(c.adjustments || []),
      nowIso(),
      nowIso()
    );
    if (c.id !== undefined) customerIdMap.set(String(c.id), id);
  }

  for (const p of products) {
    db.prepare(
      `INSERT INTO products (id, name, category, sale_price, stock_price, cost_price, sale_shop_price, low_stock_alert_qty, current_stock, ctn, created_at, updated_at)
       VALUES (?,?,?,?,?,?,?,?,?,?,?,?)`
    ).run(
      uuid(),
      p.name || "",
      p.category || null,
      p.salePrice || 0,
      p.stockPrice || 0,
      p.costPrice || 0,
      p.saleShopPrice || 0,
      p.lowStockAlertQty || 0,
      p.currentStock || 0,
      p.ctn || 0,
      nowIso(),
      nowIso()
    );
  }

  for (const inv of allInvoices) {
    const table = inv.source === "manual" ? "manual_invoices" : "sales";
    const mappedCustomerId = inv.customerId ? customerIdMap.get(String(inv.customerId)) || null : null;
    const createdAt = inv.createdAt || nowIso();
    const extra = {};
    for (const key of Object.keys(inv)) {
      if (!INVOICE_COLUMN_KEYS.has(key)) extra[key] = inv[key];
    }
    // Purane (pehle se kharab restore hue) backups mein customerName save
    // nahi hota — us surat mein customer ke record se naam wapis bhar do.
    if (!extra.customerName && inv.customerId) {
      const fallbackName = customerNameByOldId.get(String(inv.customerId));
      if (fallbackName) extra.customerName = fallbackName;
    }
    db.prepare(
      `INSERT INTO ${table}
        (id, invoice_number, customer_id, items, total, advance, payment_mode, payment_status, payments,
         previous_udaar, show_previous_udaar_on_invoice, previous_udaar_cleared, previous_udaar_cleared_at, extra, created_at, updated_at)
       VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`
    ).run(
      uuid(),
      inv.invoiceNumber || null,
      mappedCustomerId,
      JSON.stringify(inv.items || []),
      inv.total || 0,
      inv.advance || 0,
      inv.paymentMode || null,
      inv.paymentStatus || null,
      JSON.stringify(inv.payments || []),
      inv.previousUdaar || 0,
      inv.showPreviousUdaarOnInvoice ? 1 : 0,
      inv.previousUdaarCleared ? 1 : 0,
      inv.previousUdaarClearedAt || null,
      JSON.stringify(extra),
      createdAt,
      createdAt
    );
  }

  ensureSettingsRow();
  // Invoice counter ko restored invoices ke sabse bade number tak sync
  // karo — warna restore ke baad naye invoices purane numbers dobara use
  // kar sakte hain (duplicate invoice number).
  const maxExisting = Math.max(
    0,
    ...allInvoices.map((inv) => Number(inv.invoiceNumber) || 0)
  );
  if (settings && Object.keys(settings).length) {
    const row = db.prepare("SELECT * FROM app_settings WHERE id = 1").get();
    db.prepare(
      `UPDATE app_settings SET app_settings=?, invoice_settings=?, categories=?, expense_categories=?, expense_category_colors=?, updated_at=? WHERE id=1`
    ).run(
      settings.appSettings ? JSON.stringify(settings.appSettings) : row.app_settings,
      settings.invoiceSettings ? JSON.stringify({ ...settings.invoiceSettings, logo: "" }) : row.invoice_settings,
      settings.categories ? JSON.stringify(settings.categories) : row.categories,
      settings.expenseCategories ? JSON.stringify(settings.expenseCategories) : row.expense_categories,
      settings.expenseCategoryColors ? JSON.stringify(settings.expenseCategoryColors) : row.expense_category_colors,
      nowIso()
    );
  }
  db.prepare("UPDATE app_settings SET invoice_counter = MAX(invoice_counter, ?), updated_at = ? WHERE id = 1").run(
    Math.max(maxExisting, Number(settings?.invoiceCounter) || 0),
    nowIso()
  );

  // Suppliers + their purchase invoices (items + payment history) + ledger
  const supplierIdMap = new Map();
  for (const s of suppliers) {
    const id = uuid();
    db.prepare(
      `INSERT INTO suppliers (id, name, phone, city, notes, created_at, updated_at) VALUES (?,?,?,?,?,?,?)`
    ).run(id, s.name || "", s.phone || "", s.city || "", s.notes || "", nowIso(), nowIso());
    if (s.id !== undefined) supplierIdMap.set(String(s.id), id);
  }

  // Purchase invoices ko naye supplier ids ke sath dobara banao, aur har
  // purani purchase.id -> nayi id ka naqsha rakho taake neeche transactions
  // (aur khud purchase ke andar payments/transactionId) sahi se link ho
  // sakein. Bina is table ke restore se pehle, purani har khareedari aur
  // uski payment history (kab, kitni ada hui) restore ke baad ghayab ho
  // jati thi.
  const purchaseIdMap = new Map();
  for (const p of supplierPurchases) {
    const mappedSupplierId = p.supplierId ? supplierIdMap.get(String(p.supplierId)) : null;
    if (!mappedSupplierId) continue;
    const newId = uuid();
    const pDate = p.date || nowIso();
    db.prepare(
      `INSERT INTO supplier_purchases (id, supplier_id, invoice_number, total, advance, remaining, date, created_at)
       VALUES (?,?,?,?,?,?,?,?)`
    ).run(newId, mappedSupplierId, p.invoiceNumber || null, p.total || 0, p.advance || 0, p.remaining || 0, pDate, nowIso());
    if (p.id !== undefined) purchaseIdMap.set(String(p.id), newId);

    for (const it of p.items || []) {
      db.prepare(
        `INSERT INTO supplier_purchase_items (id, purchase_id, product_id, product_name, qty, purchase_price, line_total)
         VALUES (?,?,?,?,?,?,?)`
      ).run(uuid(), newId, null, it.productName || "", it.qty || 0, it.purchasePrice || 0, it.lineTotal || 0);
    }
    for (const pay of p.payments || []) {
      db.prepare(
        `INSERT INTO supplier_purchase_payments (id, purchase_id, supplier_id, transaction_id, amount, note, kind, date, created_at)
         VALUES (?,?,?,?,?,?,?,?,?)`
      ).run(uuid(), newId, mappedSupplierId, null, pay.amount || 0, pay.note || "", pay.kind || "payment", pay.date || pDate, nowIso());
    }
  }

  for (const t of supplierTransactions) {
    const mappedSupplierId = t.supplierId ? supplierIdMap.get(String(t.supplierId)) : null;
    if (!mappedSupplierId) continue;
    const mappedPurchaseId = t.purchaseId ? purchaseIdMap.get(String(t.purchaseId)) || null : null;
    db.prepare(
      `INSERT INTO supplier_transactions (id, supplier_id, type, amount, description, purchase_id, date, created_at) VALUES (?,?,?,?,?,?,?,?)`
    ).run(uuid(), mappedSupplierId, t.type, t.amount || 0, t.description || "", mappedPurchaseId, t.date || nowIso(), nowIso());
  }

  // Expenses
  for (const e of expenses) {
    db.prepare(
      `INSERT INTO expenses (id, category, amount, description, date, created_at, updated_at) VALUES (?,?,?,?,?,?,?)`
    ).run(uuid(), e.category || "Other", e.amount || 0, e.description || "", e.date || nowIso(), nowIso(), nowIso());
  }

  // Order Returns
  for (const r of returns) {
    db.prepare(
      `INSERT INTO product_returns (id, product_id, product_name, qty, price, reason, note, date, created_at) VALUES (?,?,?,?,?,?,?,?,?)`
    ).run(uuid(), null, r.productName || "", r.qty || 0, r.price || 0, r.reason || "", r.note || "", r.date || nowIso(), nowIso());
  }

  // Loss Management
  for (const l of losses) {
    db.prepare(
      `INSERT INTO product_losses (id, product_id, product_name, qty, unit_cost, value, reason, note, date, created_at) VALUES (?,?,?,?,?,?,?,?,?,?)`
    ).run(uuid(), null, l.productName || "", l.qty || 0, l.unitCost || 0, l.value || 0, l.reason || "", l.note || "", l.date || nowIso(), nowIso());
  }

  return { success: true };
});

export default { restore };
