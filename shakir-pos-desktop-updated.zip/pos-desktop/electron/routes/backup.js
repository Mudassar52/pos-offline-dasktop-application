import db, { uuid, nowIso } from "../db.js";
import { ensureSettingsRow } from "./settings.js";

// POST /api/backup/restore
// body: { products, customers, allInvoices, settings, suppliers, supplierTransactions, expenses }
export const restore = db.transaction(({ products = [], customers = [], allInvoices = [], settings = {}, suppliers = [], supplierTransactions = [], expenses = [], returns = [], losses = [] }) => {
  db.prepare("DELETE FROM products").run();
  db.prepare("DELETE FROM customers").run();
  db.prepare("DELETE FROM sales").run();
  db.prepare("DELETE FROM manual_invoices").run();
  db.prepare("DELETE FROM supplier_transactions").run();
  db.prepare("DELETE FROM suppliers").run();
  db.prepare("DELETE FROM expenses").run();
  db.prepare("DELETE FROM product_returns").run();
  db.prepare("DELETE FROM product_losses").run();

  const customerIdMap = new Map();

  for (const c of customers) {
    const id = uuid();
    db.prepare(
      `INSERT INTO customers (id, name, phone, email, city, total_orders, total_spent, last_order, adjustments, created_at, updated_at)
       VALUES (?,?,?,?,?,?,?,?,?,?,?)`
    ).run(
      id,
      c.name || "",
      c.phone || "",
      c.email || "",
      c.city || "",
      c.totalOrders || 0,
      c.totalSpent || 0,
      c.lastOrder || null,
      JSON.stringify(c.adjustments || []),
      nowIso(),
      nowIso()
    );
    if (c.id !== undefined) customerIdMap.set(String(c.id), id);
  }

  for (const p of products) {
    db.prepare(
      `INSERT INTO products (id, name, category, sale_price, stock_price, cost_price, sale_shop_price, low_stock_alert_qty, current_stock, ctn, created_at, updated_at)
       VALUES (?,?,?,?,?,?,?,?,?,?,?,?)`
    ).run(
      uuid(),
      p.name || "",
      p.category || null,
      p.salePrice || 0,
      p.stockPrice || 0,
      p.costPrice || 0,
      p.saleShopPrice || 0,
      p.lowStockAlertQty || 0,
      p.currentStock || 0,
      p.ctn || 0,
      nowIso(),
      nowIso()
    );
  }

  for (const inv of allInvoices) {
    const table = inv.source === "manual" ? "manual_invoices" : "sales";
    const mappedCustomerId = inv.customerId ? customerIdMap.get(String(inv.customerId)) || null : null;
    const createdAt = inv.createdAt || nowIso();
    db.prepare(
      `INSERT INTO ${table}
        (id, invoice_number, customer_id, items, total, advance, payment_mode, payment_status, payments,
         previous_udaar, show_previous_udaar_on_invoice, previous_udaar_cleared, previous_udaar_cleared_at, created_at, updated_at)
       VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`
    ).run(
      uuid(),
      inv.invoiceNumber || null,
      mappedCustomerId,
      JSON.stringify(inv.items || []),
      inv.total || 0,
      inv.advance || 0,
      inv.paymentMode || null,
      inv.paymentStatus || null,
      JSON.stringify(inv.payments || []),
      inv.previousUdaar || 0,
      inv.showPreviousUdaarOnInvoice ? 1 : 0,
      inv.previousUdaarCleared ? 1 : 0,
      inv.previousUdaarClearedAt || null,
      createdAt,
      createdAt
    );
  }

  ensureSettingsRow();
  // Invoice counter ko restored invoices ke sabse bade number tak sync
  // karo — warna restore ke baad naye invoices purane numbers dobara use
  // kar sakte hain (duplicate invoice number).
  const maxExisting = Math.max(
    0,
    ...allInvoices.map((inv) => Number(inv.invoiceNumber) || 0)
  );
  if (settings && Object.keys(settings).length) {
    const row = db.prepare("SELECT * FROM app_settings WHERE id = 1").get();
    db.prepare(
      `UPDATE app_settings SET app_settings=?, invoice_settings=?, categories=?, expense_categories=?, expense_category_colors=?, updated_at=? WHERE id=1`
    ).run(
      settings.appSettings ? JSON.stringify(settings.appSettings) : row.app_settings,
      settings.invoiceSettings ? JSON.stringify({ ...settings.invoiceSettings, logo: "" }) : row.invoice_settings,
      settings.categories ? JSON.stringify(settings.categories) : row.categories,
      settings.expenseCategories ? JSON.stringify(settings.expenseCategories) : row.expense_categories,
      settings.expenseCategoryColors ? JSON.stringify(settings.expenseCategoryColors) : row.expense_category_colors,
      nowIso()
    );
  }
  db.prepare("UPDATE app_settings SET invoice_counter = MAX(invoice_counter, ?), updated_at = ? WHERE id = 1").run(
    Math.max(maxExisting, Number(settings?.invoiceCounter) || 0),
    nowIso()
  );

  // Suppliers + their purchase/payment ledger
  const supplierIdMap = new Map();
  for (const s of suppliers) {
    const id = uuid();
    db.prepare(
      `INSERT INTO suppliers (id, name, phone, city, notes, created_at, updated_at) VALUES (?,?,?,?,?,?,?)`
    ).run(id, s.name || "", s.phone || "", s.city || "", s.notes || "", nowIso(), nowIso());
    if (s.id !== undefined) supplierIdMap.set(String(s.id), id);
  }
  for (const t of supplierTransactions) {
    const mappedSupplierId = t.supplierId ? supplierIdMap.get(String(t.supplierId)) : null;
    if (!mappedSupplierId) continue;
    db.prepare(
      `INSERT INTO supplier_transactions (id, supplier_id, type, amount, description, date, created_at) VALUES (?,?,?,?,?,?,?)`
    ).run(uuid(), mappedSupplierId, t.type, t.amount || 0, t.description || "", t.date || nowIso(), nowIso());
  }

  // Expenses
  for (const e of expenses) {
    db.prepare(
      `INSERT INTO expenses (id, category, amount, description, date, created_at, updated_at) VALUES (?,?,?,?,?,?,?)`
    ).run(uuid(), e.category || "Other", e.amount || 0, e.description || "", e.date || nowIso(), nowIso(), nowIso());
  }

  // Order Returns
  for (const r of returns) {
    db.prepare(
      `INSERT INTO product_returns (id, product_id, product_name, qty, reason, note, date, created_at) VALUES (?,?,?,?,?,?,?,?)`
    ).run(uuid(), null, r.productName || "", r.qty || 0, r.reason || "", r.note || "", r.date || nowIso(), nowIso());
  }

  // Loss Management
  for (const l of losses) {
    db.prepare(
      `INSERT INTO product_losses (id, product_id, product_name, qty, unit_cost, value, reason, note, date, created_at) VALUES (?,?,?,?,?,?,?,?,?,?)`
    ).run(uuid(), null, l.productName || "", l.qty || 0, l.unitCost || 0, l.value || 0, l.reason || "", l.note || "", l.date || nowIso(), nowIso());
  }

  return { success: true };
});

export default { restore };
