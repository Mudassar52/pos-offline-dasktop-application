import db, { uuid, nowIso } from "../db.js";
import { mapReturn } from "../utils/mappers.js";
import products from "./products.js";

// ── Order Returns (customer se wapis aaya hua maal) ───────────────────────
// Jab customer koi cheez wapis karta hai, hum yahan entry banate hain aur
// (agar catalog product select kiya gaya ho) us product ka stock wapis
// charha dete hain — taake wo dobara becha ja sake.

export function list() {
  return db.prepare("SELECT * FROM product_returns ORDER BY date DESC, created_at DESC").all().map(mapReturn);
}

export function create(f) {
  const qty = Number(f.qty);
  if (!qty || qty <= 0) {
    const err = new Error("Quantity must be greater than zero");
    err.status = 400;
    throw err;
  }
  const productName = String(f.productName || "").trim();
  if (!productName) {
    const err = new Error("Product name is required");
    err.status = 400;
    throw err;
  }
  const id = uuid();
  const ts = nowIso();
  db.prepare(
    `INSERT INTO product_returns (id, product_id, product_name, qty, reason, note, date, created_at)
     VALUES (?,?,?,?,?,?,?,?)`
  ).run(id, f.productId || null, productName, qty, f.reason || "", f.note || "", f.date || ts, ts);

  // Return karne se stock wapis shop mein aa jata hai.
  if (f.productId) {
    try {
      products.stockIn(f.productId, qty);
    } catch {
      /* product deleted/missing — return record still stands */
    }
  }

  return mapReturn(db.prepare("SELECT * FROM product_returns WHERE id = ?").get(id));
}

export function remove(id) {
  const row = db.prepare("SELECT * FROM product_returns WHERE id = ?").get(id);
  if (!row) return;
  // Return delete karne se wapis wo stock hata dena chahiye jo return add
  // karte waqt product mein wapis charha diya gaya tha.
  if (row.product_id) {
    try {
      products.stockOut(row.product_id, row.qty);
    } catch {
      /* product deleted/missing, or stock already used elsewhere — ignore */
    }
  }
  db.prepare("DELETE FROM product_returns WHERE id = ?").run(id);
}

export default { list, create, remove };
