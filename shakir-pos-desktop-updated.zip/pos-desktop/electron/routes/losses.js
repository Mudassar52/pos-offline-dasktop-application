import db, { uuid, nowIso } from "../db.js";
import { mapLoss } from "../utils/mappers.js";
import { mapProduct } from "../utils/mappers.js";
import products from "./products.js";

// ── Loss Management (damaged / expired / theft / breakage waghera) ───────
// Har loss entry ka value (Rs) qty × us waqt ki product cost price se
// calculate hota hai, aur (agar catalog product select kiya gaya ho) us
// product ka stock kam kar diya jata hai — kyunke wo maal ab bik nahi sakta.

export function list() {
  return db.prepare("SELECT * FROM product_losses ORDER BY date DESC, created_at DESC").all().map(mapLoss);
}

export function create(f) {
  const qty = Number(f.qty);
  if (!qty || qty <= 0) {
    const err = new Error("Quantity must be greater than zero");
    err.status = 400;
    throw err;
  }
  const productName = String(f.productName || "").trim();
  if (!productName) {
    const err = new Error("Product name is required");
    err.status = 400;
    throw err;
  }

  let unitCost = Number(f.unitCost) || 0;
  if (f.productId && !unitCost) {
    const row = db.prepare("SELECT * FROM products WHERE id = ?").get(f.productId);
    const prod = mapProduct(row);
    if (prod) unitCost = prod.costPrice || prod.stockPrice || 0;
  }

  const value = unitCost * qty;
  const id = uuid();
  const ts = nowIso();
  db.prepare(
    `INSERT INTO product_losses (id, product_id, product_name, qty, unit_cost, value, reason, note, date, created_at)
     VALUES (?,?,?,?,?,?,?,?,?,?)`
  ).run(id, f.productId || null, productName, qty, unitCost, value, f.reason || "Other", f.note || "", f.date || ts, ts);

  // Loss hone se stock kam ho jata hai — maal ab bik nahi sakta.
  if (f.productId) {
    try {
      products.stockOut(f.productId, qty);
    } catch {
      /* insufficient stock or product missing — loss record still stands */
    }
  }

  return mapLoss(db.prepare("SELECT * FROM product_losses WHERE id = ?").get(id));
}

export function remove(id) {
  const row = db.prepare("SELECT * FROM product_losses WHERE id = ?").get(id);
  if (!row) return;
  // Loss delete karne se wo stock wapis product mein add hona chahiye jo
  // loss add karte waqt kaat liya gaya tha.
  if (row.product_id) {
    try {
      products.stockIn(row.product_id, row.qty);
    } catch {
      /* product deleted/missing — ignore */
    }
  }
  db.prepare("DELETE FROM product_losses WHERE id = ?").run(id);
}

export default { list, create, remove };
