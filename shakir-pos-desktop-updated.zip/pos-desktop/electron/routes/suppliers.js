import db, { uuid, nowIso } from "../db.js";
import { mapSupplier, mapSupplierTransaction, mapSupplierPurchase } from "../utils/mappers.js";
import products from "./products.js";
import { getNextPurchaseInvoiceNumber } from "./settings.js";

// Ek purchase invoice ko items + payment history ke sath ek hi jagah se
// banata hai (addPurchase / updatePurchase / payInvoice / listPurchases sab
// isi ko use karte hain).
function buildPurchase(purchaseRow) {
  const items = db.prepare("SELECT * FROM supplier_purchase_items WHERE purchase_id = ?").all(purchaseRow.id);
  const payments = db
    .prepare("SELECT * FROM supplier_purchase_payments WHERE purchase_id = ? ORDER BY date ASC, created_at ASC")
    .all(purchaseRow.id);
  return mapSupplierPurchase(purchaseRow, items, payments);
}

function recordPurchasePayment({ purchaseId, supplierId, transactionId = null, amount, note = "", kind = "payment", date }) {
  db.prepare(
    `INSERT INTO supplier_purchase_payments (id, purchase_id, supplier_id, transaction_id, amount, note, kind, date, created_at)
     VALUES (?,?,?,?,?,?,?,?,?)`
  ).run(uuid(), purchaseId, supplierId, transactionId, Number(amount) || 0, note || "", kind, date, nowIso());
}

// Sab suppliers ki sab purchases (items + payment history ke sath) — sirf
// backup export ke liye. Har purchase mein supplierId bhi hota hai taake
// restore ke waqt sahi supplier se dobara link ho sake.
export function listAllPurchases() {
  const rows = db.prepare("SELECT * FROM supplier_purchases ORDER BY date ASC, created_at ASC").all();
  return rows.map((row) => buildPurchase(row));
}

export function list() {
  const rows = db.prepare("SELECT * FROM suppliers ORDER BY created_at DESC").all();
  return rows.map(mapSupplier);
}

export function create(f) {
  const id = uuid();
  const ts = nowIso();
  db.prepare(
    `INSERT INTO suppliers (id, name, phone, city, notes, created_at, updated_at) VALUES (?,?,?,?,?,?,?)`
  ).run(id, String(f.name || "").trim(), f.phone || "", f.city || "", f.notes || "", ts, ts);
  return mapSupplier(db.prepare("SELECT * FROM suppliers WHERE id = ?").get(id));
}

export function update(id, f) {
  const info = db
    .prepare(`UPDATE suppliers SET name=?, phone=?, city=?, notes=?, updated_at=? WHERE id=?`)
    .run(String(f.name || "").trim(), f.phone || "", f.city || "", f.notes || "", nowIso(), id);
  if (info.changes === 0) {
    const err = new Error("Supplier not found");
    err.status = 404;
    throw err;
  }
  return mapSupplier(db.prepare("SELECT * FROM suppliers WHERE id = ?").get(id));
}

// Deleting a supplier also removes its transaction history. (Handled
// explicitly here rather than relying on SQL's ON DELETE CASCADE, since
// that behavior isn't fully reliable across sql.js builds.)
export const remove = db.transaction((id) => {
  db.prepare("DELETE FROM supplier_purchase_payments WHERE supplier_id = ?").run(id);
  db.prepare("DELETE FROM supplier_transactions WHERE supplier_id = ?").run(id);
  db.prepare("DELETE FROM suppliers WHERE id = ?").run(id);
});

// ── Ledger ───────────────────────────────────────────────────────────────
export function listTransactions(supplierId) {
  const rows = db
    .prepare("SELECT * FROM supplier_transactions WHERE supplier_id = ? ORDER BY date DESC, created_at DESC")
    .all(supplierId);
  return rows.map(mapSupplierTransaction);
}

export function listAllTransactions() {
  const rows = db.prepare("SELECT * FROM supplier_transactions ORDER BY date DESC, created_at DESC").all();
  return rows.map(mapSupplierTransaction);
}

// type: 'purchase' (maal liya, hum par udhaar charhta hai) or
//       'payment'  (hum ne supplier ko paise diye, udhaar kam hota hai)
export function addTransaction(supplierId, { type, amount, description, date }) {
  if (!["purchase", "payment"].includes(type)) {
    const err = new Error("Invalid transaction type");
    err.status = 400;
    throw err;
  }
  const amt = Number(amount);
  if (!amt || amt <= 0) {
    const err = new Error("Amount must be greater than zero");
    err.status = 400;
    throw err;
  }
  const supplier = db.prepare("SELECT id FROM suppliers WHERE id = ?").get(supplierId);
  if (!supplier) {
    const err = new Error("Supplier not found");
    err.status = 404;
    throw err;
  }
  const id = uuid();
  db.prepare(
    `INSERT INTO supplier_transactions (id, supplier_id, type, amount, description, date, created_at)
     VALUES (?,?,?,?,?,?,?)`
  ).run(id, supplierId, type, amt, description || "", date || nowIso(), nowIso());
  db.prepare("UPDATE suppliers SET updated_at = ? WHERE id = ?").run(nowIso(), supplierId);
  return mapSupplierTransaction(db.prepare("SELECT * FROM supplier_transactions WHERE id = ?").get(id));
}

export function removeTransaction(id) {
  db.prepare("DELETE FROM supplier_transactions WHERE id = ?").run(id);
}

// ── Advance Balance (supplier ko pehle se diye gaye paise) ────────────────
// Hum koi alag column store nahi karte — yeh hamesha ledger se hi nikala
// jata hai: ab tak jitna "payment" diya gaya us mein se jitna "purchase"
// hua wo minus karo. Agar payment purchase se zyada ho, wo faltu amount
// hi asal mein "advance balance" hai — jo agli purchase par khud
// istemal ho jayega.
export function getAdvanceBalance(supplierId) {
  const row = db
    .prepare(
      `SELECT
         SUM(CASE WHEN type = 'purchase' THEN amount ELSE 0 END) AS purchased,
         SUM(CASE WHEN type = 'payment'  THEN amount ELSE 0 END) AS paid
       FROM supplier_transactions WHERE supplier_id = ?`
    )
    .get(supplierId);
  const purchased = Number(row?.purchased) || 0;
  const paid = Number(row?.paid) || 0;
  return Math.max(0, paid - purchased);
}

// Supplier ko advance dena — jab tak koi outstanding invoice hai, pehle
// wahi settle hoti hai (purani se nayi), jo bach jaye wo "advance balance"
// ki tarah pare rehta hai aur agli purchase par khud-ba-khud lag jata hai.
export function addAdvance(supplierId, { amount, note, date }) {
  return payInvoice(supplierId, {
    amount,
    note: note || "Advance Payment",
    date,
    purchaseId: null,
  });
}

// ── Purchase maal from supplier — ek batch mein multiple products ────────
// Ek hi action mein: (a) har product ka stock badhta hai — agar naya
// product hai to wo khud Products page mein add ho jata hai, (b) supplier
// ki ledger mein "purchase" entry (poore order ki total × amount) charhti
// hai, (c) agar advance diya gaya ho to usi waqt ek "payment" entry bhi ban
// jati hai, aur (d) poora batch ek "supplier_purchases" record ki tarah save
// hota hai taake baad mein ek hi thermal receipt (Urdu) par print ho sake.
export function addPurchase(supplierId, f) {
  const supplier = db.prepare("SELECT id, name FROM suppliers WHERE id = ?").get(supplierId);
  if (!supplier) {
    const err = new Error("Supplier not found");
    err.status = 404;
    throw err;
  }

  // Backward-compatible: purana single-item shape { productId/productName,
  // purchasePrice, qty } bhi chalta hai, naya shape { items: [...] } bhi.
  const rawItems = Array.isArray(f.items) && f.items.length > 0
    ? f.items
    : [{ productId: f.productId, productName: f.productName, purchasePrice: f.purchasePrice, qty: f.qty, category: f.category, salePrice: f.salePrice, lowStockAlertQty: f.lowStockAlertQty }];

  if (rawItems.length === 0) {
    const err = new Error("Kam az kam ek product add karein");
    err.status = 400;
    throw err;
  }

  const date = f.date || nowIso();
  const advance = Math.max(0, Number(f.advance) || 0);

  const items = [];
  let total = 0;
  const updatedProducts = [];

  for (const raw of rawItems) {
    const qty = Number(raw.qty);
    if (!qty || qty <= 0) {
      const err = new Error("Har product ki quantity 0 se zyada honi chahiye");
      err.status = 400;
      throw err;
    }
    const purchasePrice = Number(raw.purchasePrice);
    if (!purchasePrice || purchasePrice <= 0) {
      const err = new Error("Har product ki purchase price 0 se zyada honi chahiye");
      err.status = 400;
      throw err;
    }

    let product;
    if (raw.productId) {
      // Existing product — sirf stock badhta hai. Cost price jaan-boojh
      // kar yahan se overwrite NAHI hoti — wo Products page se hi manage
      // hoti hai, taake supplier ka purchase rate use ka apna cost price
      // silently na badal de.
      const existing = products.stockIn(raw.productId, qty);
      product = existing;
    } else {
      const name = String(raw.productName || "").trim();
      if (!name) {
        const err = new Error("Product name is required");
        err.status = 400;
        throw err;
      }
      // Naya product — is purchase se pehli baar catalog mein aa raha hai,
      // isliye iski shuruwati cost price purchase price hi hogi.
      product = products.create({
        name,
        category: raw.category || "Others",
        salePrice: Number(raw.salePrice) || purchasePrice,
        costPrice: purchasePrice,
        stockPrice: purchasePrice,
        currentStock: qty,
        lowStockAlertQty: Number(raw.lowStockAlertQty) || 0,
      });
    }

    const lineTotal = qty * purchasePrice;
    total += lineTotal;
    updatedProducts.push(product);
    items.push({ productId: product.id, productName: product.name, qty, purchasePrice, lineTotal });
  }

  const manualAdvance = Math.min(advance, total);

  // Agar is supplier ka pehle se diya hua "advance balance" maujood hai
  // (purani payments jo kisi purchase ke against nahi lagi), to wo yahan
  // khud-ba-khud is nayi purchase par lag jata hai — jitna zaroorat ho
  // utna hi, taake customer/dukaandar ko dobara se manually advance na
  // dena pare.
  const advanceBalanceAvailable = getAdvanceBalance(supplierId);
  const advanceFromBalance = Math.min(advanceBalanceAvailable, Math.max(0, total - manualAdvance));

  const cappedAdvance = Math.min(manualAdvance + advanceFromBalance, total);
  const remaining = Math.max(0, total - cappedAdvance);

  // Purchase batch save karo (items samet, apna alag invoice number ke sath)
  // — receipt printing aur baad mein view/edit ke liye.
  const purchaseId = uuid();
  const invoiceNumber = getNextPurchaseInvoiceNumber();
  db.prepare(
    `INSERT INTO supplier_purchases (id, supplier_id, invoice_number, total, advance, remaining, date, created_at) VALUES (?,?,?,?,?,?,?,?)`
  ).run(purchaseId, supplierId, invoiceNumber, total, cappedAdvance, remaining, date, nowIso());
  for (const item of items) {
    db.prepare(
      `INSERT INTO supplier_purchase_items (id, purchase_id, product_id, product_name, qty, purchase_price, line_total) VALUES (?,?,?,?,?,?,?)`
    ).run(uuid(), purchaseId, item.productId, item.productName, item.qty, item.purchasePrice, item.lineTotal);
  }

  // Ledger continuity ke liye same purani transaction entries bhi banti hain
  // — `purchase_id` se hamesha wapis isi invoice se link rehti hain (edit/
  // targeted payment ke liye).
  const summaryDesc = items.length === 1
    ? `${items[0].productName} × ${items[0].qty} @ Rs ${items[0].purchasePrice}`
    : `${items.length} products (${items.map((i) => i.productName).join(", ")})`;
  const txnId = uuid();
  db.prepare(
    `INSERT INTO supplier_transactions (id, supplier_id, type, amount, description, purchase_id, date, created_at) VALUES (?,?,?,?,?,?,?,?)`
  ).run(txnId, supplierId, "purchase", total, summaryDesc, purchaseId, date, nowIso());

  // Sirf naye (abhi diye gaye) cash advance ki hi nayi "payment" ledger
  // entry banti hai. Jo hissa purane advance balance se laga hai, uska
  // paisa pehle hi kisi aur payment mein ledger mein record ho chuka tha
  // — dobara entry banane se woh amount do baar count ho jata (double
  // counting), isliye yahan sirf `manualAdvance` hi likha jata hai.
  let paymentTxn = null;
  if (manualAdvance > 0) {
    const paymentId = uuid();
    db.prepare(
      `INSERT INTO supplier_transactions (id, supplier_id, type, amount, description, purchase_id, date, created_at) VALUES (?,?,?,?,?,?,?,?)`
    ).run(paymentId, supplierId, "payment", manualAdvance, `Advance — Invoice #${invoiceNumber}`, purchaseId, date, nowIso());
    paymentTxn = mapSupplierTransaction(db.prepare("SELECT * FROM supplier_transactions WHERE id = ?").get(paymentId));
    // Invoice ki payment history mein bhi likho (khareedte waqt diya gaya advance).
    recordPurchasePayment({ purchaseId, supplierId, transactionId: paymentId, amount: manualAdvance, kind: "advance", date });
  }
  // Jo hissa pehle se jama advance balance se laga, woh bhi is invoice ki
  // payment history mein alag line ban kar dikhna chahiye (ledger mein
  // dobara entry nahi banti, sirf invoice ke record mein).
  if (advanceFromBalance > 0) {
    recordPurchasePayment({ purchaseId, supplierId, amount: advanceFromBalance, kind: "balance", date });
  }

  db.prepare("UPDATE suppliers SET updated_at = ? WHERE id = ?").run(nowIso(), supplierId);

  const purchaseRow = db.prepare("SELECT * FROM supplier_purchases WHERE id = ?").get(purchaseId);

  return {
    purchaseRecord: buildPurchase(purchaseRow),
    purchase: mapSupplierTransaction(db.prepare("SELECT * FROM supplier_transactions WHERE id = ?").get(txnId)),
    payment: paymentTxn,
    products: updatedProducts,
    total,
    advance: cappedAdvance,
    advanceFromBalance,
    remaining,
  };
}

// ── Edit an existing purchase invoice ───────────────────────────────────
// Purane items ka stock pehle "undo" hota hai (jo unhone add kiya tha wo
// wapas kaat diya jata hai), phir naye items ki tarah dobara process hota
// hai — taake product stock hamesha sahi rahe chahe purchase kitni baar
// edit ho. Advance jaan-boojh kar edit nahi hoti (wo alag "payment" action
// se manage hoti hai) — sirf total/remaining naye items ke hisaab se
// recalculate hote hain.
export function updatePurchase(supplierId, purchaseId, f) {
  const purchase = db.prepare("SELECT * FROM supplier_purchases WHERE id = ? AND supplier_id = ?").get(purchaseId, supplierId);
  if (!purchase) {
    const err = new Error("Purchase invoice not found");
    err.status = 404;
    throw err;
  }
  const oldItems = db.prepare("SELECT * FROM supplier_purchase_items WHERE purchase_id = ?").all(purchaseId);

  const rawItems = Array.isArray(f.items) ? f.items : [];
  if (rawItems.length === 0) {
    const err = new Error("Kam az kam ek product add karein");
    err.status = 400;
    throw err;
  }

  // Purane items ka stock reverse karo (jo stockIn hua tha, wapas stockOut).
  for (const old of oldItems) {
    if (old.product_id) {
      try { products.stockOut(old.product_id, old.qty); } catch { /* product deleted or insufficient stock */ }
    }
  }
  db.prepare("DELETE FROM supplier_purchase_items WHERE purchase_id = ?").run(purchaseId);

  const items = [];
  let total = 0;
  const updatedProducts = [];
  for (const raw of rawItems) {
    const qty = Number(raw.qty);
    if (!qty || qty <= 0) {
      const err = new Error("Har product ki quantity 0 se zyada honi chahiye");
      err.status = 400;
      throw err;
    }
    const purchasePrice = Number(raw.purchasePrice);
    if (!purchasePrice || purchasePrice <= 0) {
      const err = new Error("Har product ki purchase price 0 se zyada honi chahiye");
      err.status = 400;
      throw err;
    }
    let product;
    if (raw.productId) {
      // Existing product — cost price yahan se overwrite nahi hoti (see
      // addPurchase ka comment).
      product = products.stockIn(raw.productId, qty);
    } else {
      const name = String(raw.productName || "").trim();
      if (!name) {
        const err = new Error("Product name is required");
        err.status = 400;
        throw err;
      }
      product = products.create({
        name, category: raw.category || "Others", salePrice: Number(raw.salePrice) || purchasePrice,
        costPrice: purchasePrice, stockPrice: purchasePrice, currentStock: qty,
        lowStockAlertQty: Number(raw.lowStockAlertQty) || 0,
      });
    }
    const lineTotal = qty * purchasePrice;
    total += lineTotal;
    updatedProducts.push(product);
    items.push({ productId: product.id, productName: product.name, qty, purchasePrice, lineTotal });
    db.prepare(
      `INSERT INTO supplier_purchase_items (id, purchase_id, product_id, product_name, qty, purchase_price, line_total) VALUES (?,?,?,?,?,?,?)`
    ).run(uuid(), purchaseId, product.id, product.name, qty, purchasePrice, lineTotal);
  }

  const advance = Math.min(purchase.advance, total);
  const remaining = Math.max(0, total - advance);
  const date = f.date || purchase.date;

  db.prepare("UPDATE supplier_purchases SET total = ?, advance = ?, remaining = ?, date = ? WHERE id = ?")
    .run(total, advance, remaining, date, purchaseId);

  const summaryDesc = items.length === 1
    ? `${items[0].productName} × ${items[0].qty} @ Rs ${items[0].purchasePrice}`
    : `${items.length} products (${items.map((i) => i.productName).join(", ")})`;
  db.prepare("UPDATE supplier_transactions SET amount = ?, description = ?, date = ? WHERE purchase_id = ? AND type = 'purchase'")
    .run(total, summaryDesc, date, purchaseId);

  db.prepare("UPDATE suppliers SET updated_at = ? WHERE id = ?").run(nowIso(), supplierId);

  const purchaseRow = db.prepare("SELECT * FROM supplier_purchases WHERE id = ?").get(purchaseId);
  return { purchaseRecord: buildPurchase(purchaseRow), products: updatedProducts };
}

// ── Payment against a purchase — specific invoice, ya overall balance ──
// purchaseId diya ho to sirf usi invoice ka advance/remaining update hota
// hai. Na diya ho ("overall" payment) to jitne bhi invoices ka remaining
// baaki hai, purani se nayi (FIFO) — sab ka remaining khud-ba-khud update
// hota reh ta hai jab tak amount khatam na ho jaye.
export function payInvoice(supplierId, f) {
  const supplier = db.prepare("SELECT id FROM suppliers WHERE id = ?").get(supplierId);
  if (!supplier) {
    const err = new Error("Supplier not found");
    err.status = 404;
    throw err;
  }
  let amount = Number(f.amount);
  if (!amount || amount <= 0) {
    const err = new Error("Amount 0 se zyada hona chahiye");
    err.status = 400;
    throw err;
  }
  const date = f.date || nowIso();
  const affectedPurchases = [];
  // Payment ki ledger entry ki id pehle hi le lete hain taake har invoice
  // ki payment history isi transaction se link ho sake.
  const paymentId = uuid();
  const userNote = String(f.note || "").trim();

  if (f.purchaseId) {
    const purchase = db.prepare("SELECT * FROM supplier_purchases WHERE id = ? AND supplier_id = ?").get(f.purchaseId, supplierId);
    if (!purchase) {
      const err = new Error("Purchase invoice not found");
      err.status = 404;
      throw err;
    }
    const applied = Math.min(amount, purchase.remaining);
    const newAdvance = purchase.advance + applied;
    const newRemaining = Math.max(0, purchase.total - newAdvance);
    db.prepare("UPDATE supplier_purchases SET advance = ?, remaining = ? WHERE id = ?").run(newAdvance, newRemaining, f.purchaseId);
    affectedPurchases.push(f.purchaseId);
    if (applied > 0) {
      recordPurchasePayment({ purchaseId: f.purchaseId, supplierId, transactionId: paymentId, amount: applied, note: userNote, kind: "payment", date });
    }
  } else {
    // Overall payment — sabse purani outstanding invoice se shuru karo.
    const outstanding = db.prepare("SELECT * FROM supplier_purchases WHERE supplier_id = ? AND remaining > 0 ORDER BY date ASC, created_at ASC").all(supplierId);
    for (const purchase of outstanding) {
      if (amount <= 0) break;
      const applied = Math.min(amount, purchase.remaining);
      const newAdvance = purchase.advance + applied;
      const newRemaining = Math.max(0, purchase.total - newAdvance);
      db.prepare("UPDATE supplier_purchases SET advance = ?, remaining = ? WHERE id = ?").run(newAdvance, newRemaining, purchase.id);
      affectedPurchases.push(purchase.id);
      if (applied > 0) {
        recordPurchasePayment({ purchaseId: purchase.id, supplierId, transactionId: paymentId, amount: applied, note: userNote, kind: "payment", date });
      }
      amount -= applied;
    }
  }

  db.prepare(
    `INSERT INTO supplier_transactions (id, supplier_id, type, amount, description, purchase_id, date, created_at) VALUES (?,?,?,?,?,?,?,?)`
  ).run(paymentId, supplierId, "payment", Number(f.amount), f.note || (f.purchaseId ? "Payment against invoice" : "Overall payment"), f.purchaseId || null, date, nowIso());

  db.prepare("UPDATE suppliers SET updated_at = ? WHERE id = ?").run(nowIso(), supplierId);

  const updatedPurchases = affectedPurchases.map((pid) => {
    const row = db.prepare("SELECT * FROM supplier_purchases WHERE id = ?").get(pid);
    return buildPurchase(row);
  });

  return {
    payment: mapSupplierTransaction(db.prepare("SELECT * FROM supplier_transactions WHERE id = ?").get(paymentId)),
    updatedPurchases,
  };
}

// Supplier ki saari purchase receipts (items samet) — Purchases tab ke liye.
export function listPurchases(supplierId) {
  const rows = db.prepare("SELECT * FROM supplier_purchases WHERE supplier_id = ? ORDER BY date DESC, created_at DESC").all(supplierId);
  return rows.map((row) => buildPurchase(row));
}

export default {
  list, create, update, remove,
  listTransactions, listAllTransactions, addTransaction, removeTransaction,
  getAdvanceBalance, addAdvance,
  addPurchase, updatePurchase, payInvoice, listPurchases, listAllPurchases,
};
