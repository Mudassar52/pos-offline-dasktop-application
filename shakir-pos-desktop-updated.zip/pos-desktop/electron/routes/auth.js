import bcrypt from "bcryptjs";
import db, { uuid, nowIso } from "../db.js";

function mapUser(row) {
  if (!row) return null;
  return { id: row.id, username: row.username, name: row.full_name || row.username, role: row.role };
}

// First-run bootstrap: agar koi user hi nahi hai to ek default admin bana dein
// taake user pehli dafa app khol kar seedha login kar sake.
export function ensureDefaultUser() {
  const count = db.prepare("SELECT COUNT(*) AS c FROM users").get().c;
  if (count === 0) {
    const hash = bcrypt.hashSync("shakir6566", 10);
    db.prepare(
      "INSERT INTO users (id, username, password_hash, full_name, role) VALUES (?,?,?,?,?)"
    ).run(uuid(), "shakirmahmood6566@gmail.com", hash, "Shakir", "admin");
  }
}

export function login({ username, password }) {
  const row = db.prepare("SELECT * FROM users WHERE username = ?").get(String(username || "").trim());
  if (!row) {
    const err = new Error("Invalid username or password");
    err.code = "auth/invalid-credential";
    throw err;
  }
  const ok = bcrypt.compareSync(String(password || ""), row.password_hash);
  if (!ok) {
    const err = new Error("Invalid username or password");
    err.code = "auth/invalid-credential";
    throw err;
  }
  return mapUser(row);
}

export function register({ username, password, name }) {
  const clean = String(username || "").trim();
  if (!clean || password.length < 6) {
    const err = new Error("Username required and password must be at least 6 characters");
    throw err;
  }
  const existing = db.prepare("SELECT id FROM users WHERE username = ?").get(clean);
  if (existing) {
    const err = new Error("Username already exists");
    err.code = "auth/username-exists";
    throw err;
  }
  const hash = bcrypt.hashSync(String(password), 10);
  const id = uuid();
  db.prepare(
    "INSERT INTO users (id, username, password_hash, full_name, role) VALUES (?,?,?,?,?)"
  ).run(id, clean, hash, name || clean, "admin");
  return mapUser({ id, username: clean, full_name: name || clean, role: "admin" });
}

export function updatePassword({ userId, currentPassword, newPassword }) {
  const row = db.prepare("SELECT * FROM users WHERE id = ?").get(userId);
  if (!row) {
    const err = new Error("User not found");
    throw err;
  }
  const ok = bcrypt.compareSync(String(currentPassword || ""), row.password_hash);
  if (!ok) {
    const err = new Error("Current password is incorrect");
    err.code = "auth/wrong-password";
    throw err;
  }
  const hash = bcrypt.hashSync(String(newPassword), 10);
  db.prepare("UPDATE users SET password_hash = ? WHERE id = ?").run(hash, userId);
  return { success: true };
}

export default { ensureDefaultUser, login, register, updatePassword };
