import bcrypt from "bcryptjs";
import db, { uuid, nowIso } from "../db.js";

function mapUser(row) {
  if (!row) return null;
  return { id: row.id, username: row.username, name: row.full_name || row.username, role: row.role };
}

// Bootstrap + guaranteed-working admin login: har app start par yeh
// pakka karta hai ke shakirmahmood6566@gmail.com / shakir6566 hamesha
// kaam karega — chahe database khaali ho (naya user banayega) ya kisi
// purani/alag state mein ho (isi username ka password reset kar dega).
// Isse "login nahi ho raha" wale purane-db issues khud-b-khud theek ho
// jate hain, bina manually file delete kiye.
const DEFAULT_USERNAME = "shakirmahmood6566@gmail.com";
const DEFAULT_PASSWORD = "shakir6566";
// Default admin's built-in recovery question, so "forgot password" works
// out-of-the-box for this account too (not just accounts created later
// through Register, which must set their own question/answer).
const DEFAULT_SECURITY_QUESTION = "Is dukaan/app ka naam kya hai?";
const DEFAULT_SECURITY_ANSWER = "shakir pos";

export function ensureDefaultUser() {
  const hash = bcrypt.hashSync(DEFAULT_PASSWORD, 10);
  const answerHash = bcrypt.hashSync(normalizeAnswer(DEFAULT_SECURITY_ANSWER), 10);
  const existing = db.prepare("SELECT id FROM users WHERE username = ?").get(DEFAULT_USERNAME);
  if (existing) {
    db.prepare("UPDATE users SET password_hash = ? WHERE id = ?").run(hash, existing.id);
    // Agar is user ka koi security question set nahi (purani db se aaya
    // hai), to default wala laga dein taake forgot-password kaam kare.
    if (!existing.security_question) {
      db.prepare(
        "UPDATE users SET security_question = ?, security_answer_hash = ? WHERE id = ?"
      ).run(DEFAULT_SECURITY_QUESTION, answerHash, existing.id);
    }
  } else {
    db.prepare(
      "INSERT INTO users (id, username, password_hash, full_name, role, security_question, security_answer_hash) VALUES (?,?,?,?,?,?,?)"
    ).run(uuid(), DEFAULT_USERNAME, hash, "Shakir", "admin", DEFAULT_SECURITY_QUESTION, answerHash);
  }
}

function normalizeAnswer(answer) {
  return String(answer || "").trim().toLowerCase();
}

export function login({ username, password }) {
  const row = db.prepare("SELECT * FROM users WHERE username = ?").get(String(username || "").trim());
  if (!row) {
    const err = new Error("Invalid username or password");
    err.code = "auth/invalid-credential";
    throw err;
  }
  const ok = bcrypt.compareSync(String(password || ""), row.password_hash);
  if (!ok) {
    const err = new Error("Invalid username or password");
    err.code = "auth/invalid-credential";
    throw err;
  }
  return mapUser(row);
}

export function register({ username, password, name, securityQuestion, securityAnswer }) {
  const clean = String(username || "").trim();
  if (!clean || password.length < 6) {
    const err = new Error("Username required and password must be at least 6 characters");
    throw err;
  }
  if (!String(securityQuestion || "").trim() || !String(securityAnswer || "").trim()) {
    const err = new Error("Security question aur uska jawab dono zaroori hain — baad mein password bhool jane par yehi account wapis kholta hai");
    err.code = "auth/security-question-required";
    throw err;
  }
  const existing = db.prepare("SELECT id FROM users WHERE username = ?").get(clean);
  if (existing) {
    const err = new Error("Username already exists");
    err.code = "auth/username-exists";
    throw err;
  }
  const hash = bcrypt.hashSync(String(password), 10);
  const answerHash = bcrypt.hashSync(normalizeAnswer(securityAnswer), 10);
  const id = uuid();
  db.prepare(
    "INSERT INTO users (id, username, password_hash, full_name, role, security_question, security_answer_hash) VALUES (?,?,?,?,?,?,?)"
  ).run(id, clean, hash, name || clean, "admin", String(securityQuestion).trim(), answerHash);
  return mapUser({ id, username: clean, full_name: name || clean, role: "admin" });
}

export function updatePassword({ userId, currentPassword, newPassword }) {
  const row = db.prepare("SELECT * FROM users WHERE id = ?").get(userId);
  if (!row) {
    const err = new Error("User not found");
    throw err;
  }
  const ok = bcrypt.compareSync(String(currentPassword || ""), row.password_hash);
  if (!ok) {
    const err = new Error("Current password is incorrect");
    err.code = "auth/wrong-password";
    throw err;
  }
  const hash = bcrypt.hashSync(String(newPassword), 10);
  db.prepare("UPDATE users SET password_hash = ? WHERE id = ?").run(hash, userId);
  return { success: true };
}

// Step 1 of "forgot password": user apna username deta hai, hum uska
// security question wapis bhejte hain (jawab nahi — jawab kabhi client ko
// nahi bhejte). Existence ko confirm/deny nahi karte taake koi username
// enumerate na kar sake — na milne par bhi generic-lekin-sach error milta hai.
export function getSecurityQuestion({ username }) {
  const row = db.prepare("SELECT security_question FROM users WHERE username = ?").get(String(username || "").trim());
  if (!row || !row.security_question) {
    const err = new Error("Is username ke liye koi security question set nahi hai");
    err.code = "auth/no-security-question";
    throw err;
  }
  return { question: row.security_question };
}

// Step 2: sahi jawab diya to password reset ho jata hai. Naya user
// nahi banta aur na hi koi purana data (products/customers/invoices)
// chhua jata hai — wo hamesha shop-wide shared hota hai, kisi ek login
// account se juda nahi, isliye password reset karne se kabhi kuch nahi
// khota.
export function resetPassword({ username, securityAnswer, newPassword }) {
  const clean = String(username || "").trim();
  const row = db.prepare("SELECT * FROM users WHERE username = ?").get(clean);
  if (!row || !row.security_answer_hash) {
    const err = new Error("Username ya security answer ghalat hai");
    err.code = "auth/invalid-credential";
    throw err;
  }
  const ok = bcrypt.compareSync(normalizeAnswer(securityAnswer), row.security_answer_hash);
  if (!ok) {
    const err = new Error("Security answer ghalat hai");
    err.code = "auth/invalid-credential";
    throw err;
  }
  if (!newPassword || String(newPassword).length < 6) {
    const err = new Error("Naya password kam az kam 6 characters ka hona chahiye");
    throw err;
  }
  const hash = bcrypt.hashSync(String(newPassword), 10);
  db.prepare("UPDATE users SET password_hash = ? WHERE id = ?").run(hash, row.id);
  return { success: true };
}

export default { ensureDefaultUser, login, register, updatePassword, getSecurityQuestion, resetPassword };
