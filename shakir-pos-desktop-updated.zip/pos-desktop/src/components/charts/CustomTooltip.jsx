export default function CustomTooltip({ active, payload, label }) {
  if (active && payload && payload.length) {
    return (
      <div dir="rtl" className="bg-white border border-blue-100 shadow-lg rounded-xl p-3 text-sm text-right">
        <p className="font-semibold text-black mb-1">{label}</p>
        {payload.map((p, i) => (
          <p key={i} style={{ color: p.color }}>
            {p.name}: <span className="font-semibold" dir="ltr">Rs {p.value.toLocaleString()}</span>
          </p>
        ))}
      </div>
    );
  }
  return null;
}
