import { useMemo, useState } from "react";
import StatsGrid from "../common/StatsGrid";
import RevenueChart from "./RevenueChart";
import TopProductsList from "./TopProductsList";
import DateRangePicker from "../common/DateRangePicker";
import { formatCurrency } from "../../utils/productHelpers";
import { URDU_MONTHS } from "../../utils/reportCalculations";


// ── Dashboard period filter options ──
const DASHBOARD_PERIODS = [
  { key: "today", label: "آج" },
  { key: "week", label: "اس ہفتے" },
  { key: "month", label: "اس مہینے" },
  { key: "all", label: "تمام وقت" },
];

// Invoice ki date diye gaye period ke andar aati hai ya nahi, check karta hai.
function isInPeriod(dateStr, period, now, customRange) {
  if (period === "custom") {
    if (!customRange?.from || !customRange?.to) return false;
    const iso = dateStr.slice(0, 10);
    return iso >= customRange.from && iso <= customRange.to;
  }
  if (period === "all") return true;
  const d = new Date(dateStr);
  if (period === "today") {
    return d.toDateString() === now.toDateString();
  }
  if (period === "week") {
    // Rolling last 7 days (aaj samet)
    const weekAgo = new Date(now);
    weekAgo.setDate(weekAgo.getDate() - 6);
    weekAgo.setHours(0, 0, 0, 0);
    return d >= weekAgo && d <= now;
  }
  if (period === "month") {
    return d.getFullYear() === now.getFullYear() && d.getMonth() === now.getMonth();
  }
  return true;
}

export default function DashboardView({ products = [], allInvoices = [], customers = [], expenses = [], losses = [] }) {
  const [dashboardPeriod, setDashboardPeriod] = useState("month");
  const [customRange, setCustomRange] = useState({ from: null, to: null });
  const now = new Date();
  const currentYear = now.getFullYear();
  const currentMonth = now.getMonth();
  const periodLabel = dashboardPeriod === "custom"
    ? (customRange.from && customRange.to ? "منتخب مدت" : "مدت منتخب کریں")
    : (DASHBOARD_PERIODS.find((p) => p.key === dashboardPeriod)?.label || "اس مہینے");

  const handleCustomRangeChange = (range) => {
    setCustomRange(range);
    if (range.from && range.to) setDashboardPeriod("custom");
  };

  // Selected period ke andar aane wali invoices — sare stats cards isi par based hain.
  const periodInvoices = useMemo(
    () => allInvoices.filter((inv) => isInPeriod(inv.createdAt, dashboardPeriod, now, customRange)),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [allInvoices, dashboardPeriod, customRange]
  );

  // ── Fast O(1) product lookup instead of products.find() inside loops ──
  // (products.find() run once per invoice-line-item was an O(invoices × items × products)
  // hot spot — with a decent-sized product catalog + invoice history this alone could
  // make the Dashboard visibly hang every time you navigated to it.)
  const productById = useMemo(() => {
    const m = new Map();
    products.forEach((p) => m.set(String(p.id), p));
    return m;
  }, [products]);
  const productByName = useMemo(() => {
    const m = new Map();
    products.forEach((p) => m.set(p.name, p));
    return m;
  }, [products]);
  const lookupProduct = (item) => {
    if (item.productId != null) {
      const byId = productById.get(String(item.productId));
      if (byId) return byId;
    }
    return productByName.get(item.name);
  };

  // ── Per-invoice financials computed ONCE and reused everywhere below ──
  // (previously, advance/payment splitting + due calculation was recomputed
  // redundantly 4-5 separate times across statsCards + outstandingSummary,
  // each re-scanning every invoice's payments array from scratch.)
  const invoiceFinancials = useMemo(() => {
    const map = new Map();
    allInvoices.forEach((inv) => {
      let advInPayments = 0;
      let otherPmts = 0;
      (inv.payments || []).forEach((p) => {
        if (p.note && p.note.includes("Advance at sale")) advInPayments += p.amount || 0;
        else otherPmts += p.amount || 0;
      });
      const standAloneAdv = advInPayments > 0 ? 0 : (inv.advance || 0);
      const paid = advInPayments + otherPmts + standAloneAdv;
      const due = Math.max(0, (inv.total || 0) - paid);
      map.set(inv.id, { due, otherPmts });
    });
    return map;
  }, [allInvoices]);

  /* ── Total Stock Value (cost price ke hisaab se, sab products ka) ── */
  /* Yeh period filter se independent hai — stock ki current snapshot value hai */
  const totalStockValue = useMemo(() => {
    return products.reduce((sum, p) => {
      const unitCost = p.costPrice ?? p.stockPrice ?? p.salePrice ?? 0;
      return sum + unitCost * (p.currentStock || 0);
    }, 0);
  }, [products]);

  /* ── Stats Cards (selected period ke hisaab se) ── */
  const statsCards = useMemo(() => {
    const totalRevenue = periodInvoices.reduce((s, i) => s + (i.total || 0), 0);

    const thisMonthRevenue = allInvoices
      .filter(i => { const d = new Date(i.createdAt); return d.getFullYear() === currentYear && d.getMonth() === currentMonth; })
      .reduce((s, i) => s + (i.total || 0), 0);

    const lastMonthRevenue = allInvoices
      .filter(i => {
        const d = new Date(i.createdAt);
        const lm = currentMonth === 0 ? 11 : currentMonth - 1;
        const ly = currentMonth === 0 ? currentYear - 1 : currentYear;
        return d.getFullYear() === ly && d.getMonth() === lm;
      })
      .reduce((s, i) => s + (i.total || 0), 0);

    // ✅ FIX: Profit helper - Same logic as Reports (backend `/api/reports` route)
    const calcProfit = (inv) => {
      // Purana udhaar (bina product ke manually add kiya gaya) revenue mein count hota hai
      // lekin profit mein nahi — kyunki iska koi cost/item nahi hota.
      if (inv.isOldUdaar) return 0;
      // First try stored grossProfit
      let fullProfit;
      if (inv.grossProfit !== undefined && inv.grossProfit !== null && inv.grossProfit > 0) {
        fullProfit = inv.grossProfit;
      } else {
        // Fallback: calculate from items
        const cost = (inv.items || []).reduce((s, item) => {
          let cp = item.costPrice;
          if ((cp === undefined || cp === null || cp === 0) && products.length > 0) {
            const prod = lookupProduct(item);
            if (prod) cp = prod.costPrice || prod.stockPrice || 0;
          }
          return s + ((cp || 0) * (item.qty || 0));
        }, 0);

        // Apply discount factor (same as Reports)
        const subtotal = inv.subtotal || inv.total || 0;
        const total = inv.total || 0;
        const discountFactor = subtotal > 0 ? (total / subtotal) : 1;
        const adjustedCost = cost * Math.min(discountFactor, 1);
        fullProfit = Math.max(0, total - adjustedCost);
      }

      // Udaar/partial invoices ka jitna hissa abhi tak wasool nahi hua, us
      // hisse ka profit abhi count nahi karna — sirf wasool shuda (paid)
      // amount ke hisaab se munafa dikhana hai (same as backend Reports route).
      if (inv.paymentStatus === "udaar" || inv.paymentStatus === "partial") {
        const total = inv.total || 0;
        if (total <= 0) return 0;
        const due = invoiceFinancials.get(inv.id)?.due ?? 0;
        const paid = Math.max(0, total - due);
        const paidRatio = Math.max(0, Math.min(1, paid / total));
        return fullProfit * paidRatio;
      }

      return fullProfit;
    };

    const lastMonthInvoices = allInvoices.filter(i => {
      const d = new Date(i.createdAt);
      const lm = currentMonth === 0 ? 11 : currentMonth - 1;
      const ly = currentMonth === 0 ? currentYear - 1 : currentYear;
      return d.getFullYear() === ly && d.getMonth() === lm;
    });
    const lastMonthProfit = lastMonthInvoices.reduce((s, i) => s + calcProfit(i), 0);

    const revenueChangePct = lastMonthRevenue > 0
      ? ((thisMonthRevenue - lastMonthRevenue) / lastMonthRevenue * 100).toFixed(1)
      : null;

    // Selected period ka profit — old udaar entries revenue mein aate hain, profit mein nahi.
    const periodProfit = periodInvoices.reduce((s, i) => s + calcProfit(i), 0);

    // Selected period ke expenses aur losses — Net Profit = Profit − Expenses − Losses.
    const periodExpenses = expenses
      .filter((e) => isInPeriod(e.date, dashboardPeriod, now, customRange))
      .reduce((s, e) => s + e.amount, 0);
    const periodLosses = losses
      .filter((l) => isInPeriod(l.date, dashboardPeriod, now, customRange))
      .reduce((s, l) => s + l.value, 0);
    const netProfit = periodProfit - periodExpenses - periodLosses;

    // % change ka comparison sirf "This Month" period ke liye maani rakhta hai
    // (baqi periods ke liye koi natural pichla-period comparison nahi hai).
    const showMonthComparison = dashboardPeriod === "month";

    const periodUdaarInvoices = periodInvoices.filter(inv => inv.paymentStatus === "udaar" || inv.paymentStatus === "partial");
    const totalUdaar = periodUdaarInvoices.reduce((s, inv) => s + (invoiceFinancials.get(inv.id)?.due || 0), 0);
    // ✅ FIX: "Udaar Receive" ab payment ki apni date ke hisaab se count hoti hai,
    // invoice kab banaya gaya tha uske hisaab se nahi. Pehle sirf "periodInvoices"
    // (jo is period mein BANI thi) ki payments count hoti thin — matlab agar
    // koi purani udaar invoice ki payment aaj wasool hui, to wo "Today" ke stats
    // mein bilkul show hi nahi hoti thi. Ab hum SAARI invoices (allInvoices) ke
    // payments scan karte hain aur jis payment ki apni date is period ke andar
    // aati hai, sirf wahi count hoti hai — chahe invoice kisi bhi purani date ki ho.
    let totalUdaarReceived = 0;
    allInvoices.forEach((inv) => {
      (inv.payments || []).forEach((p) => {
        if (p.note && p.note.includes("Advance at sale")) return; // sale ke waqt ka advance revenue mein pehle hi shamil hai
        if (!p.date) return;
        if (isInPeriod(p.date, dashboardPeriod, now, customRange)) totalUdaarReceived += p.amount || 0;
      });
    });

    return [
      {
        title: `کل سیلز (${periodLabel})`,
        value: formatCurrency(totalRevenue),
        change: showMonthComparison && revenueChangePct !== null ? `${revenueChangePct > 0 ? "+" : ""}${revenueChangePct}%` : null,
        up: revenueChangePct >= 0,
        icon: "M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z",
        light: "bg-blue-50", text: "text-blue-600",
      },
      {
        title: `مجموعی منافع (${periodLabel})`,
        value: formatCurrency(periodProfit),
        change: showMonthComparison && lastMonthProfit > 0
          ? `${periodProfit >= lastMonthProfit ? "+" : ""}${(((periodProfit - lastMonthProfit) / lastMonthProfit) * 100).toFixed(1)}%`
          : null,
        up: periodProfit >= lastMonthProfit,
        icon: "M13 7h8m0 0v8m0-8l-8 8-4-4-6 6",
        light: "bg-blue-50", text: "text-blue-600",
      },
      {
        title: `خالص منافع (${periodLabel})`,
        value: formatCurrency(netProfit),
        sub: `مجموعی ${formatCurrency(periodProfit)} − اخراجات ${formatCurrency(periodExpenses)} − نقصان ${formatCurrency(periodLosses)}`,
        change: showMonthComparison && lastMonthProfit > 0
          ? `${periodProfit >= lastMonthProfit ? "+" : ""}${(((periodProfit - lastMonthProfit) / lastMonthProfit) * 100).toFixed(1)}%`
          : null,
        up: netProfit >= 0,
        icon: "M13 7h8m0 0v8m0-8l-8 8-4-4-6 6",
        light: netProfit >= 0 ? "bg-emerald-50" : "bg-red-50", text: netProfit >= 0 ? "text-emerald-600" : "text-red-600",
      },
      {
        title: `اخراجات (${periodLabel})`,
        value: formatCurrency(periodExpenses),
        change: null, up: false,
        icon: "M17 9V7a4 4 0 00-8 0v2M5 9h14l1 12H4L5 9z",
        light: "bg-orange-50", text: "text-orange-600",
      },
      {
        title: `نقصانات (${periodLabel})`,
        value: formatCurrency(periodLosses),
        change: null, up: false,
        icon: "M12 9v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z",
        light: "bg-red-50", text: "text-red-600",
      },
      {
        title: "اسٹاک کی کل مالیت",
        value: formatCurrency(totalStockValue),
        sub: "لاگت قیمت کے حساب سے",
        change: null, up: true,
        icon: "M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4",
        light: "bg-cyan-50", text: "text-cyan-600",
      },
      {
        title: `ادھار وصول (${periodLabel})`,
        value: formatCurrency(totalUdaarReceived),
        change: null, up: true,
        icon: "M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z",
        light: "bg-violet-50", text: "text-violet-600",
      },
      {
        title: `ادھار (${periodLabel})`,
        value: formatCurrency(totalUdaar),
        change: periodUdaarInvoices.length > 0 ? `${periodUdaarInvoices.length} باقی` : null,
        up: false,
        icon: "M12 1v22M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6",
        light: "bg-red-50", text: "text-red-600",
      },
    ];
  }, [allInvoices, periodInvoices, products, currentYear, currentMonth, invoiceFinancials, dashboardPeriod, periodLabel, totalStockValue, customRange, expenses, losses]);

  /* ── Profit Calculation Function (Same as Reports) ── */
  const calcProfit = (inv, products = []) => {
    // Purana udhaar entries revenue mein aate hain lekin profit mein nahi.
    if (inv.isOldUdaar) return 0;
    // ✅ FIX: Use same logic as Reports for consistency
    // First try stored grossProfit
    let fullProfit;
    if (inv.grossProfit !== undefined && inv.grossProfit !== null && inv.grossProfit > 0) {
      fullProfit = inv.grossProfit;
    } else {
      // Fallback: calculate from items (same as Reports)
      const cost = (inv.items || []).reduce((s, item) => {
        let cp = item.costPrice;
        if ((cp === undefined || cp === null || cp === 0) && products.length > 0) {
          const prod = lookupProduct(item);
          if (prod) cp = prod.costPrice || prod.stockPrice || 0;
        }
        return s + ((cp || 0) * (item.qty || 0));
      }, 0);

      // Apply discount factor (same as Reports)
      const subtotal = inv.subtotal || inv.total || 0;
      const total = inv.total || 0;
      const discountFactor = subtotal > 0 ? (total / subtotal) : 1;
      const adjustedCost = cost * Math.min(discountFactor, 1);
      fullProfit = Math.max(0, total - adjustedCost);
    }

    // Udaar/partial invoices ka wasool na hua hissa profit mein count nahi karna
    // (same fix as backend Reports route / stats card calc above).
    if (inv.paymentStatus === "udaar" || inv.paymentStatus === "partial") {
      const total = inv.total || 0;
      if (total <= 0) return 0;
      const due = invoiceFinancials.get(inv.id)?.due ?? 0;
      const paid = Math.max(0, total - due);
      const paidRatio = Math.max(0, Math.min(1, paid / total));
      return fullProfit * paidRatio;
    }

    return fullProfit;
  };

  /* ── Monthly Revenue Data (current year) ── */
  const monthlyData = useMemo(() => {
    const data = URDU_MONTHS.map(m => ({ month: m, revenue: 0, profit: 0, expenses: 0, count: 0 }));
    allInvoices.forEach(inv => {
      const d = new Date(inv.createdAt);
      if (d.getFullYear() === currentYear) {
        const idx = d.getMonth();
        data[idx].revenue += inv.total || 0;
        data[idx].count += 1;
        // ✅ FIX: Use same calcProfit function as Reports
        const invProfit = calcProfit(inv, products);
        data[idx].profit += invProfit;
        data[idx].expenses += invProfit; // backward compat for ExpensesBarChart
      }
    });
    return data;
  }, [allInvoices, products, currentYear]);

  /* ── Category Pie Data (from real products) ── */
  const categoryData = useMemo(() => {
    const catMap = {};
    products.forEach(p => { catMap[p.category] = (catMap[p.category] || 0) + 1; });
    const total = products.length || 1;
    const colors = ["#1D6FDB","#38BDF8","#0EA5E9","#7DD3FC","#BAE6FD","#34d399","#f59e0b","#a78bfa"];
    return Object.entries(catMap)
      .sort((a, b) => b[1] - a[1])
      .map(([name, count], i) => ({
        name,
        value: Math.round((count / total) * 100),
        color: colors[i % colors.length],
      }));
  }, [products]);

  /* ── Top Products (from invoice items) ── */
  const topProducts = useMemo(() => {
    const map = {};
    allInvoices.forEach(inv => {
      (inv.items || []).forEach(item => {
        const key = item.name;
        if (!map[key]) {
          const prod = lookupProduct(item);
          map[key] = { name: item.name, category: prod?.category || "—", stock: prod?.currentStock ?? 0, sold: 0, revenue: 0 };
        }
        map[key].sold += item.qty || 0;
        map[key].revenue += item.lineTotal || 0;
      });
    });
    return Object.values(map)
      .sort((a, b) => b.revenue - a.revenue)
      .slice(0, 5);
  }, [allInvoices, productById, productByName]);


  /* ── Outstanding Balance Summary ── */
  const outstandingSummary = useMemo(() => {
    // customerId -> name lookup, taake purani invoices jin mein customerName
    // save nahi hua wo bhi sahi customer naam dikhayein (Unknown/Walk-in ki
    // jaga)
    const customerNameById = new Map(customers.map((c) => [String(c.id), c.name]));
    const resolveName = (inv) =>
      inv.customerName || (inv.customerId ? customerNameById.get(String(inv.customerId)) : null);

    // Single pass over invoices, reusing the pre-computed `due` per invoice
    // instead of re-filtering/re-reducing each invoice's payments 3 separate times.
    let totalReceivable = 0;
    const customersWithDueSet = new Set();
    const customerDue = {};
    allInvoices.forEach((inv) => {
      const due = invoiceFinancials.get(inv.id)?.due || 0;
      totalReceivable += due;
      if (inv.customerId && due > 0) {
        customersWithDueSet.add(inv.customerId);
        if (!customerDue[inv.customerId]) customerDue[inv.customerId] = { id: inv.customerId, name: resolveName(inv) || "Unknown", due: 0 };
        customerDue[inv.customerId].due += due;
      }
    });
    // Recent payments (last 4)
    const recentPayments = allInvoices
      .flatMap((inv) => (inv.payments || []).map((p) => ({ ...p, invoiceNumber: inv.invoiceNumber, customerName: resolveName(inv) })))
      .sort((a, b) => new Date(b.date) - new Date(a.date))
      .slice(0, 4);
    const topDebtors = Object.values(customerDue).sort((a, b) => b.due - a.due).slice(0, 4);
    return { totalReceivable, customersWithDue: customersWithDueSet.size, recentPayments, topDebtors };
  }, [allInvoices, invoiceFinancials, customers]);

  return (
    <div className="flex-1 overflow-y-auto scrollbar-hide px-4 sm:px-6 py-5 space-y-5">
      {/* Period Filter */}
      <div className="flex justify-end gap-2">
        <div className="flex items-center gap-1.5 bg-white border border-slate-200 rounded-xl p-1 shadow-sm w-fit">
          {DASHBOARD_PERIODS.map((opt) => (
            <button
              key={opt.key}
              onClick={() => setDashboardPeriod(opt.key)}
              className={`px-4 py-2 rounded-lg text-xs font-bold transition-all ${
                dashboardPeriod === opt.key
                  ? "bg-blue-600 text-white shadow-sm shadow-blue-200"
                  : "text-slate-500 hover:text-slate-700 hover:bg-slate-50"
              }`}
            >
              {opt.label}
            </button>
          ))}
        </div>
        <DateRangePicker value={customRange} onChange={handleCustomRangeChange} />
      </div>

      <StatsGrid cards={statsCards} />

      <div className="grid grid-cols-1 gap-4">
        <RevenueChart data={monthlyData} year={currentYear} />
      </div>


      <div className="pb-2">
        <TopProductsList data={topProducts} />
      </div>

      {/* Outstanding Balance Summary */}
      {outstandingSummary.totalReceivable > 0 && (
        <div className="pb-6">
          <h2 className="text-sm font-black text-slate-700 mb-3">Outstanding Balance Summary</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-4">
            <div className="bg-red-50 border border-red-100 rounded-2xl p-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-red-100 flex items-center justify-center">
                  <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#dc2626" strokeWidth="2" strokeLinecap="round">
                    <path d="M12 1v22M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6" />
                  </svg>
                </div>
                <div>
                  <p className="text-xs text-slate-500">Total Receivable</p>
                  <p className="text-xl font-black text-red-600">{formatCurrency(outstandingSummary.totalReceivable)}</p>
                </div>
              </div>
            </div>
            <div className="bg-amber-50 border border-amber-100 rounded-2xl p-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-amber-100 flex items-center justify-center">
                  <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#d97706" strokeWidth="2" strokeLinecap="round">
                    <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2" /><circle cx="9" cy="7" r="4" />
                  </svg>
                </div>
                <div>
                  <p className="text-xs text-slate-500">Customers with Due Balance</p>
                  <p className="text-xl font-black text-amber-700">{outstandingSummary.customersWithDue}</p>
                </div>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 xl:grid-cols-2 gap-4">
            {/* Top Debtors */}
            {outstandingSummary.topDebtors.length > 0 && (
              <div className="bg-white rounded-2xl border border-slate-100 p-4 shadow-sm">
                <h3 className="text-xs font-black text-slate-600 uppercase tracking-wider mb-3">Top Customers by Due Amount</h3>
                <div className="space-y-2">
                  {outstandingSummary.topDebtors.map((d, i) => (
                    <div key={i} className="flex items-center justify-between py-2 border-b border-slate-50 last:border-0">
                      <div className="flex items-center gap-2">
                        <span className="w-6 h-6 rounded-full bg-red-100 text-red-700 text-[10px] font-black flex items-center justify-center">{i + 1}</span>
                        <span className="text-sm font-semibold text-slate-700 truncate max-w-[140px]">{d.name}</span>
                      </div>
                      <span className="font-black text-red-600">{formatCurrency(d.due)}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Recent Payments */}
            {outstandingSummary.recentPayments.length > 0 && (
              <div className="bg-white rounded-2xl border border-slate-100 p-4 shadow-sm">
                <h3 className="text-xs font-black text-slate-600 uppercase tracking-wider mb-3">Recently Received Payments</h3>
                <div className="space-y-2">
                  {outstandingSummary.recentPayments.map((p, i) => (
                    <div key={i} className="flex items-center justify-between py-2 border-b border-slate-50 last:border-0">
                      <div>
                        <p className="text-sm font-semibold text-slate-700">{p.customerName || "Walk-in"}</p>
                        <p className="text-[10px] text-slate-400">Inv #{String(p.invoiceNumber || "").padStart(3, "0")} · {p.date ? new Date(p.date).toLocaleDateString("en-PK", { day: "2-digit", month: "short" }) : ""}</p>
                      </div>
                      <span className="font-black text-emerald-600">{formatCurrency(p.amount)}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
