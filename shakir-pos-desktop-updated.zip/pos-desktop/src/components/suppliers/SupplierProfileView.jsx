import { useState, useMemo, useEffect } from "react";
import DateRangePicker from "../common/DateRangePicker";
import ProductSelector from "../common/ProductSelector";
import { printPurchaseReceipt, getPurchasePaymentLines } from "./purchaseReceiptPrint";
import Pagination, { paginate } from "../common/Pagination";

const ROWS_PER_PAGE = 12;

// Invoice view mein payment ki qism ka label
const PAYMENT_KIND_LABEL = {
  advance: "Advance (khareedte waqt)",
  balance: "Pehle se jama advance balance se",
  payment: "Payment",
  legacy: "Purani payments (date/detail save nahi thi)",
};

function formatCurrency(val) {
  return "Rs " + Number(val || 0).toLocaleString("en-PK");
}
function formatDate(iso) {
  if (!iso) return "—";
  return new Date(iso).toLocaleDateString("en-PK", { day: "2-digit", month: "short", year: "numeric" });
}
function toISODate(d) {
  return d.toISOString().slice(0, 10);
}
let rowIdCounter = 0;
function newRowId() {
  rowIdCounter += 1;
  return `row_${rowIdCounter}`;
}

function emptyRow() {
  return { rowId: newRowId(), product: null, newProductName: "", purchasePrice: "", qty: "" };
}

// ── Maal Khareedna (Purchase Stock) ────────────────────────────────────
// Ek hi purchase mein jitne marzi products add kiye ja sakte hain — har
// row apna product (select ya naya naam), purchase price, aur quantity
// rakhti hai. Poore order ka ek hi advance diya jata hai — baaki
// (remaining) khud calculate ho jata hai. Save hote hi: supplier ki ledger
// update, har product ka stock badhta hai (ya naye products khud Products
// page mein ban jate hain).
//
// `existingPurchase` diya ho to yehi modal EDIT mode mein khul jata hai —
// items/qty/price badal sakte hain (advance edit yahan nahi hoti, wo alag
// "Payment" action se hoti hai).
function PurchaseModal({ products, onClose, onSave, existingPurchase, advanceAvailable = 0 }) {
  const isEdit = !!existingPurchase;
  const [rows, setRows] = useState(() =>
    isEdit
      ? existingPurchase.items.map((it) => ({
          rowId: newRowId(),
          product: it.productId ? (products.find((p) => String(p.id) === String(it.productId)) || { id: it.productId, name: it.productName }) : null,
          newProductName: it.productId ? "" : it.productName,
          purchasePrice: String(it.purchasePrice),
          qty: String(it.qty),
        }))
      : [emptyRow()]
  );
  const [advance, setAdvance] = useState(isEdit ? String(existingPurchase.advance) : "");
  const [date, setDate] = useState(isEdit ? existingPurchase.date.slice(0, 10) : toISODate(new Date()));
  const [error, setError] = useState("");
  const [saving, setSaving] = useState(false);

  const updateRow = (rowId, patch) => {
    setRows((prev) => prev.map((r) => (r.rowId === rowId ? { ...r, ...patch } : r)));
    setError("");
  };
  const addRow = () => setRows((prev) => [...prev, emptyRow()]);
  const removeRow = (rowId) => setRows((prev) => (prev.length > 1 ? prev.filter((r) => r.rowId !== rowId) : prev));

  const total = rows.reduce((s, r) => s + (Number(r.purchasePrice) || 0) * (Number(r.qty) || 0), 0);
  const advanceNum = Math.min(Number(advance) || 0, total);
  const autoFromBalance = !isEdit ? Math.min(advanceAvailable, Math.max(0, total - advanceNum)) : 0;
  const combinedAdvance = Math.min(advanceNum + autoFromBalance, total);
  const remaining = Math.max(0, total - combinedAdvance);

  const handleSubmit = async () => {
    for (const r of rows) {
      if (!r.product && !r.newProductName.trim()) { setError("Har row mein product select karein ya naya naam likhein"); return; }
      if (!Number(r.qty) || Number(r.qty) <= 0) { setError("Har product ki quantity 0 se zyada honi chahiye"); return; }
      if (!Number(r.purchasePrice) || Number(r.purchasePrice) <= 0) { setError("Har product ki purchase price 0 se zyada honi chahiye"); return; }
    }
    const items = rows.map((r) => ({
      productId: r.product?.id || null,
      productName: r.product?.name || r.newProductName.trim(),
      purchasePrice: Number(r.purchasePrice),
      qty: Number(r.qty),
    }));
    try {
      setSaving(true);
      if (isEdit) {
        await onSave({ items, date: new Date(date).toISOString() });
      } else {
        await onSave({ items, advance: advanceNum, date: new Date(date).toISOString() });
      }
      onClose();
    } catch (err) {
      setError(err.message || "Save nahi ho saka");
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm">
      <div className="bg-white rounded-2xl w-full max-w-2xl shadow-2xl max-h-[92vh] flex flex-col">
        <div className="flex items-center justify-between px-6 pt-5 pb-4 border-b border-slate-100 flex-shrink-0">
          <h2 className="font-bold text-slate-800 text-lg">
            {isEdit ? `Edit Purchase Invoice #${existingPurchase.invoiceNumber}` : "Maal Khareedein (Purchase)"}
          </h2>
          <button onClick={onClose} className="w-8 h-8 flex items-center justify-center rounded-xl hover:bg-slate-100 text-slate-400">
            <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round"><path d="M18 6 6 18M6 6l12 12" /></svg>
          </button>
        </div>
        <div className="px-6 py-5 space-y-4 overflow-y-auto scrollbar-hide">
          <div className="space-y-3">
            {rows.map((r, idx) => {
              const lineTotal = (Number(r.purchasePrice) || 0) * (Number(r.qty) || 0);
              return (
                <div key={r.rowId} className="bg-slate-50 rounded-xl p-3.5 border border-slate-100">
                  <div className="flex items-center justify-between mb-2">
                    <p className="text-xs font-bold text-slate-500">Product #{idx + 1}</p>
                    {rows.length > 1 && (
                      <button onClick={() => removeRow(r.rowId)} title="Row hataein"
                        className="w-6 h-6 flex items-center justify-center bg-red-50 hover:bg-red-100 text-red-500 rounded-lg transition-colors">
                        <svg xmlns="http://www.w3.org/2000/svg" width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round"><path d="M18 6 6 18M6 6l12 12" /></svg>
                      </button>
                    )}
                  </div>
                  <div className="space-y-2.5">
                    <ProductSelector
                      products={products} selectedProduct={r.product} onSelect={(p) => updateRow(r.rowId, { product: p })}
                      allowFreeText freeTextValue={r.newProductName} onFreeTextChange={(v) => updateRow(r.rowId, { newProductName: v })}
                      placeholder="Product search karein ya naya naam likhein..."
                    />
                    <div className="grid grid-cols-3 gap-2 items-end">
                      <div>
                        <label className="block text-[11px] font-semibold text-slate-500 mb-1">Purchase Price</label>
                        <input type="number" value={r.purchasePrice} onChange={(e) => updateRow(r.rowId, { purchasePrice: e.target.value })} placeholder="0"
                          className="w-full px-3 py-2 rounded-lg border border-slate-200 text-sm outline-none focus:border-blue-400 bg-white" />
                      </div>
                      <div>
                        <label className="block text-[11px] font-semibold text-slate-500 mb-1">Quantity</label>
                        <input type="number" value={r.qty} onChange={(e) => updateRow(r.rowId, { qty: e.target.value })} placeholder="0"
                          className="w-full px-3 py-2 rounded-lg border border-slate-200 text-sm outline-none focus:border-blue-400 bg-white" />
                      </div>
                      <div>
                        <p className="text-[11px] font-semibold text-slate-400 mb-1">Line Total</p>
                        <p className="text-sm font-bold text-slate-700 px-1 py-2">{formatCurrency(lineTotal)}</p>
                      </div>
                    </div>
                    {!r.product && r.newProductName.trim() && (
                      <p className="text-[11px] text-emerald-600 bg-emerald-50 rounded-lg px-2.5 py-1.5">
                        ✓ "{r.newProductName.trim()}" khud Products page mein naye product ki tarah add ho jayega.
                      </p>
                    )}
                  </div>
                </div>
              );
            })}
          </div>

          <button onClick={addRow} type="button"
            className="w-full flex items-center justify-center gap-2 py-2.5 rounded-xl border-2 border-dashed border-slate-200 hover:border-blue-300 hover:bg-blue-50/30 text-sm font-bold text-slate-500 hover:text-blue-600 transition-colors">
            <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round"><path d="M12 5v14M5 12h14" /></svg>
            Ek Aur Product Add Karein
          </button>

          <div className="grid grid-cols-2 gap-3">
            {!isEdit && (
              <div>
                <label className="block text-xs font-semibold text-slate-500 mb-1.5">Advance Diya (Rs) — poore order ka</label>
                <input type="number" value={advance} onChange={(e) => setAdvance(e.target.value)} placeholder="0"
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 text-sm outline-none focus:border-blue-400" />
                {advanceAvailable > 0 && (
                  <p className="text-[11px] text-emerald-600 mt-1">
                    Is supplier ka pehle se diya hua advance balance: <b>{formatCurrency(advanceAvailable)}</b> — yeh khud is purchase par lag jayega.
                  </p>
                )}
              </div>
            )}
            <div className={isEdit ? "col-span-2" : ""}>
              <label className="block text-xs font-semibold text-slate-500 mb-1.5">Date</label>
              <input type="date" value={date} onChange={(e) => setDate(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 text-sm outline-none focus:border-blue-400" />
            </div>
          </div>

          {isEdit && (
            <p className="text-[11px] text-slate-400 bg-slate-50 rounded-xl px-3.5 py-2.5">
              Advance/payment yahan edit nahi hoti — us ke liye "Payment" action use karein. Ye already diya gaya advance: <b>{formatCurrency(existingPurchase.advance)}</b>
            </p>
          )}

          {total > 0 && (
            <div className="grid grid-cols-3 gap-3 bg-slate-50 rounded-xl px-3.5 py-3">
              <div>
                <p className="text-[11px] text-slate-400">Total Bill</p>
                <p className="text-sm font-bold text-slate-700">{formatCurrency(total)}</p>
              </div>
              <div>
                <p className="text-[11px] text-slate-400">Advance {autoFromBalance > 0 ? "(+ balance)" : ""}</p>
                <p className="text-sm font-bold text-emerald-600">{formatCurrency(isEdit ? Math.min(existingPurchase.advance, total) : combinedAdvance)}</p>
                {!isEdit && autoFromBalance > 0 && (
                  <p className="text-[10px] text-slate-400">Isme Rs {formatCurrency(autoFromBalance).replace("Rs ", "")} advance balance se hai</p>
                )}
              </div>
              <div>
                <p className="text-[11px] text-slate-400">Baaki Rehta</p>
                <p className="text-sm font-bold text-red-600">{formatCurrency(isEdit ? Math.max(0, total - existingPurchase.advance) : remaining)}</p>
              </div>
            </div>
          )}
          {error && <p className="text-xs text-red-500">{error}</p>}
        </div>
        <div className="px-6 py-4 flex gap-3 border-t border-slate-100 flex-shrink-0">
          <button onClick={onClose} className="flex-1 py-2.5 rounded-xl border border-slate-200 text-sm font-semibold text-slate-600 hover:bg-slate-50">Cancel</button>
          <button onClick={handleSubmit} disabled={saving}
            className="flex-1 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white text-sm font-bold transition-colors">
            {saving ? "Saving..." : isEdit ? "Update Karein" : "Purchase Save Karein"}
          </button>
        </div>
      </div>
    </div>
  );
}

// ── Payment — ek specific purchase invoice ke against, ya supplier ki
// overall balance ke against (jo purani outstanding invoices mein khud
// FIFO distribute ho jata hai, aur un sab ka "baaki" update ho jata hai).
function PaymentModal({ outstandingPurchases, defaultTarget = "overall", onClose, onSave }) {
  const [target, setTarget] = useState(defaultTarget);
  const [amount, setAmount] = useState("");
  const [note, setNote] = useState("");
  const [date, setDate] = useState(toISODate(new Date()));
  const [error, setError] = useState("");
  const [saving, setSaving] = useState(false);

  const handleSubmit = async () => {
    const amt = Number(amount);
    if (!amt || amt <= 0) { setError("Sahi amount likhein"); return; }
    try {
      setSaving(true);
      await onSave({
        purchaseId: target === "overall" ? null : target,
        amount: amt,
        note,
        date: new Date(date).toISOString(),
      });
      onClose();
    } catch (err) {
      setError(err.message || "Payment save nahi ho saka");
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm">
      <div className="bg-white rounded-2xl w-full max-w-md shadow-2xl">
        <div className="flex items-center justify-between px-6 pt-5 pb-4 border-b border-slate-100">
          <h2 className="font-bold text-slate-800 text-lg">Payment Karein</h2>
          <button onClick={onClose} className="w-8 h-8 flex items-center justify-center rounded-xl hover:bg-slate-100 text-slate-400">
            <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round"><path d="M18 6 6 18M6 6l12 12" /></svg>
          </button>
        </div>
        <div className="px-6 py-5 space-y-4">
          <div>
            <label className="block text-xs font-semibold text-slate-500 mb-1.5">Kis Invoice Ke Against?</label>
            <select value={target} onChange={(e) => setTarget(e.target.value)}
              className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 text-sm outline-none focus:border-blue-400 bg-white">
              <option value="overall">Overall Balance (purani se nayi invoices)</option>
              {outstandingPurchases.map((p) => (
                <option key={p.id} value={p.id}>
                  Invoice #{p.invoiceNumber} — Baaki: {formatCurrency(p.remaining)}
                </option>
              ))}
            </select>
          </div>
          <div>
            <label className="block text-xs font-semibold text-slate-500 mb-1.5">Amount (Rs) *</label>
            <input type="number" value={amount} onChange={(e) => { setAmount(e.target.value); setError(""); }} placeholder="0"
              className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 text-sm outline-none focus:border-blue-400" />
          </div>
          <div>
            <label className="block text-xs font-semibold text-slate-500 mb-1.5">Date</label>
            <input type="date" value={date} onChange={(e) => setDate(e.target.value)}
              className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 text-sm outline-none focus:border-blue-400" />
          </div>
          <div>
            <label className="block text-xs font-semibold text-slate-500 mb-1.5">Note (optional)</label>
            <input type="text" value={note} onChange={(e) => setNote(e.target.value)} placeholder="e.g. Cash diya"
              className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 text-sm outline-none focus:border-blue-400" />
          </div>
          {error && <p className="text-xs text-red-500">{error}</p>}
        </div>
        <div className="px-6 pb-5 flex gap-3">
          <button onClick={onClose} className="flex-1 py-2.5 rounded-xl border border-slate-200 text-sm font-semibold text-slate-600 hover:bg-slate-50">Cancel</button>
          <button onClick={handleSubmit} disabled={saving}
            className="flex-1 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white text-sm font-bold transition-colors">
            {saving ? "Saving..." : "Payment Save Karein"}
          </button>
        </div>
      </div>
    </div>
  );
}

// ── Advance Payment — supplier ko future purchases ke liye pehle se paisa
// dena. Ye kisi specific invoice ke against nahi hoti; agar koi purani
// outstanding invoice ho to wo pehle settle hoti hai, jo bache wo agli
// purchase par khud lag jata hai.
function AdvanceModal({ onClose, onSave }) {
  const [amount, setAmount] = useState("");
  const [note, setNote] = useState("");
  const [date, setDate] = useState(toISODate(new Date()));
  const [error, setError] = useState("");
  const [saving, setSaving] = useState(false);

  const handleSubmit = async () => {
    const amt = Number(amount);
    if (!amt || amt <= 0) { setError("Sahi amount likhein"); return; }
    try {
      setSaving(true);
      await onSave({ amount: amt, note, date: new Date(date).toISOString() });
      onClose();
    } catch (err) {
      setError(err.message || "Advance save nahi ho saka");
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm">
      <div className="bg-white rounded-2xl w-full max-w-md shadow-2xl">
        <div className="flex items-center justify-between px-6 pt-5 pb-4 border-b border-slate-100">
          <h2 className="font-bold text-slate-800 text-lg">Advance Payment Dein</h2>
          <button onClick={onClose} className="w-8 h-8 flex items-center justify-center rounded-xl hover:bg-slate-100 text-slate-400">
            <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round"><path d="M18 6 6 18M6 6l12 12" /></svg>
          </button>
        </div>
        <div className="px-6 py-5 space-y-4">
          <p className="text-xs text-slate-400 bg-slate-50 rounded-xl px-3.5 py-2.5">
            Yeh amount is supplier ke advance balance mein jama ho jayega — agli purchase par khud-ba-khud istemal ho jayega.
          </p>
          <div>
            <label className="block text-xs font-semibold text-slate-500 mb-1.5">Amount (Rs) *</label>
            <input type="number" value={amount} onChange={(e) => { setAmount(e.target.value); setError(""); }} placeholder="0"
              className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 text-sm outline-none focus:border-blue-400" />
          </div>
          <div>
            <label className="block text-xs font-semibold text-slate-500 mb-1.5">Date</label>
            <input type="date" value={date} onChange={(e) => setDate(e.target.value)}
              className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 text-sm outline-none focus:border-blue-400" />
          </div>
          <div>
            <label className="block text-xs font-semibold text-slate-500 mb-1.5">Note (optional)</label>
            <input type="text" value={note} onChange={(e) => setNote(e.target.value)} placeholder="e.g. Advance cash diya"
              className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 text-sm outline-none focus:border-blue-400" />
          </div>
          {error && <p className="text-xs text-red-500">{error}</p>}
        </div>
        <div className="px-6 pb-5 flex gap-3">
          <button onClick={onClose} className="flex-1 py-2.5 rounded-xl border border-slate-200 text-sm font-semibold text-slate-600 hover:bg-slate-50">Cancel</button>
          <button onClick={handleSubmit} disabled={saving}
            className="flex-1 py-2.5 rounded-xl bg-amber-600 hover:bg-amber-700 disabled:opacity-50 text-white text-sm font-bold transition-colors">
            {saving ? "Saving..." : "Advance Save Karein"}
          </button>
        </div>
      </div>
    </div>
  );
}

// ── Review/View Purchase Invoice — read-only detail view (Edit ke bagair),
// eye icon se khulta hai jab sirf dekhna ho, badalna na ho.
function ViewPurchaseModal({ purchase, onClose }) {
  // Is invoice ki har payment — kab, kitni, kis tarah (advance/payment)
  const paymentLines = getPurchasePaymentLines(purchase);
  const paymentsTotal = paymentLines.reduce((sum, l) => sum + l.amount, 0);
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm">
      <div className="bg-white rounded-2xl w-full max-w-lg shadow-2xl max-h-[90vh] flex flex-col">
        <div className="flex items-center justify-between px-6 pt-5 pb-4 border-b border-slate-100 flex-shrink-0">
          <div>
            <h2 className="font-bold text-slate-800 text-lg">Invoice #{purchase.invoiceNumber}</h2>
            <p className="text-xs text-slate-400 mt-0.5">{formatDate(purchase.date)}</p>
          </div>
          <button onClick={onClose} className="w-8 h-8 flex items-center justify-center rounded-xl hover:bg-slate-100 text-slate-400">
            <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round"><path d="M18 6 6 18M6 6l12 12" /></svg>
          </button>
        </div>
        <div className="px-6 py-5 overflow-y-auto scrollbar-hide">
          <div className="bg-slate-50 rounded-xl border border-slate-100 overflow-hidden">
            <div className="grid grid-cols-12 gap-2 px-4 py-2.5 text-[11px] font-bold text-slate-400 uppercase tracking-wide border-b border-slate-200">
              <span className="col-span-6">Product</span>
              <span className="col-span-2 text-center">Qty</span>
              <span className="col-span-2 text-right">Price</span>
              <span className="col-span-2 text-right">Total</span>
            </div>
            {(purchase.items || []).map((it) => (
              <div key={it.id} className="grid grid-cols-12 gap-2 px-4 py-2.5 text-sm border-b border-slate-100 last:border-0">
                <span className="col-span-6 font-semibold text-slate-700 truncate">{it.productName}</span>
                <span className="col-span-2 text-center text-slate-500">{it.qty}</span>
                <span className="col-span-2 text-right text-slate-500">{it.purchasePrice.toLocaleString("en-PK")}</span>
                <span className="col-span-2 text-right font-bold text-slate-700">{it.lineTotal.toLocaleString("en-PK")}</span>
              </div>
            ))}
          </div>
          <div className="grid grid-cols-3 gap-3 mt-4">
            <div className="bg-slate-50 rounded-xl px-3.5 py-3">
              <p className="text-[11px] text-slate-400">Total Bill</p>
              <p className="text-sm font-bold text-slate-700">{formatCurrency(purchase.total)}</p>
            </div>
            <div className="bg-emerald-50 rounded-xl px-3.5 py-3">
              <p className="text-[11px] text-emerald-500">Advance/Paid</p>
              <p className="text-sm font-bold text-emerald-700">{formatCurrency(purchase.advance)}</p>
            </div>
            <div className="bg-red-50 rounded-xl px-3.5 py-3">
              <p className="text-[11px] text-red-400">Baaki Rehta</p>
              <p className="text-sm font-bold text-red-600">{formatCurrency(purchase.remaining)}</p>
            </div>
          </div>

          {/* Payment History — is invoice ki kab kab payment hui */}
          <div className="mt-5">
            <p className="text-xs font-bold text-slate-500 uppercase tracking-wide mb-2">Payment History</p>
            {paymentLines.length === 0 ? (
              <div className="bg-slate-50 rounded-xl border border-slate-100 px-4 py-4 text-center text-xs text-slate-400">
                Is invoice par abhi tak koi payment nahi hui.
              </div>
            ) : (
              <div className="bg-slate-50 rounded-xl border border-slate-100 overflow-hidden">
                <div className="grid grid-cols-12 gap-2 px-4 py-2.5 text-[11px] font-bold text-slate-400 uppercase tracking-wide border-b border-slate-200">
                  <span className="col-span-3">Date</span>
                  <span className="col-span-6">Detail</span>
                  <span className="col-span-3 text-right">Amount</span>
                </div>
                {paymentLines.map((l, i) => (
                  <div key={i} className="grid grid-cols-12 gap-2 px-4 py-2.5 text-sm border-b border-slate-100 last:border-0">
                    <span className="col-span-3 text-slate-600">{l.date ? formatDate(l.date) : "—"}</span>
                    <span className="col-span-6 text-slate-500 text-xs leading-5">
                      {PAYMENT_KIND_LABEL[l.kind] || "Payment"}{l.note ? ` · ${l.note}` : ""}
                    </span>
                    <span className="col-span-3 text-right font-bold text-emerald-600">{formatCurrency(l.amount)}</span>
                  </div>
                ))}
                <div className="grid grid-cols-12 gap-2 px-4 py-2.5 text-sm bg-emerald-50/60 border-t border-slate-200">
                  <span className="col-span-9 font-bold text-slate-600">Total Paid</span>
                  <span className="col-span-3 text-right font-black text-emerald-700">{formatCurrency(paymentsTotal)}</span>
                </div>
              </div>
            )}
          </div>
        </div>
        <div className="px-6 py-4 border-t border-slate-100 flex-shrink-0">
          <button onClick={onClose} className="w-full py-2.5 rounded-xl border border-slate-200 text-sm font-semibold text-slate-600 hover:bg-slate-50">Close</button>
        </div>
      </div>
    </div>
  );
}

export default function SupplierProfileView({
  supplier, transactions = [], onBack, onAddTransaction, onDeleteTransaction,
  products = [], onAddPurchase, onUpdatePurchase, onPayInvoice, onAddAdvance, purchases = [], fetchSupplierPurchases,
  invoiceSettings = {},
}) {
  const [tab, setTab] = useState("transactions"); // "transactions" | "purchases"
  const [showPurchaseModal, setShowPurchaseModal] = useState(false);
  const [editingPurchase, setEditingPurchase] = useState(null);
  const [viewingPurchase, setViewingPurchase] = useState(null);
  const [showPaymentModal, setShowPaymentModal] = useState(false);
  const [showAdvanceModal, setShowAdvanceModal] = useState(false);
  const [payingPurchase, setPayingPurchase] = useState(null);
  const [dateRange, setDateRange] = useState({ from: null, to: null });
  const [txnPage, setTxnPage] = useState(1);
  const [purchasePage, setPurchasePage] = useState(1);

  const handleDateRangeChange = (range) => {
    setDateRange(range);
    setTxnPage(1);
    setPurchasePage(1);
  };

  useEffect(() => {
    if (fetchSupplierPurchases) fetchSupplierPurchases(supplier.id);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [supplier.id]);

  const mine = useMemo(
    () => transactions.filter((t) => String(t.supplierId) === String(supplier.id)).sort((a, b) => new Date(b.date) - new Date(a.date)),
    [transactions, supplier.id]
  );

  const myPurchases = useMemo(
    () => purchases.filter((p) => String(p.supplierId) === String(supplier.id)).sort((a, b) => new Date(b.date) - new Date(a.date)),
    [purchases, supplier.id]
  );

  const filtered = useMemo(() => {
    // Transaction History sirf payments dikhata hai — "Maal Liya" (purchase)
    // entries ab Purchases tab mein apni invoice ke sath dikhti hain.
    const payments = mine.filter((t) => t.type === "payment");
    if (!dateRange.from || !dateRange.to) return payments;
    return payments.filter((t) => {
      const d = t.date.slice(0, 10);
      return d >= dateRange.from && d <= dateRange.to;
    });
  }, [mine, dateRange]);

  const filteredPurchases = useMemo(() => {
    if (!dateRange.from || !dateRange.to) return myPurchases;
    return myPurchases.filter((p) => {
      const d = p.date.slice(0, 10);
      return d >= dateRange.from && d <= dateRange.to;
    });
  }, [myPurchases, dateRange]);

  // Transaction History aur Purchases dono mein 12 entries per page
  const txnPaged = useMemo(() => paginate(filtered, txnPage, ROWS_PER_PAGE), [filtered, txnPage]);
  const purchasePaged = useMemo(() => paginate(filteredPurchases, purchasePage, ROWS_PER_PAGE), [filteredPurchases, purchasePage]);

  const totals = useMemo(() => {
    const totalPurchased = mine.filter((t) => t.type === "purchase").reduce((s, t) => s + t.amount, 0);
    const totalPaid = mine.filter((t) => t.type === "payment").reduce((s, t) => s + t.amount, 0);
    const balance = totalPurchased - totalPaid;
    // Jab paid, purchased se zyada ho jaye, wo faltu amount hi "advance
    // balance" hai — agli purchase par khud lag jayega.
    const advanceAvailable = balance < 0 ? -balance : 0;
    return { totalPurchased, totalPaid, balance, advanceAvailable };
  }, [mine]);

  const handlePurchase = async (form) => {
    await onAddPurchase(supplier.id, form);
    setShowPurchaseModal(false);
    setTab("purchases");
  };

  const handleUpdatePurchase = async (form) => {
    await onUpdatePurchase(supplier.id, editingPurchase.id, form);
    setEditingPurchase(null);
  };

  const outstandingPurchases = useMemo(
    () => myPurchases.filter((p) => p.remaining > 0).sort((a, b) => new Date(a.date) - new Date(b.date)),
    [myPurchases]
  );

  const handlePayment = async (form) => {
    await onPayInvoice(supplier.id, form);
    setShowPaymentModal(false);
    setPayingPurchase(null);
  };

  const handleAdvance = async (form) => {
    await onAddAdvance(supplier.id, form);
    setShowAdvanceModal(false);
  };

  return (
    <div className="flex-1 overflow-y-auto scrollbar-hide bg-slate-50/80">
      <div className="px-4 sm:px-6 pt-4 pb-2">
        <button onClick={onBack} className="flex items-center gap-1.5 text-sm font-semibold text-slate-500 hover:text-slate-700 mb-3">
          <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round"><path d="M15 18l-6-6 6-6" /></svg>
          Back to Suppliers
        </button>
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
          <div>
            <h2 className="text-lg font-black text-slate-800">{supplier.name}</h2>
            <p className="text-sm text-slate-400 mt-0.5">{supplier.phone || "No phone"} {supplier.city ? `· ${supplier.city}` : ""}</p>
          </div>
          <div className="flex items-center gap-2">
            <DateRangePicker value={dateRange} onChange={handleDateRangeChange} />
            <button onClick={() => setShowPurchaseModal(true)}
              className="flex items-center gap-2 px-4 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white text-sm font-bold rounded-xl shadow-md shadow-emerald-200">
              <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4" /></svg>
              Purchase Stock
            </button>
            <button onClick={() => { setPayingPurchase(null); setShowPaymentModal(true); }}
              className="flex items-center gap-2 px-4 py-2.5 bg-white border border-slate-200 hover:bg-slate-50 text-slate-700 text-sm font-bold rounded-xl shadow-sm transition-colors">
              <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><rect x="1" y="4" width="22" height="16" rx="2" ry="2" /><line x1="1" y1="10" x2="23" y2="10" /></svg>
              Payment
            </button>
            <button onClick={() => setShowAdvanceModal(true)}
              className="flex items-center gap-2 px-4 py-2.5 bg-white border border-slate-200 hover:bg-slate-50 text-amber-600 text-sm font-bold rounded-xl shadow-sm transition-colors">
              <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d="M12 1v22M17 5H9.5a3.5 3.5 0 000 7h5a3.5 3.5 0 010 7H6" /></svg>
              Advance Do
            </button>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 px-4 sm:px-6 pt-2 pb-2">
        <div className="bg-white rounded-2xl border border-slate-100 p-4">
          <p className="text-xs text-slate-400">Total Purchased</p>
          <p className="text-lg font-bold text-slate-800 mt-1">{formatCurrency(totals.totalPurchased)}</p>
        </div>
        <div className="bg-white rounded-2xl border border-slate-100 p-4">
          <p className="text-xs text-slate-400">Total Paid</p>
          <p className="text-lg font-bold text-emerald-600 mt-1">{formatCurrency(totals.totalPaid)}</p>
        </div>
        <div className="bg-white rounded-2xl border border-slate-100 p-4">
          <p className="text-xs text-slate-400">Baaki (Payable)</p>
          <p className={`text-lg font-bold mt-1 ${totals.balance > 0 ? "text-red-600" : "text-slate-800"}`}>{formatCurrency(Math.max(0, totals.balance))}</p>
        </div>
        <div className="bg-white rounded-2xl border border-slate-100 p-4">
          <p className="text-xs text-slate-400">Advance Balance</p>
          <p className={`text-lg font-bold mt-1 ${totals.advanceAvailable > 0 ? "text-amber-600" : "text-slate-800"}`}>{formatCurrency(totals.advanceAvailable)}</p>
        </div>
      </div>

      {/* Tabs — Transaction History alag, Purchases (receipts) alag side par */}
      <div className="px-4 sm:px-6 pt-2">
        <div className="flex items-center gap-1.5 bg-white border border-slate-200 rounded-xl p-1 shadow-sm w-fit">
          <button onClick={() => setTab("transactions")}
            className={`px-4 py-2 rounded-lg text-xs font-bold transition-all ${tab === "transactions" ? "bg-blue-600 text-white shadow-sm shadow-blue-200" : "text-slate-500 hover:text-slate-700 hover:bg-slate-50"}`}>
            Transaction History
          </button>
          <button onClick={() => setTab("purchases")}
            className={`px-4 py-2 rounded-lg text-xs font-bold transition-all ${tab === "purchases" ? "bg-blue-600 text-white shadow-sm shadow-blue-200" : "text-slate-500 hover:text-slate-700 hover:bg-slate-50"}`}>
            Purchases ({myPurchases.length})
          </button>
        </div>
      </div>

      {tab === "transactions" ? (
        <div className="px-4 sm:px-6 pt-3 pb-6">
          <div className="bg-white rounded-2xl border border-slate-100 overflow-hidden shadow-sm">
            <div className="px-5 py-3.5 border-b border-slate-100 bg-slate-50/70">
              <p className="text-xs font-bold text-slate-500 uppercase tracking-wider">Transaction History</p>
            </div>
            {filtered.length === 0 ? (
              <div className="p-10 text-center text-slate-400 text-sm">Koi entry nahi mili.</div>
            ) : (
              <div className="divide-y divide-slate-50">
                {txnPaged.pageItems.map((t) => (
                  <div key={t.id} className="flex items-center justify-between px-5 py-3.5 hover:bg-slate-50/50">
                    <div className="flex items-center gap-3">
                      <div className="w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0 bg-emerald-50 text-emerald-600">
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round"><path d="M12 5v14M5 12l7 7 7-7" /></svg>
                      </div>
                      <div>
                        <p className="text-sm font-semibold text-slate-700">Payment Diya</p>
                        <p className="text-xs text-slate-400">{formatDate(t.date)}{t.description ? ` · ${t.description}` : ""}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      <p className="text-sm font-bold text-emerald-600">−{formatCurrency(t.amount)}</p>
                      <button onClick={() => onDeleteTransaction(supplier.id, t.id)} title="Delete"
                        className="w-7 h-7 flex items-center justify-center bg-red-50 hover:bg-red-100 text-red-500 rounded-lg transition-colors">
                        <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round"><polyline points="3 6 5 6 21 6" /><path d="M19 6v14a2 2 0 01-2 2H7a2 2 0 01-2-2V6" /></svg>
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
          <Pagination total={filtered.length} page={txnPaged.currentPage} pageSize={ROWS_PER_PAGE} onPageChange={setTxnPage} />
        </div>
      ) : (
        <div className="px-4 sm:px-6 pt-3 pb-6">
          <div className="bg-white rounded-2xl border border-slate-100 overflow-hidden shadow-sm">
            <div className="px-5 py-3.5 border-b border-slate-100 bg-slate-50/70">
              <p className="text-xs font-bold text-slate-500 uppercase tracking-wider">Purchase Receipts</p>
            </div>
            {filteredPurchases.length === 0 ? (
              <div className="p-10 text-center text-slate-400 text-sm">Abhi koi purchase receipt nahi hai. "Purchase Stock" se maal khareedein.</div>
            ) : (
              <div className="divide-y divide-slate-50">
                {purchasePaged.pageItems.map((p) => (
                  <div key={p.id} className="flex items-center justify-between px-5 py-3.5 hover:bg-slate-50/50 gap-3">
                    <div className="flex items-center gap-3 min-w-0">
                      <div className="w-9 h-9 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center flex-shrink-0">
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4" /></svg>
                      </div>
                      <div className="min-w-0">
                        <p className="text-sm font-semibold text-slate-700 truncate">
                          <span className="text-blue-600 font-bold">#{p.invoiceNumber}</span> · {(p.items || []).map((it) => it.productName).join(", ")}
                        </p>
                        <p className="text-xs text-slate-400">{formatDate(p.date)} · {(p.items || []).length} product{(p.items || []).length !== 1 ? "s" : ""}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2 flex-shrink-0">
                      <div className="text-right hidden sm:block mr-1">
                        <p className="text-sm font-bold text-slate-800">{formatCurrency(p.total)}</p>
                        <p className={`text-xs font-semibold ${p.remaining > 0 ? "text-red-500" : "text-emerald-600"}`}>
                          {p.remaining > 0 ? `Baaki: ${formatCurrency(p.remaining)}` : "Fully Paid"}
                        </p>
                      </div>
                      {p.remaining > 0 && (
                        <button onClick={() => { setPayingPurchase(p); setShowPaymentModal(true); }} title="Isi invoice ke against payment karein"
                          className="flex items-center gap-1.5 px-3 py-2 bg-emerald-50 hover:bg-emerald-100 text-emerald-600 rounded-lg text-xs font-bold transition-colors">
                          <svg xmlns="http://www.w3.org/2000/svg" width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round"><rect x="1" y="4" width="22" height="16" rx="2" ry="2" /><line x1="1" y1="10" x2="23" y2="10" /></svg>
                          Pay
                        </button>
                      )}
                      <button onClick={() => setViewingPurchase(p)} title="Invoice Review Karein"
                        className="flex items-center justify-center w-8 h-8 bg-slate-50 hover:bg-slate-100 text-slate-500 rounded-lg transition-colors">
                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z" /><circle cx="12" cy="12" r="3" /></svg>
                      </button>
                      <button onClick={() => setEditingPurchase(p)} title="Edit Invoice"
                        className="flex items-center gap-1.5 px-3 py-2 bg-amber-50 hover:bg-amber-100 text-amber-600 rounded-lg text-xs font-bold transition-colors">
                        <svg xmlns="http://www.w3.org/2000/svg" width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7" /><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z" /></svg>
                        Edit
                      </button>
                      <button onClick={() => printPurchaseReceipt(p, supplier, "Shakir POS", invoiceSettings)} title="Receipt Print Karein"
                        className="flex items-center gap-1.5 px-3 py-2 bg-blue-50 hover:bg-blue-100 text-blue-600 rounded-lg text-xs font-bold transition-colors">
                        <svg xmlns="http://www.w3.org/2000/svg" width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round"><polyline points="6 9 6 2 18 2 18 9" /><path d="M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2" /><rect x="6" y="14" width="12" height="8" /></svg>
                        Print
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
          <Pagination total={filteredPurchases.length} page={purchasePaged.currentPage} pageSize={ROWS_PER_PAGE} onPageChange={setPurchasePage} />
        </div>
      )}

      {showPurchaseModal && <PurchaseModal products={products} onClose={() => setShowPurchaseModal(false)} onSave={handlePurchase} advanceAvailable={totals.advanceAvailable} />}
      {editingPurchase && (
        <PurchaseModal
          products={products}
          existingPurchase={editingPurchase}
          onClose={() => setEditingPurchase(null)}
          onSave={handleUpdatePurchase}
        />
      )}
      {viewingPurchase && <ViewPurchaseModal purchase={viewingPurchase} onClose={() => setViewingPurchase(null)} />}
      {showPaymentModal && (
        <PaymentModal
          outstandingPurchases={payingPurchase ? [payingPurchase] : outstandingPurchases}
          defaultTarget={payingPurchase ? payingPurchase.id : "overall"}
          onClose={() => { setShowPaymentModal(false); setPayingPurchase(null); }}
          onSave={handlePayment}
        />
      )}
      {showAdvanceModal && (
        <AdvanceModal
          onClose={() => setShowAdvanceModal(false)}
          onSave={handleAdvance}
        />
      )}
    </div>
  );
}
