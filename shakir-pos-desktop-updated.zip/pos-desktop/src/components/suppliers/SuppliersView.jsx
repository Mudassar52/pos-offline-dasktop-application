import { useState, useMemo } from "react";
import DateRangePicker from "../common/DateRangePicker";
import SupplierProfileView from "./SupplierProfileView";

function formatCurrency(val) {
  return "Rs " + Number(val || 0).toLocaleString("en-PK");
}

function SupplierModal({ supplier, onClose, onSave }) {
  const [form, setForm] = useState(
    supplier ? { name: supplier.name, phone: supplier.phone || "", city: supplier.city || "", notes: supplier.notes || "" }
             : { name: "", phone: "", city: "", notes: "" }
  );
  const [errors, setErrors] = useState({});

  const handleSubmit = () => {
    const e = {};
    if (!form.name.trim()) e.name = "Naam zaroori hai";
    if (Object.keys(e).length) { setErrors(e); return; }
    onSave({ ...form });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm">
      <div className="bg-white rounded-2xl w-full max-w-md shadow-2xl">
        <div className="flex items-center justify-between px-6 pt-5 pb-4 border-b border-slate-100">
          <h2 className="font-bold text-slate-800 text-lg">{supplier ? "Edit Supplier" : "New Supplier"}</h2>
          <button onClick={onClose} className="w-8 h-8 flex items-center justify-center rounded-xl hover:bg-slate-100 text-slate-400">
            <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round"><path d="M18 6 6 18M6 6l12 12" /></svg>
          </button>
        </div>
        <div className="px-6 py-5 space-y-4">
          {[
            { key: "name", label: "Supplier Name *", placeholder: "e.g. Al-Rehman Traders" },
            { key: "phone", label: "Phone", placeholder: "0300-1234567" },
            { key: "city", label: "City", placeholder: "Faisalabad, Lahore..." },
            { key: "notes", label: "Notes", placeholder: "Optional" },
          ].map(({ key, label, placeholder }) => (
            <div key={key}>
              <label className="block text-xs font-semibold text-slate-500 mb-1.5">{label}</label>
              <input
                type="text" value={form[key]} placeholder={placeholder}
                onChange={(e) => { setForm((f) => ({ ...f, [key]: e.target.value })); setErrors((er) => ({ ...er, [key]: "" })); }}
                className={`w-full px-3.5 py-2.5 rounded-xl border text-sm outline-none transition-colors ${errors[key] ? "border-red-400 bg-red-50" : "border-slate-200 focus:border-blue-400 bg-white"}`}
              />
              {errors[key] && <p className="text-xs text-red-500 mt-1">{errors[key]}</p>}
            </div>
          ))}
        </div>
        <div className="px-6 pb-5 flex gap-3">
          <button onClick={onClose} className="flex-1 py-2.5 rounded-xl border border-slate-200 text-sm font-semibold text-slate-600 hover:bg-slate-50">Cancel</button>
          <button onClick={handleSubmit} className="flex-1 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-sm font-bold transition-colors">
            {supplier ? "Update" : "Add Supplier"}
          </button>
        </div>
      </div>
    </div>
  );
}

function DeleteModal({ supplier, onConfirm, onClose }) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm">
      <div className="bg-white rounded-2xl w-full max-w-sm shadow-2xl p-6">
        <div className="w-12 h-12 mx-auto mb-4 rounded-2xl bg-red-50 flex items-center justify-center">
          <svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#ef4444" strokeWidth="2" strokeLinecap="round"><polyline points="3 6 5 6 21 6" /><path d="M19 6v14a2 2 0 01-2 2H7a2 2 0 01-2-2V6m3 0V4a2 2 0 012-2h4a2 2 0 012 2v2" /></svg>
        </div>
        <h3 className="text-center font-bold text-slate-800 mb-1">Delete Supplier?</h3>
        <p className="text-center text-sm text-slate-500 mb-5"><span className="font-bold text-slate-700">{supplier.name}</span> ka poora record (ledger samet) mit jayega.</p>
        <div className="flex gap-3">
          <button onClick={onClose} className="flex-1 py-2.5 rounded-xl border border-slate-200 text-sm font-semibold text-slate-600 hover:bg-slate-50">Cancel</button>
          <button onClick={onConfirm} className="flex-1 py-2.5 rounded-xl bg-red-500 hover:bg-red-600 text-white text-sm font-bold transition-colors">Delete</button>
        </div>
      </div>
    </div>
  );
}

export default function SuppliersView({
  suppliers = [], transactions = [],
  addSupplier, updateSupplier, deleteSupplier,
  addSupplierTransaction, deleteSupplierTransaction, addSupplierPurchase,
  updateSupplierPurchase, paySupplierInvoice, addSupplierAdvance,
  purchases = [], fetchSupplierPurchases,
  products = [],
  invoiceSettings = {},
}) {
  const [search, setSearch] = useState("");
  const [dateRange, setDateRange] = useState({ from: null, to: null });
  const [showModal, setShowModal] = useState(false);
  const [editingSupplier, setEditingSupplier] = useState(null);
  const [deletingSupplier, setDeletingSupplier] = useState(null);
  const [profileSupplier, setProfileSupplier] = useState(null);

  const txnBySupplier = useMemo(() => {
    const map = new Map();
    const inRange = (t) => {
      if (!dateRange.from || !dateRange.to) return true;
      const d = t.date.slice(0, 10);
      return d >= dateRange.from && d <= dateRange.to;
    };
    transactions.filter(inRange).forEach((t) => {
      const key = String(t.supplierId);
      if (!map.has(key)) map.set(key, { purchased: 0, paid: 0 });
      const entry = map.get(key);
      if (t.type === "purchase") entry.purchased += t.amount;
      else entry.paid += t.amount;
    });
    return map;
  }, [transactions, dateRange]);

  const rows = useMemo(() => {
    const q = search.trim().toLowerCase();
    return suppliers
      .map((s) => {
        const totals = txnBySupplier.get(String(s.id)) || { purchased: 0, paid: 0 };
        return { ...s, totalPurchased: totals.purchased, totalPaid: totals.paid, balance: totals.purchased - totals.paid };
      })
      .filter((s) => !q || s.name.toLowerCase().includes(q) || (s.phone || "").includes(q) || (s.city || "").toLowerCase().includes(q));
  }, [suppliers, txnBySupplier, search]);

  const stats = useMemo(() => {
    const totalPurchased = rows.reduce((s, r) => s + r.totalPurchased, 0);
    const totalPaid = rows.reduce((s, r) => s + r.totalPaid, 0);
    const totalPayable = rows.reduce((s, r) => s + Math.max(0, r.balance), 0);
    return { count: suppliers.length, totalPurchased, totalPaid, totalPayable };
  }, [rows, suppliers.length]);

  const handleSave = async (form) => {
    if (editingSupplier) {
      await updateSupplier(editingSupplier.id, form);
      setEditingSupplier(null);
    } else {
      await addSupplier(form);
      setShowModal(false);
    }
  };

  const handleDeleteConfirm = async () => {
    await deleteSupplier(deletingSupplier.id);
    setDeletingSupplier(null);
  };

  if (profileSupplier) {
    const fresh = suppliers.find((s) => String(s.id) === String(profileSupplier.id)) || profileSupplier;
    return (
      <SupplierProfileView
        supplier={fresh}
        transactions={transactions}
        onBack={() => setProfileSupplier(null)}
        onAddTransaction={addSupplierTransaction}
        onDeleteTransaction={deleteSupplierTransaction}
        onAddPurchase={addSupplierPurchase}
        onUpdatePurchase={updateSupplierPurchase}
        onPayInvoice={paySupplierInvoice}
        onAddAdvance={addSupplierAdvance}
        purchases={purchases}
        fetchSupplierPurchases={fetchSupplierPurchases}
        products={products}
        invoiceSettings={invoiceSettings}
      />
    );
  }

  return (
    <div className="flex-1 overflow-y-auto scrollbar-hide bg-slate-50/80">
      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 px-4 sm:px-6 pt-4 pb-2">
        <div className="bg-white rounded-2xl border border-slate-100 p-4">
          <p className="text-xs text-slate-400">Total Suppliers</p>
          <p className="text-lg font-bold text-slate-800 mt-1">{stats.count}</p>
        </div>
        <div className="bg-white rounded-2xl border border-slate-100 p-4">
          <p className="text-xs text-slate-400">Total Purchased</p>
          <p className="text-lg font-bold text-blue-600 mt-1">{formatCurrency(stats.totalPurchased)}</p>
        </div>
        <div className="bg-white rounded-2xl border border-slate-100 p-4">
          <p className="text-xs text-slate-400">Total Paid</p>
          <p className="text-lg font-bold text-emerald-600 mt-1">{formatCurrency(stats.totalPaid)}</p>
        </div>
        <div className="bg-white rounded-2xl border border-slate-100 p-4">
          <p className="text-xs text-slate-400">Total Payable</p>
          <p className="text-lg font-bold text-red-600 mt-1">{formatCurrency(stats.totalPayable)}</p>
        </div>
      </div>

      {/* Search + filters */}
      <div className="px-4 sm:px-6 py-3">
        <div className="flex flex-col sm:flex-row items-stretch gap-3">
          <div className="flex flex-1 items-center gap-2 bg-white border border-slate-200 rounded-xl shadow-sm px-3 py-2.5">
            <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="#94A3B8" strokeWidth="2" strokeLinecap="round" className="flex-shrink-0">
              <circle cx="11" cy="11" r="8" /><path d="m21 21-4.35-4.35" />
            </svg>
            <input type="text" value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search by name, phone or city..."
              className="flex-1 bg-transparent text-sm text-slate-700 outline-none placeholder:text-slate-400" />
          </div>
          <DateRangePicker value={dateRange} onChange={setDateRange} />
          <button onClick={() => setShowModal(true)}
            className="flex items-center justify-center gap-2 px-5 py-2.5 bg-blue-600 hover:bg-blue-700 text-white text-sm font-bold rounded-xl shadow-md shadow-blue-200 transition-colors flex-shrink-0">
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round"><path d="M12 5v14M5 12h14" /></svg>
            New Supplier
          </button>
        </div>
      </div>

      {/* List */}
      <div className="px-4 sm:px-6 pb-6">
        {suppliers.length === 0 ? (
          <div className="bg-white rounded-2xl border border-slate-100 p-16 text-center">
            <div className="w-16 h-16 mx-auto mb-4 rounded-2xl bg-blue-50 flex items-center justify-center">
              <svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#2563eb" strokeWidth="1.5" strokeLinecap="round"><path d="M20.42 4.58a5.4 5.4 0 0 0-7.65 0l-.77.78-.77-.78a5.4 5.4 0 0 0-7.65 7.65l8.42 8.42 8.42-8.42a5.4 5.4 0 0 0 0-7.65z" /></svg>
            </div>
            <h3 className="font-bold text-slate-700 mb-1">Koi supplier nahi hai</h3>
            <p className="text-sm text-slate-400 mb-5">Pehla supplier add karein jin se aap maal khareedte hain</p>
            <button onClick={() => setShowModal(true)} className="inline-flex items-center gap-2 px-5 py-2.5 bg-blue-600 text-white text-sm font-bold rounded-xl shadow-md shadow-blue-200">
              <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round"><path d="M12 5v14M5 12h14" /></svg>
              Add Supplier
            </button>
          </div>
        ) : rows.length === 0 ? (
          <div className="bg-white rounded-2xl border border-slate-100 p-12 text-center">
            <p className="text-slate-500">No suppliers match your search.</p>
          </div>
        ) : (
          <div className="bg-white rounded-2xl border border-slate-100 overflow-hidden shadow-sm">
            <table className="w-full">
              <thead>
                <tr className="border-b border-slate-100 bg-slate-50/70">
                  <th className="px-5 py-3.5 text-left text-[11px] font-bold text-slate-400 uppercase tracking-wider">Supplier</th>
                  <th className="px-5 py-3.5 text-left text-[11px] font-bold text-slate-400 uppercase tracking-wider hidden sm:table-cell">Phone</th>
                  <th className="px-5 py-3.5 text-right text-[11px] font-bold text-slate-400 uppercase tracking-wider">Purchased</th>
                  <th className="px-5 py-3.5 text-right text-[11px] font-bold text-slate-400 uppercase tracking-wider">Paid</th>
                  <th className="px-5 py-3.5 text-right text-[11px] font-bold text-slate-400 uppercase tracking-wider">Payable</th>
                  <th className="px-5 py-3.5 text-center text-[11px] font-bold text-slate-400 uppercase tracking-wider">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-50">
                {rows.map((s) => (
                  <tr key={s.id} className="hover:bg-blue-50/40 transition-colors cursor-pointer group" onClick={() => setProfileSupplier(s)}>
                    <td className="px-5 py-4">
                      <p className="font-semibold text-slate-800 text-sm group-hover:text-blue-700">{s.name}</p>
                      {s.city && <p className="text-xs text-slate-400">{s.city}</p>}
                    </td>
                    <td className="px-5 py-4 text-sm text-slate-600 hidden sm:table-cell">{s.phone || "—"}</td>
                    <td className="px-5 py-4 text-sm text-right font-medium text-slate-700">{formatCurrency(s.totalPurchased)}</td>
                    <td className="px-5 py-4 text-sm text-right font-medium text-emerald-600">{formatCurrency(s.totalPaid)}</td>
                    <td className={`px-5 py-4 text-sm text-right font-bold ${s.balance > 0 ? "text-red-600" : "text-slate-400"}`}>{formatCurrency(s.balance)}</td>
                    <td className="px-5 py-4">
                      <div className="flex items-center justify-center gap-1.5">
                        <button onClick={(e) => { e.stopPropagation(); setEditingSupplier(s); }} title="Edit"
                          className="w-8 h-8 flex items-center justify-center bg-amber-50 hover:bg-amber-100 text-amber-600 rounded-lg transition-colors">
                          <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7" /><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z" /></svg>
                        </button>
                        <button onClick={(e) => { e.stopPropagation(); setDeletingSupplier(s); }} title="Delete"
                          className="w-8 h-8 flex items-center justify-center bg-red-50 hover:bg-red-100 text-red-500 rounded-lg transition-colors">
                          <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round"><polyline points="3 6 5 6 21 6" /><path d="M19 6v14a2 2 0 01-2 2H7a2 2 0 01-2-2V6m3 0V4a2 2 0 012-2h4a2 2 0 012 2v2" /></svg>
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {(showModal || editingSupplier) && (
        <SupplierModal supplier={editingSupplier} onClose={() => { setShowModal(false); setEditingSupplier(null); }} onSave={handleSave} />
      )}
      {deletingSupplier && (
        <DeleteModal supplier={deletingSupplier} onConfirm={handleDeleteConfirm} onClose={() => setDeletingSupplier(null)} />
      )}
    </div>
  );
}
