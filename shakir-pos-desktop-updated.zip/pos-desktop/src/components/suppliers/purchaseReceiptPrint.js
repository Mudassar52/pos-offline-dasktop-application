// ── Purchase Receipt — thermal (80mm) print, Urdu labels ──────────────────
// Supplier se maal khareedte waqt jo purchase batch banta hai, uski
// receipt bilkul sale invoice ki tarah print hoti hai:
//   • Upar ka header (heading, logo/dukaan ka naam, address, dono naam aur
//     phone) Settings → Invoice Settings se aata hai — sale invoice wala hi.
//   • Items ka border wala table.
//   • Is invoice ki har payment (kab, kitni) ka alag table.

const UF = `'Noto Nastaliq Urdu','Jameel Noori Nastaleeq','Arial Unicode MS',sans-serif`;
const URDU_MONTHS = ["جنوری", "فروری", "مارچ", "اپریل", "مئی", "جون", "جولائی", "اگست", "ستمبر", "اکتوبر", "نومبر", "دسمبر"];

function formatCurrency(val) {
  return "Rs " + Number(val || 0).toLocaleString("en-PK");
}

function formatDateUrdu(iso) {
  const d = new Date(iso);
  const day = String(d.getDate()).padStart(2, "0");
  return `${day} ${URDU_MONTHS[d.getMonth()]} ${d.getFullYear()}`;
}

function formatTimeUrdu(iso) {
  const d = new Date(iso);
  let hours = d.getHours();
  const minutes = String(d.getMinutes()).padStart(2, "0");
  const ampm = hours >= 12 ? "شام" : "صبح";
  hours = hours % 12 || 12;
  return `${String(hours).padStart(2, "0")}:${minutes} ${ampm}`;
}

function escapeHtml(str) {
  return String(str ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
}

// ── Invoice ki payment history (view modal aur print dono isi se lete hain) ──
// Har line: { kind, date, amount, note }
//   kind = 'advance' | 'balance' | 'payment' | 'legacy'
// 'legacy' ek "hisaab barabar karne wali" line hai: purane data mein jo
// payments kisi invoice ke sath tarikh-wise save nahi hui thi (jaise
// "Overall" payment jo kai invoices mein baant di gayi), unka total
// invoice ke "ada shuda" se kam reh jata hai — woh farq yahan ek line
// ban kar dikhta hai taake table ka total hamesha sahi rahe.
export function getPurchasePaymentLines(purchase) {
  const lines = (purchase.payments || [])
    .map((p) => ({ kind: p.kind || "payment", date: p.date, amount: Number(p.amount) || 0, note: p.note || "" }))
    .sort((a, b) => new Date(a.date) - new Date(b.date));
  const recorded = lines.reduce((s, l) => s + l.amount, 0);
  const paid = Number(purchase.advance) || 0;
  const gap = paid - recorded;
  if (gap > 0.0001) {
    lines.unshift({ kind: "legacy", date: null, amount: gap, note: "" });
  }
  return lines;
}

const PRINT_KIND_LABEL = {
  advance: "ایڈوانس",
  balance: "جمع ایڈوانس سے",
  payment: "ادائیگی",
  legacy: "سابقہ ادائیگیاں",
};

function getReceiptHTML(purchase, supplier, appName, invoiceSettings = {}) {
  const s = invoiceSettings || {};
  const bf = {
    name: s.ownerName || "",
    business: s.businessName || "",
    phone: s.phone || "",
    name2: s.ownerName2 || "",
    phone2: s.phone2 || "",
    address: s.address || "",
    logo: s.logo && s.logo !== "__local__" ? s.logo : "",
  };
  const heading = s.invoiceHeading || "";
  const displayName = bf.business || bf.name || appName || "Shakir POS";

  const cell = (extra = "") => `border:0.5px solid #000;padding:5px 1px;font-size:9px;font-weight:900;color:#000;text-align:center;vertical-align:middle;${extra}`;
  const th = `border:0.5px solid #000;padding:2px 1px;font-size:10px;font-family:${UF};text-align:center;font-weight:900;color:#000;`;

  const items = purchase.items || [];
  const totalQty = items.reduce((sum, it) => sum + (Number(it.qty) || 0), 0);

  const itemRows = items.map((it, i) => `
      <tr>
        <td style="${cell()}">${i + 1}</td>
        <td style="${cell(`padding:5px 2px;font-size:10px;font-family:${UF};direction:rtl;text-align:right;word-break:break-word;line-height:1.2;`)}">${escapeHtml(it.productName)}</td>
        <td style="${cell()}">${it.qty}</td>
        <td style="${cell()}">${formatCurrency(it.purchasePrice)}</td>
        <td style="${cell()}">${formatCurrency(it.lineTotal)}</td>
      </tr>`).join("");

  const infoRow = (label, valueHtml) => `
      <tr>
        <td colspan="2" style="font-size:13px;padding:2px 3px;font-weight:900;color:#000;direction:rtl;text-align:right;"><span style="font-family:${UF};">${label} </span>${valueHtml}</td>
      </tr>`;

  const sumRow = (label, value, extra = "") => `
      <tr style="${extra}">
        <td style="font-size:13px;padding:3px 2px;font-family:${UF};direction:rtl;text-align:right;font-weight:900;color:#000;width:55%;">${label}</td>
        <td style="font-size:13px;padding:3px 2px;direction:ltr;text-align:left;font-weight:900;color:#000;width:45%;">${value}</td>
      </tr>`;

  // ── Payments table ──
  const payLines = getPurchasePaymentLines(purchase);
  const payRows = payLines.map((l, i) => `
      <tr>
        <td style="${cell()}">${i + 1}</td>
        <td style="${cell(`font-family:${UF};`)}">${l.date ? formatDateUrdu(l.date) : "—"}</td>
        <td style="${cell(`padding:5px 2px;font-size:10px;font-family:${UF};direction:rtl;text-align:right;word-break:break-word;line-height:1.2;`)}">${PRINT_KIND_LABEL[l.kind] || "ادائیگی"}${l.note ? ` — ${escapeHtml(l.note)}` : ""}</td>
        <td style="${cell()}">${formatCurrency(l.amount)}</td>
      </tr>`).join("");
  const paymentsTotal = payLines.reduce((sum, l) => sum + l.amount, 0);

  const paymentsSection = payLines.length > 0 ? `
      <div style="font-size:12px;font-weight:900;color:#000;font-family:${UF};text-align:center;margin:8px 0 3px;">ادائیگیوں کی تفصیل</div>
      <table style="width:100%;border-collapse:collapse;table-layout:fixed;max-width:100%;">
        <colgroup>
          <col style="width:8%;"/>
          <col style="width:32%;"/>
          <col style="width:30%;"/>
          <col style="width:30%;"/>
        </colgroup>
        <thead>
          <tr>
            <th style="${th}">SR</th>
            <th style="${th}">تاریخ</th>
            <th style="${th}">تفصیل</th>
            <th style="${th}">رقم</th>
          </tr>
        </thead>
        <tbody>
          ${payRows}
          <tr>
            <td colspan="3" style="border:0.5px solid #000;padding:1px 2px;font-size:10px;font-family:${UF};text-align:center;font-weight:900;color:#000;">کل ادا شدہ</td>
            <td style="border:0.5px solid #000;padding:1px 1px;font-size:10px;text-align:center;font-weight:900;color:#000;">${formatCurrency(paymentsTotal)}</td>
          </tr>
        </tbody>
      </table>` : "";

  return `
  <div style="width:100%;margin:0;padding:2px 3px;color:#000;background:#fff;font-family:Arial,sans-serif;box-sizing:border-box;direction:rtl;">

    <!-- HEADER (Invoice Settings se — sale invoice jaisa) -->
    <div style="text-align:center;margin-bottom:4px;">
      ${heading ? `<div style="font-size:12px;color:#000;font-weight:900;font-family:${UF};margin-bottom:3px;">${escapeHtml(heading)}</div>` : ""}
      ${bf.logo
        ? `<img src="${escapeHtml(bf.logo)}" alt="Logo" style="max-width:60px;max-height:35px;display:block;margin:0 auto 3px;" />`
        : `<div style="font-size:15px;font-weight:900;color:#000;font-family:${UF};margin-bottom:2px;">${escapeHtml(displayName)}</div>`}
      ${bf.logo && bf.business ? `<div style="font-size:13px;font-weight:900;color:#000;font-family:${UF};margin-bottom:2px;">${escapeHtml(bf.business)}</div>` : ""}
      ${bf.address ? `<div style="font-size:13px;font-weight:900;color:#000;font-family:${UF};margin-top:2px;">${escapeHtml(bf.address)}</div>` : ""}
      ${(bf.name && (bf.logo || bf.business)) || bf.phone ? `<div style="font-size:12px;font-weight:900;color:#000;font-family:${UF};margin-top:2px;display:flex;justify-content:center;gap:20px;">${bf.name && (bf.logo || bf.business) ? `<span>${escapeHtml(bf.name)}</span>` : ""}<span style="direction:ltr;">${escapeHtml(bf.phone)}</span></div>` : ""}
      ${bf.name2 || bf.phone2 ? `<div style="font-size:12px;font-weight:900;color:#000;font-family:${UF};margin-top:2px;display:flex;justify-content:center;gap:20px;">${bf.name2 ? `<span>${escapeHtml(bf.name2)}</span>` : ""}<span style="direction:ltr;">${escapeHtml(bf.phone2)}</span></div>` : ""}
    </div>

    <div style="border-top:2px solid #000;margin:3px 0;"></div>

    <div style="text-align:center;font-size:14px;font-weight:900;color:#000;font-family:${UF};margin:3px 0;">خریداری کی رسید</div>

    <!-- INFO -->
    <table style="width:100%;border-collapse:collapse;margin-bottom:3px;">
      <tbody>
        ${purchase.invoiceNumber ? infoRow("انوائس نمبر :", `<span style="direction:ltr;unicode-bidi:embed;">#${String(purchase.invoiceNumber).padStart(3, "0")}</span>`) : ""}
        ${infoRow("تاریخ :", `<span style="direction:ltr;unicode-bidi:embed;">${formatDateUrdu(purchase.date)} ${formatTimeUrdu(purchase.date)}</span>`)}
        ${infoRow("سپلائر :", escapeHtml(supplier.name))}
        ${supplier.phone ? infoRow("فون :", `<span style="direction:ltr;unicode-bidi:embed;">${escapeHtml(supplier.phone)}</span>`) : ""}
      </tbody>
    </table>

    <!-- ITEMS TABLE -->
    <table style="width:100%;border-collapse:collapse;table-layout:fixed;max-width:100%;">
      <colgroup>
        <col style="width:8%;"/>
        <col style="width:34%;"/>
        <col style="width:12%;"/>
        <col style="width:22%;"/>
        <col style="width:24%;"/>
      </colgroup>
      <thead>
        <tr>
          <th style="${th}">SR</th>
          <th style="${th}">نام آئٹم</th>
          <th style="${th}">تعداد</th>
          <th style="${th}">قیمت</th>
          <th style="${th}">کل</th>
        </tr>
      </thead>
      <tbody>
        ${itemRows}
        <tr>
          <td colspan="2" style="border:0.5px solid #000;padding:1px 2px;font-size:10px;font-family:${UF};text-align:center;font-weight:900;color:#000;">کل تعداد</td>
          <td style="border:0.5px solid #000;padding:1px 1px;font-size:10px;text-align:center;font-weight:900;color:#000;">${totalQty}</td>
          <td style="border:0.5px solid #000;"></td>
          <td style="border:0.5px solid #000;padding:1px 1px;font-size:10px;text-align:center;font-weight:900;color:#000;">${formatCurrency(purchase.total)}</td>
        </tr>
      </tbody>
    </table>

    <!-- TOTALS -->
    <table style="width:100%;border-collapse:collapse;margin-top:3px;">
      <tbody>
        ${sumRow("کل مالیت :", formatCurrency(purchase.total))}
        ${sumRow("ادا شدہ :", formatCurrency(purchase.advance))}
        ${sumRow("باقی رقم :", formatCurrency(purchase.remaining), "border-top:2px dashed #000;")}
      </tbody>
    </table>

    ${paymentsSection}

    <div style="border-top:2px solid #000;margin:6px 0 4px;"></div>

    <!-- FOOTER -->
    <div style="text-align:center;padding-bottom:5px;">
      <div style="font-size:11px;font-weight:900;color:#000;font-family:${UF};">یہ رسید صرف ریکارڈ کے لیے ہے</div>
    </div>
  </div>`;
}

export function printPurchaseReceipt(purchase, supplier, appName, invoiceSettings = {}) {
  const win = window.open("", "_blank", "width=400,height=600");
  if (!win) {
    alert("Popup blocked! Please allow popups.");
    return;
  }
  win.document.write(`<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8"/>
  <title>Purchase Receipt${purchase.invoiceNumber ? ` #${String(purchase.invoiceNumber).padStart(3, "0")}` : ""}</title>
  <link rel="preconnect" href="https://fonts.googleapis.com"/>
  <link href="https://fonts.googleapis.com/css2?family=Noto+Nastaliq+Urdu:wght@400;600;700&display=swap" rel="stylesheet"/>
  <style>
    * { margin: 0 !important; box-sizing: border-box !important; }
    body, div, h1, h2, h3, h4, h5, h6, p { padding: 0 !important; }
    html, body {
      width: 100%;
      max-width: 80mm;
      margin: 0 auto !important;
      background: #fff;
      overflow: visible !important;
      -webkit-print-color-adjust: exact;
      print-color-adjust: exact;
    }
    table { width: 100% !important; max-width: 100%; word-break: break-word; }
    img { max-width: 100%; }
    tr, td, th { page-break-inside: avoid; }
    .print-safe-area { padding-left: 2mm !important; padding-right: 2mm !important; }
    @media print {
      @page { size: 80mm auto; margin: 0 4mm 0 5mm; }
      html, body { width: 100% !important; max-width: 80mm !important; margin: 0 auto !important; padding: 0 !important; overflow: visible !important; }
      .print-safe-area { padding-left: 2mm !important; padding-right: 2mm !important; }
      * { -webkit-print-color-adjust: exact !important; print-color-adjust: exact !important; }
    }
  </style>
</head>
<body>
  <div class="print-safe-area">
  ${getReceiptHTML(purchase, supplier, appName, invoiceSettings)}
  </div>
  <script>
    window.onload = function() {
      document.fonts.ready.then(function() {
        setTimeout(function() {
          window.print();
          setTimeout(function() { window.close(); }, 1500);
        }, 300);
      });
    };
  </script>
</body>
</html>`);
  win.document.close();
}
