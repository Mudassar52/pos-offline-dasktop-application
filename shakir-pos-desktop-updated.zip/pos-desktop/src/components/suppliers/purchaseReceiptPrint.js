// ── Purchase Receipt — thermal (80mm) print, Urdu labels ──────────────────
// Supplier se maal khareedte waqt jo purchase batch banta hai, uski
// receipt isi tarah print hoti hai jaise POS invoice print hoti hai —
// same thermal printer format, bas Urdu mein aur supplier-purchase context
// ke sath (kitna maal, kitna diya, kitna baaki).

function formatCurrency(val) {
  return "Rs " + Number(val || 0).toLocaleString("en-PK");
}

function formatDateUrdu(iso) {
  const d = new Date(iso);
  const urduMonths = ["جنوری", "فروری", "مارچ", "اپریل", "مئی", "جون", "جولائی", "اگست", "ستمبر", "اکتوبر", "نومبر", "دسمبر"];
  const day = String(d.getDate()).padStart(2, "0");
  const month = urduMonths[d.getMonth()];
  const year = d.getFullYear();
  return `${day} ${month} ${year}`;
}

function formatTimeUrdu(iso) {
  const d = new Date(iso);
  let hours = d.getHours();
  const minutes = String(d.getMinutes()).padStart(2, "0");
  const ampm = hours >= 12 ? "شام" : "صبح";
  hours = hours % 12 || 12;
  return `${String(hours).padStart(2, "0")}:${minutes} ${ampm}`;
}

function escapeHtml(str) {
  return String(str || "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
}

function getReceiptHTML(purchase, supplier, appName) {
  const itemsRows = (purchase.items || []).map((it) => `
    <tr>
      <td style="padding:3px 0;font-size:12px;font-weight:700;">${escapeHtml(it.productName)}</td>
      <td style="padding:3px 0;font-size:11px;text-align:center;">${it.qty}</td>
      <td style="padding:3px 0;font-size:11px;text-align:center;direction:ltr;">${it.purchasePrice.toLocaleString("en-PK")}</td>
      <td style="padding:3px 0;font-size:12px;font-weight:700;text-align:left;direction:ltr;">${it.lineTotal.toLocaleString("en-PK")}</td>
    </tr>`).join("");

  return `
  <div dir="rtl" style="font-family:'Noto Nastaliq Urdu',sans-serif;width:100%;color:#000;">
    <div style="text-align:center;padding-bottom:6px;border-bottom:1px dashed #000;margin-bottom:8px;">
      <div style="font-size:16px;font-weight:900;">${escapeHtml(appName || "Shakir POS")}</div>
      <div style="font-size:13px;font-weight:700;margin-top:2px;">خریداری کی رسید</div>
      ${purchase.invoiceNumber ? `<div style="font-size:12px;font-weight:700;margin-top:2px;direction:ltr;">Invoice #${purchase.invoiceNumber}</div>` : ""}
    </div>

    <div style="font-size:12px;margin-bottom:6px;">
      <div style="display:flex;justify-content:space-between;padding:1px 0;">
        <span style="font-weight:700;">سپلائر:</span>
        <span>${escapeHtml(supplier.name)}</span>
      </div>
      ${supplier.phone ? `<div style="display:flex;justify-content:space-between;padding:1px 0;"><span style="font-weight:700;">فون:</span><span style="direction:ltr;">${escapeHtml(supplier.phone)}</span></div>` : ""}
      <div style="display:flex;justify-content:space-between;padding:1px 0;">
        <span style="font-weight:700;">تاریخ:</span>
        <span style="direction:ltr;">${formatDateUrdu(purchase.date)} — ${formatTimeUrdu(purchase.date)}</span>
      </div>
    </div>

    <table style="width:100%;border-collapse:collapse;border-top:1px dashed #000;border-bottom:1px dashed #000;margin:6px 0;">
      <thead>
        <tr>
          <th style="padding:4px 0;font-size:11px;text-align:right;">پروڈکٹ</th>
          <th style="padding:4px 0;font-size:11px;text-align:center;">تعداد</th>
          <th style="padding:4px 0;font-size:11px;text-align:center;">قیمت</th>
          <th style="padding:4px 0;font-size:11px;text-align:left;">کل</th>
        </tr>
      </thead>
      <tbody>${itemsRows}</tbody>
    </table>

    <div style="font-size:13px;">
      <div style="display:flex;justify-content:space-between;padding:3px 0;font-weight:900;">
        <span>کل مالیت (کتنے کا مال):</span>
        <span style="direction:ltr;">${formatCurrency(purchase.total)}</span>
      </div>
      <div style="display:flex;justify-content:space-between;padding:3px 0;color:#0a7d3d;font-weight:700;">
        <span>ادا شدہ (کتنے دیے):</span>
        <span style="direction:ltr;">${formatCurrency(purchase.advance)}</span>
      </div>
      <div style="display:flex;justify-content:space-between;padding:3px 0;border-top:1px dashed #000;margin-top:3px;color:#c00;font-weight:900;font-size:14px;">
        <span>باقی رقم (کتنے رہتے ہیں):</span>
        <span style="direction:ltr;">${formatCurrency(purchase.remaining)}</span>
      </div>
    </div>

    <div style="text-align:center;margin-top:14px;padding-top:6px;border-top:1px dotted #000;">
      <div style="font-size:10px;color:#444;">یہ رسید صرف ریکارڈ کے لیے ہے</div>
    </div>
  </div>`;
}

export function printPurchaseReceipt(purchase, supplier, appName) {
  const win = window.open("", "_blank", "width=400,height=600");
  if (!win) {
    alert("Popup blocked! Please allow popups.");
    return;
  }
  win.document.write(`<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8"/>
  <title>Purchase Receipt</title>
  <link rel="preconnect" href="https://fonts.googleapis.com"/>
  <link href="https://fonts.googleapis.com/css2?family=Noto+Nastaliq+Urdu:wght@400;600;700&display=swap" rel="stylesheet"/>
  <style>
    * { margin: 0 !important; box-sizing: border-box !important; }
    body, div, h1, h2, h3, h4, h5, h6, p { padding: 0 !important; }
    html, body {
      width: 100%;
      max-width: 80mm;
      margin: 0 auto !important;
      background: #fff;
      overflow: visible !important;
      -webkit-print-color-adjust: exact;
      print-color-adjust: exact;
    }
    table { width: 100% !important; max-width: 100%; word-break: break-word; }
    .print-safe-area { padding-left: 2mm !important; padding-right: 2mm !important; }
    @media print {
      @page { size: 80mm auto; margin: 0 4mm 0 5mm; }
      html, body { width: 100% !important; max-width: 80mm !important; margin: 0 auto !important; padding: 0 !important; overflow: visible !important; }
      .print-safe-area { padding-left: 2mm !important; padding-right: 2mm !important; }
      * { -webkit-print-color-adjust: exact !important; print-color-adjust: exact !important; }
    }
  </style>
</head>
<body>
  <div class="print-safe-area">
  ${getReceiptHTML(purchase, supplier, appName)}
  </div>
  <script>
    window.onload = function() {
      document.fonts.ready.then(function() {
        setTimeout(function() {
          window.print();
          setTimeout(function() { window.close(); }, 1500);
        }, 300);
      });
    };
  </script>
</body>
</html>`);
  win.document.close();
}
