import { useState, useMemo } from "react";
import StatsGrid from "../common/StatsGrid";
import DateRangePicker from "../common/DateRangePicker";
import ProductSelector from "../common/ProductSelector";

function formatCurrency(val) {
  return "Rs " + Number(val || 0).toLocaleString("en-PK");
}
function formatDate(iso) {
  if (!iso) return "—";
  return new Date(iso).toLocaleDateString("en-PK", { day: "2-digit", month: "short", year: "numeric" });
}

const LOSS_REASONS = ["Damaged", "Expired", "Theft/Chori", "Breakage", "Spoiled", "Other"];

function AddLossModal({ products, onClose, onSave }) {
  const [product, setProduct] = useState(null);
  const [qty, setQty] = useState("");
  const [reason, setReason] = useState(LOSS_REASONS[0]);
  const [note, setNote] = useState("");
  const [error, setError] = useState("");
  const [saving, setSaving] = useState(false);

  const estValue = product ? (product.costPrice || product.stockPrice || 0) * Number(qty || 0) : 0;

  const handleSubmit = async () => {
    const q = Number(qty);
    if (!product) { setError("Product select karein"); return; }
    if (!q || q <= 0) { setError("Sahi quantity likhein"); return; }
    try {
      setSaving(true);
      await onSave({ productId: product.id, productName: product.name, qty: q, reason, note });
      onClose();
    } catch (err) {
      setError(err.message || "Save nahi ho saka");
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm">
      <div className="bg-white rounded-2xl w-full max-w-md shadow-2xl">
        <div className="flex items-center justify-between px-6 pt-5 pb-4 border-b border-slate-100">
          <h2 className="font-bold text-slate-800 text-lg">Naya Loss Record Karein</h2>
          <button onClick={onClose} className="w-8 h-8 flex items-center justify-center rounded-xl hover:bg-slate-100 text-slate-400">
            <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round"><path d="M18 6 6 18M6 6l12 12" /></svg>
          </button>
        </div>
        <div className="px-6 py-5 space-y-4">
          <div>
            <label className="block text-xs font-semibold text-slate-500 mb-1.5">Product</label>
            <ProductSelector products={products} selectedProduct={product} onSelect={setProduct} placeholder="Product search karein..." />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-500 mb-1.5">Quantity Lost *</label>
              <input type="number" value={qty} onChange={(e) => { setQty(e.target.value); setError(""); }} placeholder="0"
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 text-sm outline-none focus:border-blue-400" />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-500 mb-1.5">Reason</label>
              <select value={reason} onChange={(e) => setReason(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 text-sm outline-none focus:border-blue-400 bg-white">
                {LOSS_REASONS.map((r) => <option key={r} value={r}>{r}</option>)}
              </select>
            </div>
          </div>
          <div>
            <label className="block text-xs font-semibold text-slate-500 mb-1.5">Note (optional)</label>
            <input type="text" value={note} onChange={(e) => setNote(e.target.value)} placeholder="Extra tafseel..."
              className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 text-sm outline-none focus:border-blue-400" />
          </div>
          {product && qty > 0 && (
            <p className="text-xs text-red-600 bg-red-50 rounded-xl px-3.5 py-2.5">
              ⚠ Is product ka stock <b>{qty}</b> unit se kam ho jayega. Andazan loss value: <b>{formatCurrency(estValue)}</b>
            </p>
          )}
          {error && <p className="text-xs text-red-500">{error}</p>}
        </div>
        <div className="px-6 pb-5 flex gap-3">
          <button onClick={onClose} className="flex-1 py-2.5 rounded-xl border border-slate-200 text-sm font-semibold text-slate-600 hover:bg-slate-50">Cancel</button>
          <button onClick={handleSubmit} disabled={saving}
            className="flex-1 py-2.5 rounded-xl bg-red-600 hover:bg-red-700 disabled:opacity-50 text-white text-sm font-bold transition-colors">
            {saving ? "Saving..." : "Loss Save Karein"}
          </button>
        </div>
      </div>
    </div>
  );
}

export default function LossManagementView({ products = [], losses = [], addLoss, deleteLoss }) {
  const [dateRange, setDateRange] = useState({ from: null, to: null });
  const [search, setSearch] = useState("");
  const [showAdd, setShowAdd] = useState(false);

  const filtered = useMemo(() => {
    return losses
      .filter((l) => !search || l.productName.toLowerCase().includes(search.toLowerCase()))
      .filter((l) => {
        if (!dateRange.from || !dateRange.to) return true;
        const d = l.date.slice(0, 10);
        return d >= dateRange.from && d <= dateRange.to;
      })
      .sort((a, b) => new Date(b.date) - new Date(a.date));
  }, [losses, search, dateRange]);

  const stats = useMemo(() => {
    const now = new Date();
    const monthLosses = losses.filter((l) => { const d = new Date(l.date); return d.getFullYear() === now.getFullYear() && d.getMonth() === now.getMonth(); });
    const qtyLost = losses.reduce((s, l) => s + l.qty, 0);
    const totalValue = losses.reduce((s, l) => s + l.value, 0);
    const monthValue = monthLosses.reduce((s, l) => s + l.value, 0);
    return { totalRecords: losses.length, qtyLost, totalValue, monthValue };
  }, [losses]);

  const statsCards = [
    { title: "Total Loss Records", value: stats.totalRecords, icon: "M12 9v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z", light: "bg-red-50", text: "text-red-600" },
    { title: "Qty Lost", value: stats.qtyLost, icon: "M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4", light: "bg-amber-50", text: "text-amber-600" },
    { title: "Total Loss Value", value: formatCurrency(stats.totalValue), icon: "M17 9V7a4 4 0 00-8 0v2M5 9h14l1 12H4L5 9z", light: "bg-red-50", text: "text-red-600" },
    { title: "This Month's Loss", value: formatCurrency(stats.monthValue), icon: "M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z", light: "bg-violet-50", text: "text-violet-600" },
  ];

  return (
    <div className="flex-1 overflow-y-auto scrollbar-hide bg-slate-50/80">
      <div className="px-4 sm:px-6 pt-4 pb-2 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
        <div>
          <h2 className="text-lg font-black text-slate-800">Loss Management</h2>
          <p className="text-sm text-slate-400 mt-0.5">Damaged / expired / chori waghera ka hisaab rakhein</p>
        </div>
        <button onClick={() => setShowAdd(true)}
          className="flex items-center gap-2 px-4 py-2.5 bg-red-600 hover:bg-red-700 text-white text-sm font-bold rounded-xl shadow-md shadow-red-200 transition-colors self-start sm:self-auto">
          <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round"><path d="M12 5v14M5 12h14" /></svg>
          New Loss
        </button>
      </div>

      <div className="px-4 sm:px-6 py-2">
        <StatsGrid cards={statsCards} />
      </div>

      <div className="px-4 sm:px-6 py-3">
        <div className="flex flex-col sm:flex-row items-stretch gap-3">
          <div className="flex-1 flex items-center gap-2 bg-white rounded-xl border border-slate-200 px-3.5 py-2.5">
            <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#94A3B8" strokeWidth="2" strokeLinecap="round"><circle cx="11" cy="11" r="8" /><path d="m21 21-4.35-4.35" /></svg>
            <input type="text" value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Product naam se search karein..."
              className="flex-1 bg-transparent text-sm outline-none placeholder:text-slate-400" />
          </div>
          <DateRangePicker value={dateRange} onChange={setDateRange} />
        </div>
      </div>

      <div className="px-4 sm:px-6 pb-6">
        {filtered.length === 0 ? (
          <div className="bg-white rounded-2xl border border-slate-100 p-16 text-center">
            <p className="text-slate-500 font-medium">Koi loss record nahi mila.</p>
          </div>
        ) : (
          <div className="bg-white rounded-2xl border border-slate-100 overflow-hidden shadow-sm divide-y divide-slate-50">
            {filtered.map((l) => (
              <div key={l.id} className="flex items-center justify-between px-5 py-3.5 hover:bg-slate-50/50">
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-xl bg-red-50 flex items-center justify-center flex-shrink-0">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#dc2626" strokeWidth="2" strokeLinecap="round"><path d="M12 9v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
                  </div>
                  <div>
                    <p className="text-sm font-semibold text-slate-700">{l.productName}</p>
                    <p className="text-xs text-slate-400">{l.reason} · {formatDate(l.date)}{l.note ? ` · ${l.note}` : ""}</p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <span className="text-xs font-bold px-2.5 py-1 rounded-lg bg-amber-50 text-amber-600">Qty: {l.qty}</span>
                  <p className="text-sm font-bold text-red-600">{formatCurrency(l.value)}</p>
                  <button onClick={() => deleteLoss(l.id)} title="Delete"
                    className="w-7 h-7 flex items-center justify-center bg-red-50 hover:bg-red-100 text-red-500 rounded-lg transition-colors">
                    <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round"><polyline points="3 6 5 6 21 6" /><path d="M19 6v14a2 2 0 01-2 2H7a2 2 0 01-2-2V6m3 0V4a2 2 0 012-2h4a2 2 0 012 2v2" /></svg>
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {showAdd && <AddLossModal products={products} onClose={() => setShowAdd(false)} onSave={addLoss} />}
    </div>
  );
}
