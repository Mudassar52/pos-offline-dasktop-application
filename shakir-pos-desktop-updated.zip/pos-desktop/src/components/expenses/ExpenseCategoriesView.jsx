import { useState } from "react";

const SUGGESTED_COLORS = ["#2563eb", "#059669", "#d97706", "#7c3aed", "#dc2626", "#0891b2", "#db2777", "#65a30d"];

// ── Expense → Manage Categories ────────────────────────────────────────
// Reached via the "Manage Categories" toggle on the main Expenses page.
// Lets the shop owner add/remove expense categories and pick a custom
// color for each one (used as the badge color on the Expenses list).
export default function ExpenseCategoriesView({ categories = [], colors = {}, onAddCategory, onRemoveCategory, onSetColor, onBack }) {
  const [name, setName] = useState("");
  const [color, setColor] = useState(SUGGESTED_COLORS[0]);
  const [error, setError] = useState("");
  const [saving, setSaving] = useState(false);

  const handleAdd = async () => {
    const clean = name.trim();
    if (!clean) { setError("Category ka naam likhein"); return; }
    if (categories.includes(clean)) { setError("Ye category pehle se maujood hai"); return; }
    try {
      setSaving(true);
      await onAddCategory(clean);
      await onSetColor(clean, color);
      setName("");
      setColor(SUGGESTED_COLORS[(categories.length + 1) % SUGGESTED_COLORS.length]);
      setError("");
    } catch (err) {
      setError(err.message || "Category add nahi ho saki");
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="flex-1 overflow-y-auto scrollbar-hide bg-slate-50/80">
      <div className="px-4 sm:px-6 pt-4 pb-2 flex items-center gap-3">
        <button onClick={onBack} className="w-9 h-9 flex items-center justify-center rounded-xl bg-white border border-slate-200 hover:bg-slate-50 text-slate-600 transition-colors">
          <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><path d="M19 12H5m0 0 7 7m-7-7 7-7" /></svg>
        </button>
        <div>
          <h2 className="text-lg font-black text-slate-800">Manage Expense Categories</h2>
          <p className="text-sm text-slate-400 mt-0.5">Category banayein aur har ek ke liye apna rang chunein</p>
        </div>
      </div>

      {/* Custom color picker + add form — sits above the category list */}
      <div className="px-4 sm:px-6 py-4">
        <div className="bg-white rounded-2xl border border-slate-100 shadow-sm p-5">
          <h3 className="text-sm font-bold text-slate-700 mb-3">Nayi Category</h3>
          <div className="flex flex-col sm:flex-row items-stretch sm:items-end gap-3">
            <div className="flex-1">
              <label className="block text-xs font-semibold text-slate-500 mb-1.5">Category Naam</label>
              <input type="text" value={name} onChange={(e) => { setName(e.target.value); setError(""); }} placeholder="e.g. Internet Bill"
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 text-sm outline-none focus:border-blue-400" />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-500 mb-1.5">Custom Rang</label>
              <div className="flex items-center gap-2">
                <input type="color" value={color} onChange={(e) => setColor(e.target.value)}
                  className="w-11 h-[42px] rounded-xl border border-slate-200 cursor-pointer bg-white p-1" />
                <div className="flex items-center gap-1.5">
                  {SUGGESTED_COLORS.map((c) => (
                    <button key={c} type="button" onClick={() => setColor(c)}
                      className={`w-6 h-6 rounded-full border-2 transition-transform ${color === c ? "border-slate-700 scale-110" : "border-white"}`}
                      style={{ backgroundColor: c }} title={c} />
                  ))}
                </div>
              </div>
            </div>
            <button onClick={handleAdd} disabled={saving}
              className="px-5 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white text-sm font-bold whitespace-nowrap transition-colors">
              + Add Category
            </button>
          </div>
          {error && <p className="text-xs text-red-500 mt-2">{error}</p>}
        </div>
      </div>

      {/* Existing categories */}
      <div className="px-4 sm:px-6 pb-6">
        <div className="bg-white rounded-2xl border border-slate-100 shadow-sm overflow-hidden divide-y divide-slate-50">
          {categories.length === 0 ? (
            <p className="text-sm text-slate-400 text-center py-10">Abhi koi category nahi hai.</p>
          ) : (
            categories.map((c) => {
              const catColor = colors[c] || SUGGESTED_COLORS[categories.indexOf(c) % SUGGESTED_COLORS.length];
              return (
                <div key={c} className="flex items-center justify-between px-5 py-3.5">
                  <div className="flex items-center gap-3">
                    <span className="w-4 h-4 rounded-full flex-shrink-0" style={{ backgroundColor: catColor }} />
                    <span className="text-sm font-semibold text-slate-700">{c}</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <input type="color" value={catColor} onChange={(e) => onSetColor(c, e.target.value)}
                      title="Rang badlein" className="w-8 h-8 rounded-lg border border-slate-200 cursor-pointer bg-white p-0.5" />
                    <button onClick={() => onRemoveCategory(c)} title="Delete"
                      className="w-8 h-8 flex items-center justify-center bg-red-50 hover:bg-red-100 text-red-500 rounded-lg transition-colors">
                      <svg xmlns="http://www.w3.org/2000/svg" width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round"><polyline points="3 6 5 6 21 6" /><path d="M19 6v14a2 2 0 01-2 2H7a2 2 0 01-2-2V6m3 0V4a2 2 0 012-2h4a2 2 0 012 2v2" /></svg>
                    </button>
                  </div>
                </div>
              );
            })
          )}
        </div>
      </div>
    </div>
  );
}
