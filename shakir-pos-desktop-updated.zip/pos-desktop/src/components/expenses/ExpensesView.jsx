import { useState, useMemo } from "react";
import DateRangePicker from "../common/DateRangePicker";
import StatsGrid from "../common/StatsGrid";
import ExpenseCategoriesView from "./ExpenseCategoriesView";

function formatCurrency(val) {
  return "Rs " + Number(val || 0).toLocaleString("en-PK");
}
function formatDate(iso) {
  if (!iso) return "—";
  return new Date(iso).toLocaleDateString("en-PK", { day: "2-digit", month: "short", year: "numeric" });
}
function toISODate(d) {
  return d.toISOString().slice(0, 10);
}

const FALLBACK_COLORS = ["#2563eb", "#059669", "#d97706", "#7c3aed", "#dc2626", "#0891b2", "#db2777"];
function colorFor(category, categories, colors) {
  if (colors && colors[category]) return colors[category];
  const idx = categories.indexOf(category);
  return FALLBACK_COLORS[(idx < 0 ? 0 : idx) % FALLBACK_COLORS.length];
}

// ── Add Expense modal (matches the Supplier/Product "New X" modal pattern
// used elsewhere in the app, instead of the old inline expanding toggle) ──
function AddExpenseModal({ categories, onClose, onSave }) {
  const [category, setCategory] = useState(categories[0] || "");
  const [amount, setAmount] = useState("");
  const [description, setDescription] = useState("");
  const [date, setDate] = useState(toISODate(new Date()));
  const [error, setError] = useState("");
  const [saving, setSaving] = useState(false);

  const handleSubmit = async () => {
    const amt = Number(amount);
    if (!amt || amt <= 0) { setError("Sahi amount likhein"); return; }
    if (!category) { setError("Category chunein"); return; }
    try {
      setSaving(true);
      await onSave({ category, amount: amt, description, date: new Date(date).toISOString() });
      onClose();
    } catch (err) {
      setError(err.message || "Save nahi ho saka, dobara koshish karein");
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm">
      <div className="bg-white rounded-2xl w-full max-w-md shadow-2xl">
        <div className="flex items-center justify-between px-6 pt-5 pb-4 border-b border-slate-100">
          <h2 className="font-bold text-slate-800 text-lg">Naya Expense Add Karein</h2>
          <button onClick={onClose} className="w-8 h-8 flex items-center justify-center rounded-xl hover:bg-slate-100 text-slate-400">
            <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round"><path d="M18 6 6 18M6 6l12 12" /></svg>
          </button>
        </div>
        <div className="px-6 py-5 space-y-4">
          <div>
            <label className="block text-xs font-semibold text-slate-500 mb-1.5">Category</label>
            {categories.length === 0 ? (
              <p className="text-xs text-slate-400 bg-slate-50 rounded-xl px-3.5 py-2.5">Koi category nahi hai — pehle "Manage Categories" se ek category banayein.</p>
            ) : (
              <select value={category} onChange={(e) => setCategory(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 text-sm outline-none focus:border-blue-400 bg-white">
                {categories.map((c) => <option key={c} value={c}>{c}</option>)}
              </select>
            )}
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-500 mb-1.5">Amount (Rs) *</label>
              <input type="number" value={amount} onChange={(e) => { setAmount(e.target.value); setError(""); }} placeholder="0"
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 text-sm outline-none focus:border-blue-400" />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-500 mb-1.5">Date</label>
              <input type="date" value={date} onChange={(e) => setDate(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 text-sm outline-none focus:border-blue-400" />
            </div>
          </div>
          <div>
            <label className="block text-xs font-semibold text-slate-500 mb-1.5">Description (optional)</label>
            <input type="text" value={description} onChange={(e) => setDescription(e.target.value)} placeholder="e.g. August ka bijli bill"
              className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 text-sm outline-none focus:border-blue-400" />
          </div>
          {error && <p className="text-xs text-red-500">{error}</p>}
        </div>
        <div className="px-6 pb-5 flex gap-3">
          <button onClick={onClose} className="flex-1 py-2.5 rounded-xl border border-slate-200 text-sm font-semibold text-slate-600 hover:bg-slate-50">Cancel</button>
          <button onClick={handleSubmit} disabled={saving || categories.length === 0}
            className="flex-1 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white text-sm font-bold transition-colors">
            {saving ? "Saving..." : "Expense Save Karein"}
          </button>
        </div>
      </div>
    </div>
  );
}

function EditExpenseModal({ expense, categories, onClose, onSave }) {
  const [form, setForm] = useState({
    category: expense.category, amount: expense.amount, description: expense.description || "", date: expense.date.slice(0, 10),
  });
  const [error, setError] = useState("");

  const handleSubmit = () => {
    const amt = Number(form.amount);
    if (!amt || amt <= 0) { setError("Sahi amount likhein"); return; }
    onSave({ ...form, amount: amt, date: new Date(form.date).toISOString() });
  };

  const catOptions = categories.includes(expense.category) ? categories : [expense.category, ...categories];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm">
      <div className="bg-white rounded-2xl w-full max-w-md shadow-2xl">
        <div className="flex items-center justify-between px-6 pt-5 pb-4 border-b border-slate-100">
          <h2 className="font-bold text-slate-800 text-lg">Edit Expense</h2>
          <button onClick={onClose} className="w-8 h-8 flex items-center justify-center rounded-xl hover:bg-slate-100 text-slate-400">
            <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round"><path d="M18 6 6 18M6 6l12 12" /></svg>
          </button>
        </div>
        <div className="px-6 py-5 space-y-4">
          <div>
            <label className="block text-xs font-semibold text-slate-500 mb-1.5">Category</label>
            <select value={form.category} onChange={(e) => setForm((f) => ({ ...f, category: e.target.value }))}
              className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 text-sm outline-none focus:border-blue-400 bg-white">
              {catOptions.map((c) => <option key={c} value={c}>{c}</option>)}
            </select>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-500 mb-1.5">Amount (Rs)</label>
              <input type="number" value={form.amount} onChange={(e) => { setForm((f) => ({ ...f, amount: e.target.value })); setError(""); }}
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 text-sm outline-none focus:border-blue-400" />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-500 mb-1.5">Date</label>
              <input type="date" value={form.date} onChange={(e) => setForm((f) => ({ ...f, date: e.target.value }))}
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 text-sm outline-none focus:border-blue-400" />
            </div>
          </div>
          <div>
            <label className="block text-xs font-semibold text-slate-500 mb-1.5">Description</label>
            <input type="text" value={form.description} onChange={(e) => setForm((f) => ({ ...f, description: e.target.value }))}
              className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 text-sm outline-none focus:border-blue-400" />
          </div>
          {error && <p className="text-xs text-red-500">{error}</p>}
        </div>
        <div className="px-6 pb-5 flex gap-3">
          <button onClick={onClose} className="flex-1 py-2.5 rounded-xl border border-slate-200 text-sm font-semibold text-slate-600 hover:bg-slate-50">Cancel</button>
          <button onClick={handleSubmit} className="flex-1 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-sm font-bold transition-colors">Update</button>
        </div>
      </div>
    </div>
  );
}

export default function ExpensesView({
  expenses = [], expenseCategories = [], expenseCategoryColors = {},
  addExpense, updateExpense, deleteExpense,
  addExpenseCategory, removeExpenseCategory, setExpenseCategoryColor,
}) {
  // "page" toggle: list ↔ Manage Categories (a separate in-place page, per
  // the requested flow, instead of a nav-level route).
  const [page, setPage] = useState("list");
  const [dateRange, setDateRange] = useState({ from: null, to: null });
  const [categoryFilter, setCategoryFilter] = useState("all");
  const [showAddModal, setShowAddModal] = useState(false);
  const [editingExpense, setEditingExpense] = useState(null);

  const filtered = useMemo(() => {
    return expenses
      .filter((e) => categoryFilter === "all" || e.category === categoryFilter)
      .filter((e) => {
        if (!dateRange.from || !dateRange.to) return true;
        const d = e.date.slice(0, 10);
        return d >= dateRange.from && d <= dateRange.to;
      })
      .sort((a, b) => new Date(b.date) - new Date(a.date));
  }, [expenses, categoryFilter, dateRange]);

  // ── Stats: Today, This Month, All Time Total, Total Entries ──────────
  const stats = useMemo(() => {
    const now = new Date();
    const today = now.toDateString();
    const todayTotal = expenses.filter((e) => new Date(e.date).toDateString() === today).reduce((s, e) => s + e.amount, 0);
    const monthTotal = expenses
      .filter((e) => { const d = new Date(e.date); return d.getFullYear() === now.getFullYear() && d.getMonth() === now.getMonth(); })
      .reduce((s, e) => s + e.amount, 0);
    const allTimeTotal = expenses.reduce((s, e) => s + e.amount, 0);
    return { todayTotal, monthTotal, allTimeTotal, totalEntries: expenses.length };
  }, [expenses]);

  const statsCards = [
    { title: "Today", value: formatCurrency(stats.todayTotal), icon: "M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z", light: "bg-blue-50", text: "text-blue-600" },
    { title: "This Month", value: formatCurrency(stats.monthTotal), icon: "M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z", light: "bg-violet-50", text: "text-violet-600" },
    { title: "All Time Total", value: formatCurrency(stats.allTimeTotal), icon: "M17 9V7a4 4 0 00-8 0v2M5 9h14l1 12H4L5 9z", light: "bg-red-50", text: "text-red-600" },
    { title: "Total Entries", value: stats.totalEntries, icon: "M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z", light: "bg-emerald-50", text: "text-emerald-600" },
  ];

  const handleAddExpense = async (form) => {
    await addExpense(form);
    setShowAddModal(false);
  };

  const handleSaveEdit = async (form) => {
    await updateExpense(editingExpense.id, form);
    setEditingExpense(null);
  };

  if (page === "categories") {
    return (
      <ExpenseCategoriesView
        categories={expenseCategories}
        colors={expenseCategoryColors}
        onAddCategory={addExpenseCategory}
        onRemoveCategory={removeExpenseCategory}
        onSetColor={setExpenseCategoryColor}
        onBack={() => setPage("list")}
      />
    );
  }

  return (
    <div className="flex-1 overflow-y-auto scrollbar-hide bg-slate-50/80">
      {/* Header actions — sits above the stats, as requested */}
      <div className="px-4 sm:px-6 pt-4 pb-2 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
        <div>
          <h2 className="text-lg font-black text-slate-800">Expenses</h2>
          <p className="text-sm text-slate-400 mt-0.5">Dukaan ke rozana kharche track karein</p>
        </div>
        <div className="flex items-center gap-2">
          <button onClick={() => setPage("categories")}
            className="flex items-center gap-2 px-4 py-2.5 bg-white border border-slate-200 hover:bg-slate-50 text-slate-700 text-sm font-bold rounded-xl shadow-sm transition-colors">
            <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><circle cx="13.5" cy="6.5" r=".5" /><circle cx="17.5" cy="10.5" r=".5" /><circle cx="8.5" cy="7.5" r=".5" /><circle cx="6.5" cy="12.5" r=".5" /><path d="M12 2C6.5 2 2 6.5 2 12s4.5 10 10 10c.926 0 1.648-.746 1.648-1.688 0-.437-.18-.835-.437-1.125-.29-.289-.438-.652-.438-1.125a1.64 1.64 0 011.688-1.688h1.996c3.051 0 5.555-2.503 5.555-5.554C21.965 6.012 17.461 2 12 2z" /></svg>
            Manage Categories
          </button>
          <button onClick={() => setShowAddModal(true)}
            className="flex items-center gap-2 px-4 py-2.5 bg-blue-600 hover:bg-blue-700 text-white text-sm font-bold rounded-xl shadow-md shadow-blue-200 transition-colors">
            <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round"><path d="M12 5v14M5 12h14" /></svg>
            New Expense
          </button>
        </div>
      </div>

      {/* Stats */}
      <div className="px-4 sm:px-6 py-2">
        <StatsGrid cards={statsCards} />
      </div>

      {/* Filters */}
      <div className="px-4 sm:px-6 py-3">
        <div className="flex flex-col sm:flex-row items-stretch gap-3">
          <div className="flex flex-1 items-center gap-2 overflow-x-auto scrollbar-hide">
            <button onClick={() => setCategoryFilter("all")}
              className={`px-3.5 py-2 rounded-xl text-xs font-bold border whitespace-nowrap transition-colors ${categoryFilter === "all" ? "bg-blue-600 border-blue-600 text-white" : "bg-white border-slate-200 text-slate-600 hover:bg-slate-50"}`}>
              All Categories
            </button>
            {expenseCategories.map((c) => (
              <button key={c} onClick={() => setCategoryFilter(c)}
                className={`px-3.5 py-2 rounded-xl text-xs font-bold border whitespace-nowrap transition-colors ${categoryFilter === c ? "text-white" : "bg-white border-slate-200 text-slate-600 hover:bg-slate-50"}`}
                style={categoryFilter === c ? { backgroundColor: colorFor(c, expenseCategories, expenseCategoryColors), borderColor: colorFor(c, expenseCategories, expenseCategoryColors) } : {}}>
                {c}
              </button>
            ))}
          </div>
          <DateRangePicker value={dateRange} onChange={setDateRange} />
        </div>
      </div>

      {/* List */}
      <div className="px-4 sm:px-6 pb-6">
        {filtered.length === 0 ? (
          <div className="bg-white rounded-2xl border border-slate-100 p-16 text-center">
            <p className="text-slate-500 font-medium">Koi expense record nahi mila.</p>
          </div>
        ) : (
          <div className="bg-white rounded-2xl border border-slate-100 overflow-hidden shadow-sm divide-y divide-slate-50">
            {filtered.map((e) => {
              const c = colorFor(e.category, expenseCategories, expenseCategoryColors);
              return (
                <div key={e.id} className="flex items-center justify-between px-5 py-3.5 hover:bg-slate-50/50">
                  <div className="flex items-center gap-3">
                    <span className="text-[11px] font-bold px-2.5 py-1 rounded-lg" style={{ backgroundColor: `${c}1a`, color: c }}>{e.category}</span>
                    <div>
                      <p className="text-sm font-semibold text-slate-700">{e.description || e.category}</p>
                      <p className="text-xs text-slate-400">{formatDate(e.date)}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <p className="text-sm font-bold text-red-600">{formatCurrency(e.amount)}</p>
                    <button onClick={() => setEditingExpense(e)} title="Edit"
                      className="w-7 h-7 flex items-center justify-center bg-amber-50 hover:bg-amber-100 text-amber-600 rounded-lg transition-colors">
                      <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7" /><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z" /></svg>
                    </button>
                    <button onClick={() => deleteExpense(e.id)} title="Delete"
                      className="w-7 h-7 flex items-center justify-center bg-red-50 hover:bg-red-100 text-red-500 rounded-lg transition-colors">
                      <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round"><polyline points="3 6 5 6 21 6" /><path d="M19 6v14a2 2 0 01-2 2H7a2 2 0 01-2-2V6m3 0V4a2 2 0 012-2h4a2 2 0 012 2v2" /></svg>
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {showAddModal && (
        <AddExpenseModal categories={expenseCategories} onClose={() => setShowAddModal(false)} onSave={handleAddExpense} />
      )}
      {editingExpense && (
        <EditExpenseModal expense={editingExpense} categories={expenseCategories} onClose={() => setEditingExpense(null)} onSave={handleSaveEdit} />
      )}
    </div>
  );
}
