import { useState, useRef, useEffect } from "react";

/**
 * ProductSelector
 * A search-as-you-type dropdown to pick a catalog product. Also supports
 * an optional "add a product that isn't in the catalog yet" free-text mode,
 * used by flows like Supplier Purchase where a brand-new item may be
 * bought before it exists as a product.
 *
 * Props:
 *   products: array of product objects
 *   onSelect: (product|null) => void
 *   selectedProduct: product object or null
 *   allowFreeText: bool — if true, typing a name with no match lets the
 *                  caller treat it as a "new product" via onFreeText
 *   freeTextValue: string — current free-text name (when nothing selected)
 *   onFreeTextChange: (name) => void
 *   placeholder: string
 */
export default function ProductSelector({
  products = [], onSelect, selectedProduct,
  allowFreeText = false, freeTextValue = "", onFreeTextChange,
  placeholder = "Search product by name...",
}) {
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState("");
  const dropRef = useRef(null);
  const inputRef = useRef(null);

  const filtered = products.filter((p) => {
    const q = query.toLowerCase();
    return !q || p.name.toLowerCase().includes(q) || (p.category || "").toLowerCase().includes(q);
  }).slice(0, 30);

  useEffect(() => {
    function handleClick(e) {
      if (dropRef.current && !dropRef.current.contains(e.target)) setOpen(false);
    }
    document.addEventListener("mousedown", handleClick);
    return () => document.removeEventListener("mousedown", handleClick);
  }, []);

  const handleOpen = () => {
    setOpen(true);
    setQuery(selectedProduct ? "" : freeTextValue || "");
    setTimeout(() => inputRef.current?.focus(), 50);
  };

  const handlePick = (p) => {
    onSelect(p);
    setOpen(false);
    setQuery("");
  };

  const handleClear = () => {
    onSelect(null);
    if (onFreeTextChange) onFreeTextChange("");
    setOpen(false);
  };

  const handleQueryChange = (val) => {
    setQuery(val);
    if (allowFreeText && onFreeTextChange) onFreeTextChange(val);
  };

  const showingFreeText = allowFreeText && !selectedProduct && freeTextValue;

  return (
    <div className="relative" ref={dropRef}>
      <button
        type="button"
        onClick={selectedProduct ? undefined : handleOpen}
        className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl border text-sm transition-colors text-left
          ${selectedProduct ? "border-blue-300 bg-blue-50" : "border-slate-200 bg-white hover:border-blue-300 hover:bg-blue-50/40"}`}
      >
        {selectedProduct ? (
          <>
            <div className="w-7 h-7 rounded-lg bg-blue-100 flex items-center justify-center flex-shrink-0">
              <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#2563eb" strokeWidth="2" strokeLinecap="round"><path d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4" /></svg>
            </div>
            <div className="flex-1 min-w-0">
              <p className="font-semibold text-slate-800 truncate">{selectedProduct.name}</p>
              <p className="text-xs text-slate-400">Stock: {selectedProduct.currentStock}{selectedProduct.category ? ` · ${selectedProduct.category}` : ""}</p>
            </div>
            <button type="button" onClick={(e) => { e.stopPropagation(); handleClear(); }}
              className="flex-shrink-0 w-6 h-6 flex items-center justify-center rounded-lg hover:bg-blue-200 text-blue-400 hover:text-blue-700 transition-colors" title="Clear selection">
              <svg xmlns="http://www.w3.org/2000/svg" width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round"><path d="M18 6 6 18M6 6l12 12" /></svg>
            </button>
          </>
        ) : showingFreeText ? (
          <>
            <div className="w-7 h-7 rounded-lg bg-emerald-100 flex items-center justify-center flex-shrink-0">
              <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#059669" strokeWidth="2.5" strokeLinecap="round"><path d="M12 5v14M5 12h14" /></svg>
            </div>
            <div className="flex-1 min-w-0">
              <p className="font-semibold text-slate-800 truncate">{freeTextValue}</p>
              <p className="text-xs text-emerald-600">New product — will be added to catalog</p>
            </div>
            <button type="button" onClick={(e) => { e.stopPropagation(); handleClear(); }}
              className="flex-shrink-0 w-6 h-6 flex items-center justify-center rounded-lg hover:bg-emerald-200 text-emerald-500 transition-colors" title="Clear">
              <svg xmlns="http://www.w3.org/2000/svg" width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round"><path d="M18 6 6 18M6 6l12 12" /></svg>
            </button>
          </>
        ) : (
          <>
            <div className="w-7 h-7 rounded-full bg-slate-100 flex items-center justify-center flex-shrink-0">
              <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#94A3B8" strokeWidth="2" strokeLinecap="round"><circle cx="11" cy="11" r="8" /><path d="m21 21-4.35-4.35" /></svg>
            </div>
            <span className="text-slate-400 flex-1">{placeholder}</span>
            <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#94A3B8" strokeWidth="2.5" strokeLinecap="round" className="flex-shrink-0"><path d="m6 9 6 6 6-6" /></svg>
          </>
        )}
      </button>

      {open && (
        <div className="absolute z-50 top-full left-0 right-0 mt-1.5 bg-white rounded-xl border border-slate-200 shadow-xl overflow-hidden">
          <div className="p-2 border-b border-slate-100">
            <div className="flex items-center gap-2 bg-slate-50 rounded-lg px-3 py-2">
              <svg xmlns="http://www.w3.org/2000/svg" width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="#94A3B8" strokeWidth="2" strokeLinecap="round" className="flex-shrink-0"><circle cx="11" cy="11" r="8" /><path d="m21 21-4.35-4.35" /></svg>
              <input ref={inputRef} type="text" value={query} onChange={(e) => handleQueryChange(e.target.value)}
                placeholder="Search or type a new product name..."
                className="flex-1 bg-transparent text-sm text-slate-700 outline-none placeholder:text-slate-400" />
            </div>
          </div>
          <div className="max-h-48 overflow-y-auto">
            {filtered.length === 0 ? (
              allowFreeText && query.trim() ? (
                <button type="button" onClick={() => { onFreeTextChange && onFreeTextChange(query.trim()); onSelect(null); setOpen(false); }}
                  className="w-full flex items-center gap-3 px-3 py-2.5 hover:bg-emerald-50 transition-colors text-left">
                  <div className="w-8 h-8 rounded-lg bg-emerald-50 flex items-center justify-center flex-shrink-0">
                    <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="#059669" strokeWidth="2.5" strokeLinecap="round"><path d="M12 5v14M5 12h14" /></svg>
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className="text-sm font-semibold text-emerald-700 truncate">Add "{query.trim()}" as new product</p>
                    <p className="text-xs text-slate-400">Not in catalog yet</p>
                  </div>
                </button>
              ) : (
                <p className="text-xs text-slate-400 text-center py-4">No products found</p>
              )
            ) : (
              filtered.map((p) => (
                <button key={p.id} type="button" onClick={() => handlePick(p)}
                  className="w-full flex items-center gap-3 px-3 py-2.5 hover:bg-blue-50 transition-colors text-left">
                  <div className="w-8 h-8 rounded-lg bg-blue-50 flex items-center justify-center flex-shrink-0">
                    <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="#2563eb" strokeWidth="2" strokeLinecap="round"><path d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4" /></svg>
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className="text-sm font-semibold text-slate-800 truncate">{p.name}</p>
                    <p className="text-xs text-slate-400">{p.category || "—"} · Stock: {p.currentStock}</p>
                  </div>
                </button>
              ))
            )}
          </div>
        </div>
      )}
    </div>
  );
}
