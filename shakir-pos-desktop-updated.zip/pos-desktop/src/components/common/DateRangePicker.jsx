import { useState, useRef, useEffect } from "react";

const MONTH_NAMES = ["January","February","March","April","May","June","July","August","September","October","November","December"];
const DAY_NAMES = ["Su","Mo","Tu","We","Th","Fr","Sa"];

function toISODate(d) {
  const y = d.getFullYear(), m = String(d.getMonth() + 1).padStart(2, "0"), day = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}
function fmtShort(iso) {
  if (!iso) return "";
  const d = new Date(iso + "T00:00:00");
  return d.toLocaleDateString("en-PK", { day: "2-digit", month: "short", year: "numeric" });
}

/**
 * A calendar dropdown for picking a custom date range (from → to).
 * value: { from: "YYYY-MM-DD"|null, to: "YYYY-MM-DD"|null }
 * onChange(range) is called once both from & to are picked (or cleared).
 */
export default function DateRangePicker({ value, onChange, label = "Custom Range" }) {
  const [open, setOpen] = useState(false);
  const [viewMonth, setViewMonth] = useState(() => {
    const base = value?.from ? new Date(value.from + "T00:00:00") : new Date();
    return new Date(base.getFullYear(), base.getMonth(), 1);
  });
  const [pickingFrom, setPickingFrom] = useState(value?.from || null);
  const [pickingTo, setPickingTo] = useState(value?.to || null);
  const ref = useRef(null);

  useEffect(() => {
    function onClickOutside(e) {
      if (ref.current && !ref.current.contains(e.target)) setOpen(false);
    }
    document.addEventListener("mousedown", onClickOutside);
    return () => document.removeEventListener("mousedown", onClickOutside);
  }, []);

  useEffect(() => {
    setPickingFrom(value?.from || null);
    setPickingTo(value?.to || null);
  }, [value?.from, value?.to]);

  const hasRange = value?.from && value?.to;

  const daysInMonth = new Date(viewMonth.getFullYear(), viewMonth.getMonth() + 1, 0).getDate();
  const firstDayOfWeek = new Date(viewMonth.getFullYear(), viewMonth.getMonth(), 1).getDay();
  const cells = [];
  for (let i = 0; i < firstDayOfWeek; i++) cells.push(null);
  for (let d = 1; d <= daysInMonth; d++) cells.push(new Date(viewMonth.getFullYear(), viewMonth.getMonth(), d));

  const handleDayClick = (date) => {
    const iso = toISODate(date);
    if (!pickingFrom || (pickingFrom && pickingTo)) {
      // Start a fresh selection
      setPickingFrom(iso);
      setPickingTo(null);
    } else {
      // Second click: complete the range (swap if picked backwards)
      if (iso < pickingFrom) {
        setPickingTo(pickingFrom);
        setPickingFrom(iso);
        onChange({ from: iso, to: pickingFrom });
      } else {
        setPickingTo(iso);
        onChange({ from: pickingFrom, to: iso });
      }
      setOpen(false);
    }
  };

  const isInRange = (date) => {
    if (!date || !pickingFrom) return false;
    const iso = toISODate(date);
    const end = pickingTo || pickingFrom;
    return iso >= pickingFrom && iso <= end;
  };
  const isEndpoint = (date) => {
    if (!date) return false;
    const iso = toISODate(date);
    return iso === pickingFrom || iso === pickingTo;
  };

  const handleClear = () => {
    setPickingFrom(null);
    setPickingTo(null);
    onChange({ from: null, to: null });
    setOpen(false);
  };

  return (
    <div className="relative" ref={ref}>
      <button
        onClick={() => setOpen((o) => !o)}
        className={`flex items-center gap-2 px-3.5 py-2.5 rounded-xl border text-xs font-bold transition-all ${
          hasRange ? "bg-blue-600 text-white border-blue-600 shadow-sm shadow-blue-200" : "bg-white text-slate-600 border-slate-200 hover:bg-slate-50"
        }`}
      >
        <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <rect x="3" y="4" width="18" height="18" rx="2" /><line x1="16" y1="2" x2="16" y2="6" /><line x1="8" y1="2" x2="8" y2="6" /><line x1="3" y1="10" x2="21" y2="10" />
        </svg>
        {hasRange ? `${fmtShort(value.from)} – ${fmtShort(value.to)}` : label}
      </button>

      {open && (
        <div className="absolute z-40 top-full mt-2 right-0 bg-white rounded-2xl border border-slate-200 shadow-xl p-4 w-[300px]">
          <div className="flex items-center justify-between mb-3">
            <button onClick={() => setViewMonth((m) => new Date(m.getFullYear(), m.getMonth() - 1, 1))}
              className="w-7 h-7 flex items-center justify-center rounded-lg hover:bg-slate-100 text-slate-500">
              <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round"><path d="M15 18l-6-6 6-6" /></svg>
            </button>
            <p className="text-sm font-bold text-slate-700">{MONTH_NAMES[viewMonth.getMonth()]} {viewMonth.getFullYear()}</p>
            <button onClick={() => setViewMonth((m) => new Date(m.getFullYear(), m.getMonth() + 1, 1))}
              className="w-7 h-7 flex items-center justify-center rounded-lg hover:bg-slate-100 text-slate-500">
              <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round"><path d="M9 18l6-6-6-6" /></svg>
            </button>
          </div>
          <div className="grid grid-cols-7 gap-1 mb-1">
            {DAY_NAMES.map((d) => <div key={d} className="text-center text-[10px] font-bold text-slate-400 py-1">{d}</div>)}
          </div>
          <div className="grid grid-cols-7 gap-1">
            {cells.map((date, i) => (
              <button
                key={i}
                disabled={!date}
                onClick={() => date && handleDayClick(date)}
                className={`h-8 rounded-lg text-xs font-semibold transition-colors ${
                  !date ? "" :
                  isEndpoint(date) ? "bg-blue-600 text-white" :
                  isInRange(date) ? "bg-blue-100 text-blue-700" :
                  "text-slate-600 hover:bg-slate-100"
                }`}
              >
                {date ? date.getDate() : ""}
              </button>
            ))}
          </div>
          <div className="flex items-center justify-between mt-3 pt-3 border-t border-slate-100">
            <p className="text-[11px] text-slate-400">
              {pickingFrom ? `${fmtShort(pickingFrom)}${pickingTo ? " – " + fmtShort(pickingTo) : " → select end date"}` : "Select start date"}
            </p>
            {hasRange && (
              <button onClick={handleClear} className="text-[11px] font-bold text-red-500 hover:text-red-600">Clear</button>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
