import { useState } from "react";
import { navItems } from "../../data/mockData";

const TOP_LEVEL_LABELS = ["Dashboard", "Products", "Point of Sale", "Invoices", "Reports", "Customers", "Suppliers", "Expenses", "Settings"];

// Sub-pages nested under "Products" — reached via the dropdown, not a
// top-level nav item of their own.
const PRODUCTS_SUBNAV = [
  { label: "Order Returns", icon: "M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8 M3 3v5h5" },
  { label: "Loss Management", icon: "M12 9v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" },
];

function renderIcon(iconPath) {
  return (
    <svg xmlns="http://www.w3.org/2000/svg" width="19" height="19" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" className="flex-shrink-0">
      {iconPath.split(" M").map((part, i) => (
        <path key={i} d={i === 0 ? part : "M" + part} />
      ))}
    </svg>
  );
}

export default function Sidebar({ sidebarOpen, mobileSidebar, setMobileSidebar, activeNav, setActiveNav, setSidebarOpen, appSettings = {} }) {
  const [productsExpanded, setProductsExpanded] = useState(PRODUCTS_SUBNAV.some((s) => s.label === activeNav));

  const goTo = (label) => {
    setActiveNav(label);
    setMobileSidebar(false);
  };

  return (
    <>
      {mobileSidebar && (
        <div
          className="fixed inset-0 bg-black/40 z-20 lg:hidden"
          onClick={() => setMobileSidebar(false)}
        />
      )}

      <aside
        className={`
          fixed lg:relative z-30 flex flex-col h-full bg-white border-r border-slate-100
          transition-all duration-300 ease-in-out shadow-sm
          ${mobileSidebar ? "translate-x-0 w-64" : "-translate-x-full lg:translate-x-0"}
          ${sidebarOpen ? "lg:w-64" : "lg:w-20"}
        `}
      >
        <div className="flex items-center gap-3 px-5 py-5 border-b border-slate-100">
          <div className="w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0 shadow-md shadow-blue-200 overflow-hidden">
            <img src="./logo.png" alt="Logo" className="w-full h-full object-cover" />
          </div>
          {sidebarOpen && (
            <div className="overflow-hidden">
              <p className="font-bold text-slate-800 text-base leading-tight">{appSettings.appName || "Shakir POS"}</p>
              <p className="text-xs text-slate-400">{appSettings.tagline || "Pro Dashboard"}</p>
            </div>
          )}
        </div>

        <button
          onClick={() => setSidebarOpen(!sidebarOpen)}
          className="hidden lg:flex absolute -right-3.5 top-16 w-7 h-7 bg-white border border-slate-200 rounded-full items-center justify-center shadow-sm hover:bg-blue-50 transition-colors"
        >
          <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="#1D6FDB" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
            <path d={sidebarOpen ? "M15 18l-6-6 6-6" : "M9 18l6-6-6-6"} />
          </svg>
        </button>

        <nav className="flex-1 px-3 py-4 space-y-1 overflow-y-auto scrollbar-hide">
          {navItems.map((item) => {
            const isProducts = item.label === "Products";
            const isSubActive = isProducts && PRODUCTS_SUBNAV.some((s) => s.label === activeNav);
            return (
              <div key={item.label}>
                <div
                  className={`w-full flex items-center gap-1 rounded-xl transition-all duration-200 group
                    ${activeNav === item.label || isSubActive
                      ? "bg-blue-600 text-white shadow-md shadow-blue-200"
                      : "text-slate-500 hover:bg-slate-50 hover:text-slate-700"
                    }`}
                >
                  <button
                    onClick={() => {
                      if (TOP_LEVEL_LABELS.includes(item.label)) goTo(item.label);
                    }}
                    className="flex-1 flex items-center gap-3 px-3 py-2.5 min-w-0"
                  >
                    {renderIcon(item.icon)}
                    {sidebarOpen && (
                      <span className="text-sm font-medium whitespace-nowrap truncate">{item.label}</span>
                    )}
                  </button>
                  {isProducts && sidebarOpen && (
                    <button
                      onClick={(e) => { e.stopPropagation(); setProductsExpanded((v) => !v); }}
                      className="px-2.5 py-2.5 flex-shrink-0"
                      title="Order Returns / Loss Management"
                    >
                      <svg xmlns="http://www.w3.org/2000/svg" width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"
                        className={`transition-transform duration-200 ${productsExpanded ? "rotate-180" : ""}`}>
                        <path d="m6 9 6 6 6-6" />
                      </svg>
                    </button>
                  )}
                </div>

                {isProducts && sidebarOpen && productsExpanded && (
                  <div className="mt-1 ml-4 pl-3 border-l-2 border-slate-100 space-y-1">
                    {PRODUCTS_SUBNAV.map((sub) => (
                      <button
                        key={sub.label}
                        onClick={() => goTo(sub.label)}
                        className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-lg transition-colors text-xs font-semibold
                          ${activeNav === sub.label ? "bg-blue-50 text-blue-600" : "text-slate-500 hover:bg-slate-50 hover:text-slate-700"}`}
                      >
                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="flex-shrink-0">
                          {sub.icon.split(" M").map((part, i) => (
                            <path key={i} d={i === 0 ? part : "M" + part} />
                          ))}
                        </svg>
                        <span className="truncate">{sub.label}</span>
                      </button>
                    ))}
                  </div>
                )}
              </div>
            );
          })}
        </nav>
      </aside>
    </>
  );
}
