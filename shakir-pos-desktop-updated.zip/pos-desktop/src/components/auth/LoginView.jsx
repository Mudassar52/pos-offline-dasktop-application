import { useState } from "react";

// ── Shared bits ─────────────────────────────────────────────────────────
const inputBase =
  "w-full px-3 py-2.5 rounded-xl text-sm outline-none transition-all bg-slate-50 border font-medium placeholder-slate-300 text-slate-800 focus:bg-white focus:border-blue-500 focus:ring-2 focus:ring-blue-100";
const labelCls = "block text-[10px] font-bold uppercase tracking-widest text-slate-400 mb-1.5";

function Logo() {
  return (
    <div className="flex items-center gap-2.5 mb-7">
      <img src="./logo.png" alt="Shakir POS" className="w-9 h-9 rounded-xl shadow-sm" />
      <span className="font-bold text-slate-800 text-base tracking-tight">Shakir POS</span>
    </div>
  );
}

function ErrorBanner({ message }) {
  if (!message) return null;
  return (
    <div className="mb-3 px-3.5 py-2.5 rounded-xl bg-red-50 border border-red-200 flex items-center gap-2">
      <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#ef4444" strokeWidth="2.5" strokeLinecap="round"><circle cx="12" cy="12" r="10" /><line x1="12" y1="8" x2="12" y2="12" /><line x1="12" y1="16" x2="12.01" y2="16" /></svg>
      <p className="text-red-600 text-xs font-medium">{message}</p>
    </div>
  );
}

function SuccessBanner({ message }) {
  if (!message) return null;
  return (
    <div className="mb-3 px-3.5 py-2.5 rounded-xl bg-emerald-50 border border-emerald-200 flex items-center gap-2">
      <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#059669" strokeWidth="2.5" strokeLinecap="round"><circle cx="12" cy="12" r="10" /><path d="M9 12l2 2 4-4" /></svg>
      <p className="text-emerald-700 text-xs font-medium">{message}</p>
    </div>
  );
}

function PasswordField({ label = "Password", value, onChange, error, onEnter, autoComplete = "current-password" }) {
  const [show, setShow] = useState(false);
  return (
    <div>
      <label className={labelCls}>{label}</label>
      <div className="relative">
        <input
          type={show ? "text" : "password"}
          value={value}
          onChange={onChange}
          autoComplete={autoComplete}
          placeholder="••••••••"
          className={`${inputBase} pr-9 ${error ? "border-red-400 bg-red-50" : "border-slate-200"}`}
          onKeyDown={(e) => e.key === "Enter" && onEnter && onEnter()}
        />
        <button type="button" onClick={() => setShow((s) => !s)} className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-300 hover:text-slate-500">
          <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
            {show ? <><path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24" /><line x1="1" y1="1" x2="23" y2="23" /></> : <><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z" /><circle cx="12" cy="12" r="3" /></>}
          </svg>
        </button>
      </div>
      {error && <p className="text-red-500 text-[10px] mt-1 font-medium">{error}</p>}
    </div>
  );
}

function SubmitButton({ loading, label, loadingLabel = "Please wait..." }) {
  return (
    <button
      type="button"
      disabled={loading}
      className="w-full mt-6 py-2.5 rounded-xl text-white text-sm font-bold tracking-tight transition-all disabled:opacity-60 flex items-center justify-center gap-2"
      style={{ background: "#1D6FDB" }}
      onMouseEnter={(e) => !e.currentTarget.disabled && (e.currentTarget.style.background = "#185FA5")}
      onMouseLeave={(e) => (e.currentTarget.style.background = "#1D6FDB")}
    >
      {loading ? (
        <><svg className="animate-spin" xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><path d="M21 12a9 9 0 11-6.219-8.56" /></svg>{loadingLabel}</>
      ) : (
        <>{label} <span className="opacity-70">→</span></>
      )}
    </button>
  );
}

const errorMsg = (err, fallback) => {
  if (err?.code === "auth/invalid-credential") return "Username ya password/jawab ghalat hai";
  if (err?.code === "auth/username-exists") return "Yeh username pehle se mojood hai";
  if (err?.code === "auth/no-security-question") return "Is username ke liye security question set nahi hai";
  if (err?.code === "auth/security-question-required") return "Security question aur jawab dono zaroori hain";
  return err?.message || fallback || "Kuch ghalat ho gaya. Dobara koshish karein.";
};

// ── Main component ──────────────────────────────────────────────────────
// mode: "login" | "register" | "forgot-username" | "forgot-answer"
export default function LoginView({ onEmailLogin, onEmailRegister, onGetSecurityQuestion, onForgotPassword }) {
  const [mode, setMode] = useState("login");

  return (
    <div
      className="min-h-screen flex items-center justify-center bg-slate-100 p-4"
      style={{ fontFamily: "'Plus Jakarta Sans', 'DM Sans', 'Segoe UI', sans-serif" }}
    >
      <div className="w-full max-w-[440px] rounded-2xl overflow-hidden shadow-2xl shadow-slate-300/60 border border-slate-200/60 bg-white">
        <div className="p-8">
          <Logo />
          {mode === "login" && <LoginForm onEmailLogin={onEmailLogin} goRegister={() => setMode("register")} goForgot={() => setMode("forgot-username")} />}
          {mode === "register" && <RegisterForm onEmailRegister={onEmailRegister} goLogin={() => setMode("login")} />}
          {(mode === "forgot-username" || mode === "forgot-answer") && (
            <ForgotPasswordForm
              step={mode === "forgot-username" ? 1 : 2}
              setStep={(s) => setMode(s === 1 ? "forgot-username" : "forgot-answer")}
              onGetSecurityQuestion={onGetSecurityQuestion}
              onForgotPassword={onForgotPassword}
              goLogin={() => setMode("login")}
            />
          )}
        </div>
      </div>
    </div>
  );
}

// ── Login ────────────────────────────────────────────────────────────────
function LoginForm({ onEmailLogin, goRegister, goForgot }) {
  const [form, setForm] = useState({ email: "", password: "" });
  const [errors, setErrors] = useState({});
  const [loading, setLoading] = useState(false);

  const validate = () => {
    const e = {};
    if (!form.email.trim()) e.email = "Username darj karein";
    if (form.password.length < 3) e.password = "Password darj karein";
    return e;
  };

  const handleSubmit = async () => {
    const e = validate();
    if (Object.keys(e).length) { setErrors(e); return; }
    setLoading(true);
    setErrors({});
    try {
      await onEmailLogin(form.email.trim(), form.password);
    } catch (err) {
      setErrors({ general: errorMsg(err) });
    } finally {
      setLoading(false);
    }
  };

  const set = (key) => (e) => {
    setForm((f) => ({ ...f, [key]: e.target.value }));
    setErrors((er) => ({ ...er, [key]: "", general: "" }));
  };

  return (
    <>
      <div className="mb-6">
        <h1 className="text-[22px] font-extrabold text-slate-800 tracking-tight leading-none">Welcome back</h1>
        <p className="text-slate-400 text-xs mt-1.5">Apne local account se sign in karein</p>
      </div>

      <ErrorBanner message={errors.general} />

      <div className="space-y-3">
        <div>
          <label className={labelCls}>Username</label>
          <input type="text" autoComplete="username" value={form.email} onChange={set("email")} placeholder="admin"
            className={`${inputBase} ${errors.email ? "border-red-400 bg-red-50" : "border-slate-200"}`} />
          {errors.email && <p className="text-red-500 text-[10px] mt-1 font-medium">{errors.email}</p>}
        </div>
        <PasswordField value={form.password} onChange={set("password")} error={errors.password} onEnter={handleSubmit} />
      </div>

      <div onClick={handleSubmit}>
        <SubmitButton loading={loading} label="Sign In" />
      </div>

      <div className="flex items-center justify-between mt-4">
        <button onClick={goForgot} className="text-[11px] font-semibold text-blue-500 hover:text-blue-700">Password bhool gaye?</button>
        <button onClick={goRegister} className="text-[11px] font-semibold text-blue-500 hover:text-blue-700">Naya account banayein</button>
      </div>

      <p className="text-center text-[11px] text-slate-300 mt-4">
        Pehli baar khol rahe hain? Default: <span className="font-semibold text-slate-400">shakirmahmood6566@gmail.com</span> / <span className="font-semibold text-slate-400">shakir6566</span>
      </p>
    </>
  );
}

// ── Register ─────────────────────────────────────────────────────────────
function RegisterForm({ onEmailRegister, goLogin }) {
  const [form, setForm] = useState({ name: "", email: "", password: "", question: "", answer: "" });
  const [errors, setErrors] = useState({});
  const [loading, setLoading] = useState(false);

  const validate = () => {
    const e = {};
    if (!form.email.trim()) e.email = "Username darj karein";
    if (form.password.length < 6) e.password = "Kam az kam 6 characters ka password rakhein";
    if (!form.question.trim()) e.question = "Ek security question likhein";
    if (!form.answer.trim()) e.answer = "Uska jawab bhi darj karein";
    return e;
  };

  const handleSubmit = async () => {
    const e = validate();
    if (Object.keys(e).length) { setErrors(e); return; }
    setLoading(true);
    setErrors({});
    try {
      await onEmailRegister(form.email.trim(), form.password, form.name.trim(), form.question.trim(), form.answer.trim());
    } catch (err) {
      setErrors({ general: errorMsg(err) });
    } finally {
      setLoading(false);
    }
  };

  const set = (key) => (e) => {
    setForm((f) => ({ ...f, [key]: e.target.value }));
    setErrors((er) => ({ ...er, [key]: "", general: "" }));
  };

  return (
    <>
      <div className="mb-6">
        <h1 className="text-[22px] font-extrabold text-slate-800 tracking-tight leading-none">Naya account</h1>
        <p className="text-slate-400 text-xs mt-1.5">Yaad rahe: sab accounts isi dukaan ka ek hi shared data (products/customers/invoices) dekhte hain — sirf login alag hota hai.</p>
      </div>

      <ErrorBanner message={errors.general} />

      <div className="space-y-3">
        <div>
          <label className={labelCls}>Naam (optional)</label>
          <input type="text" value={form.name} onChange={set("name")} placeholder="Aapka naam" className={`${inputBase} border-slate-200`} />
        </div>
        <div>
          <label className={labelCls}>Username</label>
          <input type="text" autoComplete="username" value={form.email} onChange={set("email")} placeholder="e.g. owner@dukaan.com"
            className={`${inputBase} ${errors.email ? "border-red-400 bg-red-50" : "border-slate-200"}`} />
          {errors.email && <p className="text-red-500 text-[10px] mt-1 font-medium">{errors.email}</p>}
        </div>
        <PasswordField label="Password" value={form.password} onChange={set("password")} error={errors.password} autoComplete="new-password" />
        <div>
          <label className={labelCls}>Security Question</label>
          <input type="text" value={form.question} onChange={set("question")} placeholder="e.g. Pehle pale kutte ka naam?"
            className={`${inputBase} ${errors.question ? "border-red-400 bg-red-50" : "border-slate-200"}`} />
          {errors.question && <p className="text-red-500 text-[10px] mt-1 font-medium">{errors.question}</p>}
        </div>
        <div>
          <label className={labelCls}>Iska Jawab</label>
          <input type="text" value={form.answer} onChange={set("answer")} placeholder="Jawab yaad rakhein — password bhool jane par yehi chahiye hoga"
            className={`${inputBase} ${errors.answer ? "border-red-400 bg-red-50" : "border-slate-200"}`} />
          {errors.answer && <p className="text-red-500 text-[10px] mt-1 font-medium">{errors.answer}</p>}
        </div>
      </div>

      <div onClick={handleSubmit}>
        <SubmitButton loading={loading} label="Account Banayein" />
      </div>

      <button onClick={goLogin} className="w-full text-center text-[11px] font-semibold text-blue-500 hover:text-blue-700 mt-4">
        Pehle se account hai? Sign in karein
      </button>
    </>
  );
}

// ── Forgot Password (2-step) ────────────────────────────────────────────
function ForgotPasswordForm({ step, setStep, onGetSecurityQuestion, onForgotPassword, goLogin }) {
  const [username, setUsername] = useState("");
  const [question, setQuestion] = useState("");
  const [answer, setAnswer] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [errors, setErrors] = useState({});
  const [loading, setLoading] = useState(false);
  const [done, setDone] = useState(false);

  const handleFindAccount = async () => {
    if (!username.trim()) { setErrors({ username: "Username darj karein" }); return; }
    setLoading(true);
    setErrors({});
    try {
      const res = await onGetSecurityQuestion(username.trim());
      setQuestion(res.question);
      setStep(2);
    } catch (err) {
      setErrors({ general: errorMsg(err, "Yeh username nahi mila") });
    } finally {
      setLoading(false);
    }
  };

  const handleReset = async () => {
    const e = {};
    if (!answer.trim()) e.answer = "Jawab darj karein";
    if (newPassword.length < 6) e.newPassword = "Kam az kam 6 characters ka password rakhein";
    if (Object.keys(e).length) { setErrors(e); return; }
    setLoading(true);
    setErrors({});
    try {
      await onForgotPassword(username.trim(), answer.trim(), newPassword);
      setDone(true);
    } catch (err) {
      setErrors({ general: errorMsg(err) });
    } finally {
      setLoading(false);
    }
  };

  if (done) {
    return (
      <>
        <div className="mb-6">
          <h1 className="text-[22px] font-extrabold text-slate-800 tracking-tight leading-none">Password reset ho gaya</h1>
          <p className="text-slate-400 text-xs mt-1.5">Ab naye password se sign in kar sakte hain. Purana dukaan ka data (products/customers/invoices) bilkul waisa hi hai — kuch nahi badla.</p>
        </div>
        <SuccessBanner message="Password kamyabi se badal diya gaya." />
        <button onClick={goLogin} className="w-full mt-4 py-2.5 rounded-xl text-white text-sm font-bold" style={{ background: "#1D6FDB" }}>
          Sign In Par Jayein
        </button>
      </>
    );
  }

  return (
    <>
      <div className="mb-6">
        <h1 className="text-[22px] font-extrabold text-slate-800 tracking-tight leading-none">Password bhool gaye?</h1>
        <p className="text-slate-400 text-xs mt-1.5">
          {step === 1 ? "Apna username darj karein" : "Apne security question ka jawab de kar naya password set karein"}
        </p>
      </div>

      <ErrorBanner message={errors.general} />

      {step === 1 ? (
        <>
          <div>
            <label className={labelCls}>Username</label>
            <input type="text" value={username} onChange={(e) => { setUsername(e.target.value); setErrors({}); }}
              placeholder="admin" className={`${inputBase} ${errors.username ? "border-red-400 bg-red-50" : "border-slate-200"}`}
              onKeyDown={(e) => e.key === "Enter" && handleFindAccount()} />
            {errors.username && <p className="text-red-500 text-[10px] mt-1 font-medium">{errors.username}</p>}
          </div>
          <div onClick={handleFindAccount}>
            <SubmitButton loading={loading} label="Aage Barhein" />
          </div>
        </>
      ) : (
        <div className="space-y-3">
          <div className="px-3.5 py-2.5 rounded-xl bg-slate-50 border border-slate-200">
            <p className="text-[10px] font-bold uppercase tracking-widest text-slate-400 mb-1">Security Question</p>
            <p className="text-sm font-semibold text-slate-700">{question}</p>
          </div>
          <div>
            <label className={labelCls}>Jawab</label>
            <input type="text" value={answer} onChange={(e) => { setAnswer(e.target.value); setErrors((er) => ({ ...er, answer: "", general: "" })); }}
              className={`${inputBase} ${errors.answer ? "border-red-400 bg-red-50" : "border-slate-200"}`} />
            {errors.answer && <p className="text-red-500 text-[10px] mt-1 font-medium">{errors.answer}</p>}
          </div>
          <PasswordField label="Naya Password" value={newPassword}
            onChange={(e) => { setNewPassword(e.target.value); setErrors((er) => ({ ...er, newPassword: "", general: "" })); }}
            error={errors.newPassword} autoComplete="new-password" onEnter={handleReset} />
          <div onClick={handleReset}>
            <SubmitButton loading={loading} label="Password Reset Karein" />
          </div>
        </div>
      )}

      <button onClick={goLogin} className="w-full text-center text-[11px] font-semibold text-blue-500 hover:text-blue-700 mt-4">
        ← Sign in par wapis jayein
      </button>
    </>
  );
}
