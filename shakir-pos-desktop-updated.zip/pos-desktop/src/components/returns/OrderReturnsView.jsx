import { useState, useMemo } from "react";
import StatsGrid from "../common/StatsGrid";
import DateRangePicker from "../common/DateRangePicker";
import ProductSelector from "../common/ProductSelector";

function formatDate(iso) {
  if (!iso) return "—";
  return new Date(iso).toLocaleDateString("en-PK", { day: "2-digit", month: "short", year: "numeric" });
}

const RETURN_REASONS = ["Customer Changed Mind", "Wrong Item", "Damaged/Defective", "Size/Quality Issue", "Other"];

let rowIdCounter = 0;
function newRowId() {
  rowIdCounter += 1;
  return `ret_row_${rowIdCounter}`;
}
function emptyRow() {
  return { rowId: newRowId(), product: null, qty: "", reason: RETURN_REASONS[0], note: "" };
}

// ── Naya Return Add Karein — ek hi baar mein jitne marzi products add kiye
// ja sakte hain. Har row apna product, quantity, aur reason rakhti hai.
function AddReturnModal({ products, onClose, onSave }) {
  const [rows, setRows] = useState([emptyRow()]);
  const [error, setError] = useState("");
  const [saving, setSaving] = useState(false);

  const updateRow = (rowId, patch) => {
    setRows((prev) => prev.map((r) => (r.rowId === rowId ? { ...r, ...patch } : r)));
    setError("");
  };
  const addRow = () => setRows((prev) => [...prev, emptyRow()]);
  const removeRow = (rowId) => setRows((prev) => (prev.length > 1 ? prev.filter((r) => r.rowId !== rowId) : prev));

  const handleSubmit = async () => {
    for (const r of rows) {
      if (!r.product) { setError("Har row mein product select karein"); return; }
      if (!Number(r.qty) || Number(r.qty) <= 0) { setError("Har product ki quantity 0 se zyada honi chahiye"); return; }
    }
    try {
      setSaving(true);
      // Har row alag return entry banati hai — sab ka stock apne aap wapis
      // charh jata hai.
      for (const r of rows) {
        await onSave({ productId: r.product.id, productName: r.product.name, qty: Number(r.qty), reason: r.reason, note: r.note });
      }
      onClose();
    } catch (err) {
      setError(err.message || "Save nahi ho saka");
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm">
      <div className="bg-white rounded-2xl w-full max-w-2xl shadow-2xl max-h-[92vh] flex flex-col">
        <div className="flex items-center justify-between px-6 pt-5 pb-4 border-b border-slate-100 flex-shrink-0">
          <h2 className="font-bold text-slate-800 text-lg">Naya Return Add Karein</h2>
          <button onClick={onClose} className="w-8 h-8 flex items-center justify-center rounded-xl hover:bg-slate-100 text-slate-400">
            <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round"><path d="M18 6 6 18M6 6l12 12" /></svg>
          </button>
        </div>
        <div className="px-6 py-5 space-y-3 overflow-y-auto scrollbar-hide">
          {rows.map((r, idx) => (
            <div key={r.rowId} className="bg-slate-50 rounded-xl p-3.5 border border-slate-100">
              <div className="flex items-center justify-between mb-2">
                <p className="text-xs font-bold text-slate-500">Product #{idx + 1}</p>
                {rows.length > 1 && (
                  <button onClick={() => removeRow(r.rowId)} title="Row hataein"
                    className="w-6 h-6 flex items-center justify-center bg-red-50 hover:bg-red-100 text-red-500 rounded-lg transition-colors">
                    <svg xmlns="http://www.w3.org/2000/svg" width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round"><path d="M18 6 6 18M6 6l12 12" /></svg>
                  </button>
                )}
              </div>
              <div className="space-y-2.5">
                <ProductSelector products={products} selectedProduct={r.product} onSelect={(p) => updateRow(r.rowId, { product: p })} placeholder="Product search karein..." />
                <div className="grid grid-cols-2 gap-2.5">
                  <div>
                    <label className="block text-[11px] font-semibold text-slate-500 mb-1">Quantity Returned</label>
                    <input type="number" value={r.qty} onChange={(e) => updateRow(r.rowId, { qty: e.target.value })} placeholder="0"
                      className="w-full px-3 py-2 rounded-lg border border-slate-200 text-sm outline-none focus:border-blue-400 bg-white" />
                  </div>
                  <div>
                    <label className="block text-[11px] font-semibold text-slate-500 mb-1">Reason</label>
                    <select value={r.reason} onChange={(e) => updateRow(r.rowId, { reason: e.target.value })}
                      className="w-full px-3 py-2 rounded-lg border border-slate-200 text-sm outline-none focus:border-blue-400 bg-white">
                      {RETURN_REASONS.map((rs) => <option key={rs} value={rs}>{rs}</option>)}
                    </select>
                  </div>
                </div>
                <input type="text" value={r.note} onChange={(e) => updateRow(r.rowId, { note: e.target.value })} placeholder="Note (optional)..."
                  className="w-full px-3 py-2 rounded-lg border border-slate-200 text-sm outline-none focus:border-blue-400 bg-white" />
                {r.product && (
                  <p className="text-[11px] text-emerald-600 bg-emerald-50 rounded-lg px-2.5 py-1.5">
                    ✓ Save karne par is product ka stock wapis <b>{r.qty || 0}</b> unit se badh jayega.
                  </p>
                )}
              </div>
            </div>
          ))}

          <button onClick={addRow} type="button"
            className="w-full flex items-center justify-center gap-2 py-2.5 rounded-xl border-2 border-dashed border-slate-200 hover:border-blue-300 hover:bg-blue-50/30 text-sm font-bold text-slate-500 hover:text-blue-600 transition-colors">
            <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round"><path d="M12 5v14M5 12h14" /></svg>
            Ek Aur Product Add Karein
          </button>

          {error && <p className="text-xs text-red-500">{error}</p>}
        </div>
        <div className="px-6 py-4 flex gap-3 border-t border-slate-100 flex-shrink-0">
          <button onClick={onClose} className="flex-1 py-2.5 rounded-xl border border-slate-200 text-sm font-semibold text-slate-600 hover:bg-slate-50">Cancel</button>
          <button onClick={handleSubmit} disabled={saving}
            className="flex-1 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white text-sm font-bold transition-colors">
            {saving ? "Saving..." : "Return Save Karein"}
          </button>
        </div>
      </div>
    </div>
  );
}

export default function OrderReturnsView({ products = [], returns = [], addReturn, deleteReturn }) {
  const [dateRange, setDateRange] = useState({ from: null, to: null });
  const [search, setSearch] = useState("");
  const [showAdd, setShowAdd] = useState(false);

  const filtered = useMemo(() => {
    return returns
      .filter((r) => !search || r.productName.toLowerCase().includes(search.toLowerCase()))
      .filter((r) => {
        if (!dateRange.from || !dateRange.to) return true;
        const d = r.date.slice(0, 10);
        return d >= dateRange.from && d <= dateRange.to;
      })
      .sort((a, b) => new Date(b.date) - new Date(a.date));
  }, [returns, search, dateRange]);

  const stats = useMemo(() => {
    const now = new Date();
    const monthReturns = returns.filter((r) => { const d = new Date(r.date); return d.getFullYear() === now.getFullYear() && d.getMonth() === now.getMonth(); });
    const qtyReturned = returns.reduce((s, r) => s + r.qty, 0);
    return { totalReturns: returns.length, monthReturns: monthReturns.length, qtyReturned };
  }, [returns]);

  const statsCards = [
    { title: "Total Returns", value: stats.totalReturns, icon: "M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8", light: "bg-blue-50", text: "text-blue-600" },
    { title: "This Month Returns", value: stats.monthReturns, icon: "M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z", light: "bg-violet-50", text: "text-violet-600" },
    { title: "Qty Returned", value: stats.qtyReturned, icon: "M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4", light: "bg-emerald-50", text: "text-emerald-600" },
  ];

  return (
    <div className="flex-1 overflow-y-auto scrollbar-hide bg-slate-50/80">
      <div className="px-4 sm:px-6 pt-4 pb-2 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
        <div>
          <h2 className="text-lg font-black text-slate-800">Order Returns</h2>
          <p className="text-sm text-slate-400 mt-0.5">Wapis aaya hua maal record karein — stock khud badh jayega</p>
        </div>
        <button onClick={() => setShowAdd(true)}
          className="flex items-center gap-2 px-4 py-2.5 bg-blue-600 hover:bg-blue-700 text-white text-sm font-bold rounded-xl shadow-md shadow-blue-200 transition-colors self-start sm:self-auto">
          <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round"><path d="M12 5v14M5 12h14" /></svg>
          New Return
        </button>
      </div>

      <div className="px-4 sm:px-6 py-2">
        <StatsGrid cards={statsCards} />
      </div>

      <div className="px-4 sm:px-6 py-3">
        <div className="flex flex-col sm:flex-row items-stretch gap-3">
          <div className="flex-1 flex items-center gap-2 bg-white rounded-xl border border-slate-200 px-3.5 py-2.5">
            <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#94A3B8" strokeWidth="2" strokeLinecap="round"><circle cx="11" cy="11" r="8" /><path d="m21 21-4.35-4.35" /></svg>
            <input type="text" value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Product naam se search karein..."
              className="flex-1 bg-transparent text-sm outline-none placeholder:text-slate-400" />
          </div>
          <DateRangePicker value={dateRange} onChange={setDateRange} />
        </div>
      </div>

      <div className="px-4 sm:px-6 pb-6">
        {filtered.length === 0 ? (
          <div className="bg-white rounded-2xl border border-slate-100 p-16 text-center">
            <p className="text-slate-500 font-medium">Koi return record nahi mila.</p>
          </div>
        ) : (
          <div className="bg-white rounded-2xl border border-slate-100 overflow-hidden shadow-sm divide-y divide-slate-50">
            {filtered.map((r) => (
              <div key={r.id} className="flex items-center justify-between px-5 py-3.5 hover:bg-slate-50/50">
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-xl bg-blue-50 flex items-center justify-center flex-shrink-0">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#2563eb" strokeWidth="2" strokeLinecap="round"><path d="M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8" /><path d="M3 3v5h5" /></svg>
                  </div>
                  <div>
                    <p className="text-sm font-semibold text-slate-700">{r.productName}</p>
                    <p className="text-xs text-slate-400">{r.reason} · {formatDate(r.date)}{r.note ? ` · ${r.note}` : ""}</p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <span className="text-xs font-bold px-2.5 py-1 rounded-lg bg-blue-50 text-blue-600">Qty: {r.qty}</span>
                  <button onClick={() => deleteReturn(r.id)} title="Delete"
                    className="w-7 h-7 flex items-center justify-center bg-red-50 hover:bg-red-100 text-red-500 rounded-lg transition-colors">
                    <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round"><polyline points="3 6 5 6 21 6" /><path d="M19 6v14a2 2 0 01-2 2H7a2 2 0 01-2-2V6m3 0V4a2 2 0 012-2h4a2 2 0 012 2v2" /></svg>
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {showAdd && <AddReturnModal products={products} onClose={() => setShowAdd(false)} onSave={addReturn} />}
    </div>
  );
}
