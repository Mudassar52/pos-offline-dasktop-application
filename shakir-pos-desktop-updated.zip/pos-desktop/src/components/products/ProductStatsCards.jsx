import { useMemo } from "react";
import StatsGrid from "../common/StatsGrid";
import { formatCurrency } from "../../utils/productHelpers";

export default function ProductStatsCards({ stats, products = [] }) {
  // Total stock value = sab products ke current stock ki cost price ke hisaab se kul rakam
  // (costPrice na ho tu stockPrice, wo bhi na ho tu salePrice fallback ke tor par use hota hai)
  const totalStockValue = useMemo(() => {
    return products.reduce((sum, p) => {
      const unitCost = p.costPrice ?? p.stockPrice ?? p.salePrice ?? 0;
      return sum + unitCost * (p.currentStock || 0);
    }, 0);
  }, [products]);

  const cards = [
    {
      title: "Total Products",
      value: stats.totalProducts.toString(),
      icon: "M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4",
      light: "bg-violet-50",
      text: "text-violet-600",
    },
    {
      title: "Current Stock",
      value: stats.totalStock.toLocaleString(),
      icon: "M5 8h14M5 8a2 2 0 110-4h14a2 2 0 110 4M5 8v10a2 2 0 002 2h10a2 2 0 002-2V8m-9 4h4",
      light: "bg-blue-50",
      text: "text-blue-600",
    },
    {
      title: "Total Stock Value",
      value: formatCurrency(totalStockValue),
      sub: "Cost price ke hisaab se",
      icon: "M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z",
      light: "bg-amber-50",
      text: "text-amber-600",
    },
    {
      title: "Out of Stock",
      value: stats.outOfStockCount.toString(),
      change: stats.outOfStockCount > 0 ? "Critical" : null,
      up: false,
      icon: "M18.364 18.364A9 9 0 005.636 5.636m12.728 12.728A9 9 0 015.636 5.636m12.728 12.728L5.636 5.636",
      light: "bg-red-50",
      text: "text-red-600",
    },
  ];

  return <StatsGrid cards={cards} large />;
}
