// ── API client (talks to the local SQLite database via Electron's main
// process — no internet, no external server, everything stays on this
// computer). Kept the same get/post/put/delete shape as before so none of
// the existing components/hooks needed to change.
async function request(path, { method = "GET", body } = {}) {
  if (!window.electronAPI) {
    throw new Error("electronAPI not available — this app must run inside the Electron desktop shell.");
  }
  return window.electronAPI.request(method, path, body);
}

export const api = {
  get: (path) => request(path),
  post: (path, body) => request(path, { method: "POST", body }),
  put: (path, body) => request(path, { method: "PUT", body }),
  delete: (path) => request(path, { method: "DELETE" }),
};

// ── Local auth (bridges to electron/routes/auth.js via preload.js) ────────
export const localAuth = {
  login: (username, password) => window.electronAPI.login(username, password),
  register: (username, password, name, securityQuestion, securityAnswer) =>
    window.electronAPI.register(username, password, name, securityQuestion, securityAnswer),
  updatePassword: (userId, currentPassword, newPassword) =>
    window.electronAPI.updatePassword(userId, currentPassword, newPassword),
  getSecurityQuestion: (username) => window.electronAPI.getSecurityQuestion(username),
  resetPassword: (username, securityAnswer, newPassword) =>
    window.electronAPI.resetPassword(username, securityAnswer, newPassword),
};
