# Shakir POS — Offline Desktop App

Yeh aapke POS system ka **Electron + React + SQLite** version hai.
Koi internet nahi chahiye, koi backend server nahi chahiye — sara data
seedha isi computer par ek local file mein save hota hai.

> **Note:** Database engine ke taur par `sql.js` (pure JavaScript/WebAssembly)
> use kiya gaya hai, na ke `better-sqlite3`. Wajah: `better-sqlite3` ko har
> computer par C++ compile karna padta hai (Windows par Visual Studio Build
> Tools chahiye hoti hain), jo install ke waqt masle karta hai. `sql.js` ko
> kisi bhi cheez ke compile karne ki zaroorat nahi — `npm install` seedha,
> tez, aur har Windows/Mac/Linux computer par reliably chalta hai.

## App ka logo

Maine ek default logo bana kar `build/icon.png` mein rakh diya hai (app
ke andar sidebar, login screen, aur window icon sab isi ko use karte
hain). Agar aap **apna khud ka logo** lagana chahte hain:

1. Apni logo image ko **1024x1024 pixel PNG** (square, transparent ya
   solid background) mein tayyar karein
2. Usay `build/icon.png` par (isi naam se) replace kar dein
3. Usay `public/logo.png` par bhi copy kar dein (yeh app ke andar
   sidebar/login screen mein dikhta hai)
4. `npm run build` dobara chalayein

Bas itna hi — electron-builder khud is ek PNG se Windows (.ico), Mac
(.icns) aur Linux ke liye zaroori icon formats bana lega.

## Security (npm audit)

`npm install` ke baad agar "vulnerabilities" ka warning nazar aaye: yeh
sirf **build tool** (`electron-builder`, jo `.exe` banata hai) ki purani
dependencies mein thay — aapki asal app (login, data, POS) mein nahi.
Maine `electron-builder` aur `electron` dono ko latest version par
update kar diya hai, ab `npm audit` **0 vulnerabilities** dikhata hai.

## Performance (bara data)

App ko is tarah banaya gaya hai ke bohot saare products, customers, aur
invoices hone par bhi tez chale:
- Database mein zaroori **indexes** lagaye gaye hain (category, phone,
  customer, tareekh) taake search/reports fast rahein.
- Sirf **actual changes** (naya product, sale, waghera) hone par hi disk
  par save hota hai — sirf dekhne/list karne (GET) par nahi.
- Tezi se ki gayi kai changes (misal: ek sale complete karna) ek hi disk
  write mein **batch** ho jati hain, taake app kabhi bhi "atki hui" na
  lage.
- App band karte waqt bacha hua data turant (bina delay) save ho jata
  hai — koi data zaya nahi hota.

## Naye Features (Suppliers, Expenses, Calendar Filters)

**Suppliers page** — jin suppliers se aap maal khareedte hain, unka poora
record rakhein:
- Naya supplier add karein (naam, phone, city)
- Har supplier ke andar jaa kar "Maal Liya" (purchase) aur "Payment Diya"
  entries add karein — app khud hisaab laga kar batata hai kitna baaki
  hai (Payable)
- Naam/phone/city se search, aur date range (calendar) se filter

**Expenses page** — dukaan ke rozana kharche track karein:
- "Naya Expense Add Karein" toggle button se form khulta hai
- Apni marzi ki category chunein ya "+ Apni Category" se nayi bana lein
- Category-wise breakdown (kis cheez par kitna kharch hua) khud ban jata
  hai
- Category aur date range dono se filter kar sakte hain

**Dashboard aur Reports** — dono mein ab period buttons (Today/This
Week/This Month) ke sath ek **"Custom Range"** calendar button bhi hai,
jisse aap koi bhi custom tareekh se tareekh tak ka data dekh sakte hain.

## Kya badla gaya hai (summary)

- **Backend (Express + Postgres/Supabase) poori tarah hata diya gaya hai.**
  Uski jagah `electron/` folder mein wahi logic (products, customers, POS
  sales, invoices, reports, settings, backup) ab seedha local SQLite
  database (`better-sqlite3`) ke sath chalta hai — Electron ke "main
  process" ke andar.
- **Login ab local hai.** Supabase/Firebase/Google login hata diya gaya —
  ab username/password seedha isi computer ki SQLite database mein
  (bcrypt se hashed) save hota hai.
- **Frontend (React components) tabdeel nahi kiya gaya** — Products, POS,
  Invoices, Reports, Customers, Settings, Dashboard — sab wahi hain jo
  pehle thay. Sirf `src/api/client.js` aur `src/App.jsx` (login/logout
  handling) update kiye gaye hain taake wo local database se baat karein.

## Data kahan save hota hai?

Aapki dukaan ka sara data (products, sales, customers, invoices) is file
mein hota hai:

- **Windows:** `%APPDATA%\Shakir POS\pos-data.db`
- **Mac:** `~/Library/Application Support/Shakir POS/pos-data.db`
- **Linux:** `~/.config/Shakir POS/pos-data.db`

Backup lena ho to bas yeh file copy kar lein. App ke andar Settings mein
jo "Backup/Restore" feature pehle se maujood tha, wo bhi kaam karta hai.

## Pehli dafa install karna (development/testing ke liye)

Aapke computer par [Node.js](https://nodejs.org) (version 18 ya usse
zyada) installed honi chahiye.

```bash
cd pos-desktop
npm install
```

Bas itna hi — koi extra rebuild step nahi chahiye (koi native/C++ compile
nahi hota, isliye Visual Studio ya Python install karne ki zaroorat nahi).

> **Agar npm 12+ use kar rahe hain** aur `npm install` ke baad
> `Electron failed to install correctly` jaisa error aaye: yeh npm ki nayi
> security policy ki wajah se hai jo har package ki "install script" ko
> by default block kar deti hai (Electron apni install script se hi apna
> program download karta hai). Iska fix `package.json` ke andar
> `allowScripts` field mein pehle se maujood hai, lekin agar phir bhi masla
> aaye to yeh chalayein:
> ```bash
> npm rebuild
> ```
> Agar ye bhi kaam na kare, to `node_modules` folder delete kar ke
> `npm install` dobara chalayein.

## App ko test/run karna

```bash
npm run dev
```

Yeh Vite dev server + Electron dono ek sath chala dega — app ki window
khul jayegi.

## Default login

- **Username:** `shakirmahmood6566@gmail.com`
- **Password:** `shakir6566`

Login karne ke baad **Profile → Change Password** se ise turant badal
lein.

> Agar aapne pehle (purani zip se) app chala li hai, to us waqt
> `admin`/`admin123` wala user pehle se ban chuka hoga — is naye
> username/password se login nahi hoga kyunke default user sirf tab
> banta hai jab database bilkul khaali ho. Aisi soorat mein purane
> `admin` / `admin123` se login karein, ya `pos-data.db` file (dekhein
> upar "Data kahan save hota hai?") delete kar ke app dobara khol lein
> taake naya default user ban jaye — **lekin dhyan rahe iss se saara
> pehle wala data (products/customers/invoices) mit jayega.**

## Installer (.exe / AppImage / .dmg) banana

Jab aap tayyar hon ke apni dukaan/computer par install karne wali file
banayein:

```bash
npm run dist:win     # Windows ke liye .exe installer
npm run dist:linux   # Linux ke liye AppImage
npm run dist:mac     # Mac ke liye .dmg
```

Banayi hui file `release/` folder mein milegi. Yeh file directly install
karke app chala sakte hain — koi Node.js ya internet ki zaroorat nahi
hogi is installed app ko chalane ke liye.

**Zaroori:** Windows ke liye `.exe` banane ka kaam **apne Windows computer
par hi karein** — is command ko seedha Windows par chalane se koi extra
tool (wine waghera) ki zaroorat nahi hoti, sirf Node.js kaafi hai. Maine
yeh electron-builder config khud test kar ke confirm ki hai (Linux build
target ke sath) ke yeh mukammal sahi kaam karta hai.

## Structure

```
pos-desktop/
  electron/           ← main process: SQLite db, business logic, IPC
    main.js           ← Electron window + IPC handlers
    preload.js        ← safe bridge between main process & React app
    db.js             ← SQLite schema & connection
    apiRouter.js       ← routes /api/... calls to the right logic (products, pos, etc.)
    routes/           ← same business logic as the old Express routes, ported to SQLite
  src/                ← React frontend (mostly unchanged from your original)
  package.json
```

## Multiple users / cashiers

Filhal ek hi "admin" account hai. Agar aap chahte hain ke har cashier ka
apna alag login ho (taake pata chal sake kis ne kaunsi sale ki), mujhe
bata dijiye — main "Manage Users" screen bhi add kar sakta hoon.
